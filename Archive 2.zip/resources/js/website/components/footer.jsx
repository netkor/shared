import React from 'react'

const Footer = ({website}) => {
            var data=JSON.parse(website);
  return (

 <footer className="footer-area bg-f">
		<div className="container">
			<div className="row">
				<div className="col-lg-3 col-md-6">
					<h3>About Us</h3>
					<p>
                         {data.long_description.length > 250 ?
    `${data.long_description.substring(0, 300)}...` : data.long_description
  }
                    </p>
				</div>
				<div className="col-lg-3 col-md-6">
					<h3>Opening hours</h3>
					<p><span className="text-color"> </span>{data.close_time}</p>
					<p><span className="text-color"> </span>{data.open_time}</p>

				</div>
				<div className="col-lg-3 col-md-6">
					<h3>Contact information</h3>
					<p className="lead">{
                        data.address
                    }</p>
					<p className="lead"><a href="#">{
                        data.phone
                    }</a></p>
					<p><a href="#">{
                        data.email
                    }</a></p>
				</div>
				 <div className="col-lg-3 col-md-6">
					<h3>Subscribe</h3>
					<div className="subscribe_form">
						<form className="subscribe_form">
							<input name="EMAIL" id="subs-email" className="form_input" placeholder="Email Address..." type="email"/>
							<button type="submit" className="submit">SUBSCRIBE</button>
							<div className="clearfix"></div>
						</form>
					</div>
				<ul className="list-inline f-social">
					<li className="list-inline-item"><a href="#"><i className="fa fa-facebook" aria-hidden="true"></i></a></li>
                    <li className="list-inline-item"><a href="#"><i className="fa fa-twitter" aria-hidden="true"></i></a></li>
                    <li className="list-inline-item"><a href="#"><i className="fa fa-linkedin" aria-hidden="true"></i></a></li>
                    <li className="list-inline-item"><a href="#"><i className="fa fa-google-plus" aria-hidden="true"></i></a></li>
                    <li className="list-inline-item"><a href="#"><i className="fa fa-instagram" aria-hidden="true"></i></a></li>
				</ul>
			</div>
		</div>
		</div>

		<div className="copyright">
			<div className="container">
				<div className="row">
					<div className="col-lg-12">
						<p className="company-name">All Rights Reserved. &copy; 2022 <a href="#">Ara Tech Solutions</a> Design By :
                            <a href="http://pankajdahal.com.np/">Pankaj Dahal❤️</a>
                                        </p>

					</div>
				</div>
			</div>
		</div>

	</footer>
  )
}

export default Footer
