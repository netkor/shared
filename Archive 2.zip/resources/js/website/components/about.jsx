import React from 'react'

const About = ({website}) => {
            var data=JSON.parse(website);

  return (
    <>
	<div className="about-section-box">
		<div className="container">
			<div className="row">
				<div className="col-lg-6 col-md-6 col-sm-12">
					<img src={window.location.origin + '/storage/' + data.image} alt="image" className="img-fluid"/>
				</div>
				<div className="col-lg-6 col-md-6 col-sm-12 text-center">
					<div className="inner-column">
						<h1>Welcome To <span>{data.title} </span></h1>
						<p>{data.long_description} </p>

					</div>
				</div>
			</div>
		</div>
	</div>
    </>
  )
}

export default About
