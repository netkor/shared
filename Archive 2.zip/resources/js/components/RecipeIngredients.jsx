import axios from "axios";
import React, {Component, Fragment} from "react";
import ReactDOM from "react-dom";

class RecipeIngredients extends Component {
    constructor(props) {
        super(props);
        const units = JSON.parse(props.units);
        const itemIngrident = JSON.parse(props.ingredients);
        const recipe = JSON.parse(props.recipe);


        this.state = {
            products: [],
            itemIngrident: itemIngrident,
            unit_id: "",
            units: units,
            search: "",
            recipe: recipe,
        };

        this.handleChangeSearch = this.handleChangeSearch.bind(this);
        this.handleSeach = this.handleSeach.bind(this);
    }

    componentDidMount() {
        this.loadProducts();
    }

    loadProducts(search = "") {
        const query = !!search ? `?search=${search}` : "";
        axios.get(`/admin/products${query}`).then((res) => {
            const products = res.data.data;
            this.setState({
                products,
            });
        });
    }

    handleChangeSearch(event) {
        const search = event.target.value;
        this.setState({
            search,
        });
    }

    handleSeach(event) {
        if (event.keyCode === 13) {
            this.loadProducts(event.target.value);
        }
    }

    addProductToList(ingredientId) {

        let product = this.state.products.find((p) => p.id === ingredientId);

        if (!!product) {
            // if product is already in inventory_product

            let itemIngrident = this.state.itemIngrident.find(
                (item) => item.product_id === product.id
            );

            if (!!itemIngrident) {
                Swal.fire("Error!", "item is already in recipe", "error");
            } else {
                this.setState({
                    itemIngrident: [
                        ...this.state.itemIngrident, {
                            product_id: product.id,
                            menu_id: this.state.recipe.id,
                            name: product.name,
                            quantity: null,
                            units: product.units,
                            unit_id: null,
                        },
                    ],
                });
            }
        }
    }

    handelSubmitButton(itemIngrident) {
        axios
            .post(`/admin/menu/${this.state.recipe.id}/ingredients`,
                {data: itemIngrident}
            ).then((res) => {
            Swal.fire("Success!", "item added successfully", "success");

            window.location.href = `/admin/menus/${this.state.recipe.id}`;

        }).catch((err) => {
            Swal.fire("Error!", "item not added", "error");
        });
    }

    render() {
        const {products, itemIngrident, units, recipe} = this.state;
        return (
            <Fragment>
                <div className="row">
                    <div className="col-md-3 col-lg-6">
                        <h1>Ingredients for {recipe.name}</h1>
                        <div className="user-cart">
                            <div className="container">
                                <table className="table table-striped">
                                    <thead>
                                    <tr>
                                        <th>Product Name</th>
                                        <th>Quantity</th>
                                        <th>Unit</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    {itemIngrident.map((c) => (
                                        <tr key={c.product_id}>
                                            <td>{c.name}</td>
                                            <td>
                                                <input
                                                    type="number"
                                                    className="form-control form-control-sm "
                                                    defaultValue={
                                                        c.quantity
                                                    }
                                                    onChange={
                                                        () =>
                                                            this.setState(
                                                                (
                                                                    prevState
                                                                ) => ({
                                                                    itemIngrident: prevState.itemIngrident.map(
                                                                        (p) => {
                                                                            if (p.product_id === c.product_id) {
                                                                                p.quantity = event.target.value;
                                                                            }
                                                                            return p;

                                                                        }
                                                                    ),
                                                                })
                                                            )
                                                    }
                                                />
                                            </td>
                                            <td>
                                                <select
                                                    className="form-control form-control-sm mr-5"
                                                    defaultValue={
                                                        c.unit_id
                                                    }
                                                    onChange={() =>
                                                        this.setState(
                                                            (prevState) => ({
                                                                itemIngrident:
                                                                    prevState.itemIngrident.map(
                                                                        (p) =>
                                                                            p.product_id ===
                                                                            c.product_id
                                                                                ? {
                                                                                    ...p,
                                                                                    unit_id:
                                                                                    event
                                                                                        .target
                                                                                        .value,
                                                                                }
                                                                                : p
                                                                    ),
                                                            })
                                                        )
                                                    }
                                                    value={
                                                        itemIngrident.unit_id
                                                    }
                                                >
                                                    <option value="">
                                                        Select Unit
                                                    </option>
                                                    {c.units.map((u) => (
                                                        <option key={u.id} value={u.id}> {u.name}</option>
                                                    ))}

                                                </select>
                                            </td>
                                            <td>
                                                <button
                                                    className="btn btn-danger btn-sm"
                                                    onClick={() =>
                                                        this.setState(
                                                            (prevState) => ({
                                                                itemIngrident:
                                                                    prevState.itemIngrident.filter(
                                                                        (p) =>
                                                                            p.product_id !==
                                                                            c.product_id
                                                                    ),
                                                            })
                                                        )
                                                    }
                                                >
                                                    <i className="fas fa-times"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <div className="col-md-3 col-lg-6">
                        <div className="mb-2">
                            <input
                                type="text"
                                className="form-control"
                                placeholder="Search Product..."
                                onChange={this.handleChangeSearch}
                                onKeyDown={this.handleSeach}
                            />
                        </div>
                        <div className="order-product">
                            {products.map((product) => (
                                <div
                                    onClick={() =>
                                        this.addProductToList(product.id)
                                    }
                                    key={product.id}
                                    className="item"
                                >
                                    {/*<img src={product.image} alt=""/>*/}
                                    <button className="btn btn-primary bg-blue">

                                        {product.name}
                                    </button>
                                </div>
                            ))}
                        </div>
                    </div>
                    <div className="col-lg-3 mt-4">
                        <button
                            className="btn btn-primary"
                            disabled={!itemIngrident.length}
                            onClick={() => this.handelSubmitButton(itemIngrident)}
                        >
                            {" "}
                            Makes Recipe{" "}
                        </button>
                    </div>
                </div>
            </Fragment>
        );
    }
}

export default RecipeIngredients;

if (document.getElementById("recipeIngredients")) {
    const element = document.getElementById("recipeIngredients");
    const props = Object.assign({}, element.dataset);
    ReactDOM.render(<RecipeIngredients {...props} />, element);
}
