import React, {Component} from "react";

export default class ItemView extends Component {
    constructor(props) {
        super(props);
        console.log(props);
        this.state = {
            item: {}
        };
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        if (prevProps.item !== this.props.item) {
            this.setState({
                item: this.props.item
            });
        }
    }

    render() {
        return (
            <div className="my-3 flex justify-between">
                <div
                    className="rounded-full h-12 w-12 overflow-hidden shadow-lg drop-shadow-lg filter backdrop:shadow-md">
                    <img className="h-12 w-12 object-cover"
                         loading="lazy"
                         src={
                             "/image/menu/" + this.state.item.id + "/100/100"}
                         alt="pizza"/>
                </div>
                <div className="flex flex-col text-sm font-normal">
                    <span className=""> {this.state.item.name} </span>
                    <span className="mt-1 text-zinc-400">
                    <div className="relative rounded-full w-32 h-[0.55rem] bg-gray-200">
                        <div
                            className={this.state.item.progress < 20
                                ? "absolute rounded-full h-full bg-gradient-to-r from-red-500 to-orange-500"
                                : this.state.item.progress < 40
                                    ? "absolute rounded-full h-full bg-gradient-to-r from-orange-500 to-amber-500"
                                    : this.state.item.progress < 80
                                        ? "absolute rounded-full h-full bg-gradient-to-r from-amber-500 to-yellow-500"
                                        : this.state.item.progress < 80
                                            ? "absolute rounded-full h-full bg-gradient-to-r from-yellow-500 to-lime-500 "
                                            : "absolute rounded-full h-full bg-gradient-to-r from-lime-500 to-green-500"
                            }
                            style={{width: this.state.item.progress + '%'}}>
                        </div>
                    </div>


                    </span>
                </div>
                <div
                    className="text-sm font-normal">{this.state.item.quantity} {this.state.item.quantity > 1 ? "items" : "item"} </div>
            </div>
        );
    }
}
