@extends('layouts.admin')

@section('title', 'Branch List')
@section('content-header', 'Branch List')
@section('content-actions')
<a href="{{route('branches.create')}}" class="btn btn-primary">Add Branch</a>
@endsection
@section('css')
<link rel="stylesheet" href="{{ asset('plugins/sweetalert2/sweetalert2.min.css') }}">
@endsection
@section('content')
<div class="card">
    <div class="card-body">


        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Logo</th>
                    <th>Branch Name</th>
                    <th>Address</th>
                    <th>Phone</th>
                    <th>Email</th>
                    <th>Authorize Employee </th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($branches as $branch)
                <tr>
                    <td>{{$branch->id}}</td>
                    <td>
                        <img width="50" src="{{$branch->getLogoUrl()}}" alt="">
                    </td>
                    <td>{{$branch->name}}</td>
                    <td>{{$branch->address}}</td>
                    <td>{{$branch->phone}}</td>
                    <td>{{$branch->email}}</td>
                    <td>{{$branch->user->full_name}}</td>
                    <td>
                        <a href="{{ route('branches.edit', $branch) }}" class="btn btn-primary"><i
                                class="fas fa-edit"></i></a>
                        <button class="btn btn-danger btn-delete" data-url="{{route('branches.destroy', $branch)}}"><i
                                class="fas fa-trash"></i></button>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
@endsection

@section('js')
<script src="{{ asset('plugins/sweetalert2/sweetalert2.min.js') }}"></script>
<script>
    $(document).ready(function () {
            $(document).on('click', '.btn-delete', function () {
                $this = $(this);
                const swalWithBootstrapButtons = Swal.mixin({
                    customClass: {
                        confirmButton: 'btn btn-success',
                        cancelButton: 'btn btn-danger'
                    },
                    buttonsStyling: false
                })

                swalWithBootstrapButtons.fire({
                    title: 'Are you sure?',
                    text: "Do you really want to delete this Branch?",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, delete it!',
                    cancelButtonText: 'No',
                    reverseButtons: true
                }).then((result) => {
                    if (result.value) {
                        $.post($this.data('url'), {_method: 'DELETE', _token: '{{csrf_token()}}'}, function (res) {
                            $this.closest('tr').fadeOut(500, function () {
                                $(this).remove();
                            })
                        })
                    }
                })
            })
        })
</script>
@endsection
