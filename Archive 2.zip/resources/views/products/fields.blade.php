<div class="form-group">
    <label for="name">Name</label>
    <input type="text" name="name" class="form-control @error('name') is-invalid @enderror"
           id="name" placeholder="Name" value="{{ old('name',$product->name) }}">
    @error('name')
    <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
    @enderror
</div>

<div class="form-group">
    <label for="description">Description</label>
    <textarea name="description" class="form-control @error('description') is-invalid @enderror" id="description"
              placeholder="description">{{ old('description',$product->description) }}</textarea>
    @error('description')
    <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
    @enderror
</div>

<div class="form-group">
    <label for="remaining-stock">Remaining Stock</label>
    <input type="number" name="remaining_stock" class="form-control @error('remaining_stock') is-invalid @enderror"
           id="remaining_stock" placeholder="Remaining Stock"
           value="{{ old('remaining_stock',$product->remaining_stock) }}">
    @error('remaining_stock')
    <span class="invalid-feedback" role="alert"><strong>{{ $message }}</strong></span>
    @enderror
</div>


<div class="row">
{{--    <div class="col-md-4">--}}
{{--        <div class="form-group">--}}
{{--            <label for="image">Image</label>--}}
{{--            <div class="custom-file">--}}
{{--                <input type="file" class="custom-file-input" name="image" id="image">--}}
{{--                <label class="custom-file-label" for="image">Choose file</label>--}}
{{--            </div>--}}
{{--            @error('image')--}}
{{--            <span class="invalid-feedback" role="alert">--}}
{{--                                    <strong>{{ $message }}</strong>--}}
{{--                                </span>--}}
{{--            @enderror--}}
{{--        </div>--}}
{{--    </div>--}}


    <div class="col-md-4">
        <div class="form-group">
            <label for="keeping_unit_id">Unit</label>
            <select class="form-control form-select" aria-label="Default select example" name="keeping_unit_id">
                @foreach ($units as $key=>$unit)
                    <option value="{{ $key }}" @if($selectedUnit==$key) selected @endif>{{ $unit }}</option>
                @endforeach
            </select>
            @error('keeping_unit_id')

            <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
            @enderror
        </div>
    </div>

    <div class="col-md-4">
        <div class="form-group">
            <label for="status">Status</label>
            <select name="status" class="form-control @error('status') is-invalid @enderror"
                    id="status">
                <option value="1" {{ old('status', $product->status) === 1 ? 'selected' : '' }}>Active</option>
                <option value="0" {{ old('status', $product->status) === 0 ? 'selected' : '' }}>Inactive</option>
            </select>
            @error('status')
            <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
            @enderror
        </div>
    </div>
</div>
