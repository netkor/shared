@extends('layouts.admin')

@section('title', 'Store List')
@section('content-header', 'Store List')
@section('content-actions')
    <a href="{{route('inventory.index')}}" class="btn btn-primary">Go To Inventory</a>
@endsection
@section('content')
    <div class="content">
        <div class="clearfix"></div>
        <div class="card">
            <div class="card-header">
                <ul class="nav nav-tabs align-items-end card-header-tabs w-100">
                    <li class="nav-item">
                        <a class="nav-link active" href="{!! url()->current() !!}"><i
                                class="fa fa-list mr-2"></i>Stores List</a>
                    </li>
                    {{--                    @can('recipes.create')--}}
                    {{-- <li class="nav-item">
                        <a class="nav-link" href="{!! route('recipes.create') !!}"><i
                                class="fa fa-plus mr-2"></i>Add Products to Store</a>
                    </li> --}}
                    {{--                    @endcan--}}
                    @include('layouts.right_toolbar', compact('dataTable'))
                </ul>
            </div>
            <div class="card-body">
                @include('store.table')
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
@endsection
