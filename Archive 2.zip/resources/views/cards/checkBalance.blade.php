@extends('layouts.admin')

@section('title', 'Check Balance')

@section('content')
    <div id="qr-scanner"></div>
{{--    <livewire:p-o-s-dash />--}}
@endsection
