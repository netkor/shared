@extends('layouts.admin')

@section('title', 'Update Card')
@section('content-header', 'Update Card')

@section('content')

    <div class="card">
        <div class="card-body">

            <form action="{{ route('cards.update', $card) }}" method="POST" enctype="multipart/form-data">
                @csrf
                @method('PUT')

                <div class="form-group">
                    <label for="card_name">Full Name</label>
                    <input type="text" name="card_name" class="form-control @error('card_name') is-invalid @enderror"
                           id="card_name"
                           placeholder="Card Name" value="{{ old('card_name', $card->card_name) }}">
                    @error('card_name')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                    @enderror
                </div>



                <div class="form-group">
                    <label for="card_address">Card Address</label>
                    <input type="text" name="card_address" class="form-control @error('card_address') is-invalid @enderror" id="phone"
                           placeholder="Card Address" value="{{ old('card_address', $card->card_address) }}">
                    @error('card_address')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                    @enderror
                </div>





                <button class="btn btn-primary" type="submit">Update</button>
            </form>
        </div>
    </div>
@endsection

@section('js')
    <script src="{{ asset('plugins/bs-custom-file-input/bs-custom-file-input.min.js') }}"></script>
    <script>
        $(document).ready(function () {
            bsCustomFileInput.init();
        });
    </script>
@endsection
