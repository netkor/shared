@extends('layouts.admin')

@section('title', 'Create Cash In/Out')
@section('content-header', 'Create Cash In/Out')

@section('content')

    <div class="card">
        <div class="card-body">

            <form action="{{ route('transactions.store') }}" method="POST" enctype="multipart/form-data">
                @csrf

                <div class="form-group">
                    <label for="amount">Amount</label>
                    <input type="text" name="amount" class="form-control @error('amount') is-invalid @enderror"
                        id="amount" placeholder="Amount" value="{{ old('amount') }}">
                    @error('amount')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="note">Transation Note</label>
                    <input type="text" name="note" class="form-control @error('note') is-invalid @enderror"
                        id="note" placeholder="Transation Note" value="{{ old('note') }}">
                    @error('note')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>
                <div class="form-group">
                <label for="transactionable_type">Type</label>
                <select name="transactionable_type" id="transactionable_type" class="form-control @error('transactionable_type') is-invalid @enderror">
                    <option value="">Select Type</option>
                    <option value="Cash In">Cash In</option>
                    <option value="Cash Out">Cash Out</option>
                </select>
                @error('transactionable_type')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                @enderror
            </div>


                    <button class="btn btn-success" type="submit">Submit</button>


            </form>
        </div>
    </div>
@endsection

@section('js')
    <script src="{{ asset('plugins/bs-custom-file-input/bs-custom-file-input.min.js') }}"></script>
    <script>
        $(document).ready(function() {
            bsCustomFileInput.init();
        });
    </script>
@endsection
