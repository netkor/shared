@extends('layouts.admin')

@section('title', 'Staff List')
@section('content-header', 'Staff List')
@section('content-actions')
    <a href="{{route('users.create')}}" class="btn btn-primary">Add Staff</a>
@endsection
@section('css')
    <link rel="stylesheet" href="{{ asset('plugins/sweetalert2/sweetalert2.min.css') }}">
@endsection
@section('content')
    <div class="card">
        <div class="card-body">


            <table class="table">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Staff Name</th>
                    <th>Staff Email</th>
                    <th>Staff Phone</th>
                    <th>Staff Address</th>
                    <th>Staff Role</th>
                    <th>Staff Branch</th>
                    <th>Status</th>
                    <th>Created At</th>
                    <th>Actions</th>
                </tr>
                </thead>
                <tbody>
                @foreach ($users as $user)
                    <tr>
                        <td>{{$user->id}}</td>
                        <td>{{$user->getFullNameAttribute()}}</td>
                        <td>{{$user->email}}</td>
                        <td>{{$user->phone}}</td>
                        <td>{{$user->address}}</td>
                        <td>{{$user->getRoleNames()}}</td>
                        <td>{{$user->currentBranch()?->name}}</td>
                        <td>
                            <span class="right badge badge-{{ $user->status ? 'success' : 'danger' }}">{{$user->status ? 'Active' :
                                'Inactive'}}</span>
                        </td>
                        <td>{{$user->created_at->format('Y-M-j h:i a')}}</td>
                        <td>
                            <a href="{{ route('users.edit', $user) }}" class="btn btn-primary"><i
                                    class="fas fa-edit"></i></a>
                            <button class="btn btn-danger btn-delete" data-url="{{route('users.destroy', $user)}}"><i
                                    class="fas fa-trash"></i></button>
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>

        </div>
    </div>
@endsection

@section('js')
    <script src="{{ asset('plugins/sweetalert2/sweetalert2.min.js') }}"></script>
    <script>
        $(document).ready(function () {
            $(document).on('click', '.btn-delete', function () {
                $this = $(this);
                const swalWithBootstrapButtons = Swal.mixin({
                    customClass: {
                        confirmButton: 'btn btn-success',
                        cancelButton: 'btn btn-danger'
                    },
                    buttonsStyling: false
                })

                swalWithBootstrapButtons.fire({
                    title: 'Are you sure?',
                    text: "Do you really want to delete this user?",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, delete it!',
                    cancelButtonText: 'No',
                    reverseButtons: true
                }).then((result) => {
                    if (result.value) {
                        $.post($this.data('url'), {_method: 'DELETE', _token: '{{csrf_token()}}'}, function (res) {
                            $this.closest('tr').fadeOut(500, function () {
                                $(this).remove();
                            })
                        })
                    }
                })
            })
        })
    </script>
@endsection
