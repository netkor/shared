@extends('layouts.admin')

@section('title', 'Sales Reports')
@section('content-header', 'Sales Reports')
@section('content-actions')
@endsection
@section('css')
    <link rel="stylesheet" href="{{ asset('plugins/sweetalert2/sweetalert2.min.css') }}">
@endsection
@section('content')

    <div class="content">

        <div class="clearfix"></div>
        <div class="row ml-3 mr-3 mb-2">
            <div class="col-md-12">
                <form action="{{ route('dailysalesreport.index') }}">

                    <div class="row">

                        <div class="col-md-2 ">
                            <label for="from">Search By Menu Item</label>

                            <input type="text" placeholder="Enter menu item name" name="menu" class="form-control"
                                value="{{ request()->menu }}">
                        </div>
                        <div class="col-md-2">
                            <label for="from">From</label>
                            <input type="date" name="start_date" class="form-control"
                                value="{{ request('start_date') }}" />
                        </div>
                        <div class="col-md-2">
                            <label for="from">To</label>
                            <input type="date" name="end_date" class="form-control" value="{{ request('end_date') }}" />
                        </div>

                        <div class="col-md-1">
                            <label for="from">Filter</label>
                            <button class="btn btn-outline-success" type="submit">Search</button>
                        </div>
                        <div class="col-md-1">
                            <label for="from">Print Report</label>
                            <button class="btn btn-outline-primary" onclick="window.print();">Print</button>
                        </div>
                        <div class="col-md-1">
                            <label for="from">Reset Search</label>

                            <a href="{{ route('dailysalesreport.index') }}" class="btn btn-outline-danger">Reset</a>
                        </div>




                    </div>


                </form>


            </div>




        </div>

        <table class="table">
            <thead>
                <tr>
                    <th>Menu</th>
                    <th>Quantity</th>
                    <th>Price</th>
                    <th>Total</th>
                    <th>Date</th>


                </tr>
            </thead>
            <tbody>
                @foreach ($ordersItem as $item)
                    <tr>
                        <td>{{ $item->menu->name }}</td>
                        <td>{{ $item->quantity }}</td>
                        <td>{{ config('settings.currency_symbol') }} {{ $item->menu->price }}</td>
                        <td>{{ config('settings.currency_symbol') }} {{ $item->menu->price * $item->quantity }}</td>
                        <td>{{ $item->created_at->format('d-M-Y h:m a') }}</td>
                    </tr>
                @endforeach
            </tbody>
            <tfoot>
                <tr>
                    <th></th>
                    <th>Total Qty= {{ $totalQuantity }}</th>
                    <th></th>
                    <th>{{ config('settings.currency_symbol') }} {{ $totalAmount }}</th>
                    <th></th>

                </tr>
            </tfoot>
        </table>
    </div>

    </div>

@endsection
