@extends('layouts.admin')

@section('title', 'Assign Product  to inventory')
@section('content-header', 'Assign Product To Inventory')

@section('content')

    <div class="card">
        <div class="card-body">
            <div id="inventory" data-inventory="{{ $inventory }}" data-units="{{ $units }}" data-vendors="{{ $vendors }}">

            </div>
        </div>
    </div>
@endsection

