@extends('layouts.admin')

@section('title', 'Create Website')
@section('content-header', 'Create Website')

@section('content')

    <div class="card">
        <div class="card-body">

            <form action="{{ route('website.store') }}" method="POST" enctype="multipart/form-data">
                @csrf
                <div class="row">
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="title">Title</label>
                            <input type="text" name="title" class="form-control @error('title') is-invalid @enderror"
                                id="title" placeholder="Title of Site" value="{{ old('title') }}">
                            @error('title')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="title">Email</label>
                            <input type="email" name="email" class="form-control @error('email') is-invalid @enderror"
                                id="email" placeholder="email" value="{{ old('email') }}">
                            @error('title')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="phone">Phone</label>
                            <input type="phone" name="phone" class="form-control @error('phone') is-invalid @enderror"
                                id="phone" placeholder="phone" value="{{ old('phone') }}">
                            @error('phone')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="address"> Address</label>
                            <input type="text" name="address" class="form-control @error('address') is-invalid @enderror"
                                id="address" placeholder="Branch address" value="{{ old('address') }}">
                            @error('address')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>

                </div>



                <div class="row">
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="short_description">Description</label>
                            <textarea name="short_description" class="form-control @error('short_description') is-invalid @enderror"
                                id="short_description" placeholder="short_description">{{ old('short_description') }}</textarea>
                            @error('short_description')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>

                    </div>

                    <div class="col-md-5">
                        <div class="form-group">
                            <label for="long_description">Long Description</label>
                            <textarea name="long_description" class="form-control @error('long_description') is-invalid @enderror"
                                id="long_description" placeholder="Long Description">{{ old('long_description') }}</textarea>
                            @error('long_description')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>

                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="image">Image</label>
                            <div class="custom-file">
                                <input type="file" class="custom-file-input" name="image" id="image">
                                <label class="custom-file-label" for="image">Choose file</label>
                            </div>
                            @error('image')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>

                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="logo">Logo</label>
                            <div class="custom-file">
                                <input type="file" class="custom-file-input" name="logo" id="logo">
                                <label class="custom-file-label" for="logo">Choose file</label>
                            </div>
                            @error('logo')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="slider1">slider 1</label>
                            <div class="custom-file">
                                <input type="file" class="custom-file-input" name="slider1" id="slider1">
                                <label class="custom-file-label" for="slider1">Choose file</label>
                            </div>
                            @error('slider1')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="slider2">slider 2</label>
                            <div class="custom-file">
                                <input type="file" class="custom-file-input" name="slider2" id="slider2">
                                <label class="custom-file-label" for="slider2">Choose file</label>
                            </div>
                            @error('slider2')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="slider3">slider 3</label>
                            <div class="custom-file">
                                <input type="file" class="custom-file-input" name="slider3" id="slider3">
                                <label class="custom-file-label" for="slider3">Choose file</label>
                            </div>
                            @error('slider3')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6">
                         <div class="form-group">
                            <label for="close_time">Close Day with time</label>
                            <input type="text" name="close_time" class="form-control @error('close_time') is-invalid @enderror"
                                id="close_time" placeholder="close time" value="{{ old('close_time') }}">
                            @error('close_time')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>
                    <div class="col-md-6">
                         <div class="form-group">
                            <label for="open_time">Open Day With Time</label>
                            <input type="text" name="open_time" class="form-control @error('open_time') is-invalid @enderror"
                                id="open_time" placeholder="opening time" value="{{ old('open_time') }}">
                            @error('open_time')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>
                </div>

















                <button class="btn btn-primary" type="submit">Create</button>
            </form>
        </div>
    </div>
@endsection

@section('js')
    <script src="{{ asset('plugins/bs-custom-file-input/bs-custom-file-input.min.js') }}"></script>
    <script>
        $(document).ready(function() {
            bsCustomFileInput.init();
        });
    </script>
@endsection
