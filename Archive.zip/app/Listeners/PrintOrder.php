<?php

namespace App\Listeners;

class PrintOrder
{


    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param object $event
     * @return void
     */
    public function handle($event)
    {
        $carts = $event->carts;
        $printed_date = date('M d, Y h:i:s');
        $group = $carts->first()->group;
        $table = $carts->first()->table->name;
        $user = auth()->user()->first_name;
        $branch = auth()->user()->currentBranch()->name;

//        $data = collect([
//            'table' => $table,
//            'group' => $group,
//            'printed_date' => $printed_date,
//            'items' => $carts->map(function ($cart) {
//                return collect([
//                    'description' => $cart->menu->name,
//                    'qty' => $cart->quantity
//                ]);
//            })
//        ]);


//        try {
//            $connector = new NetworkPrintConnector("192.168.1.100", 9100);
//            $printer = new Printer($connector);
//            $printer->selectPrintMode(Printer::MODE_FONT_B);
//
//            $printer->text("$table\n");
//            $printer->setFont(Printer::FONT_C);
//            $printer->text("#$group\n");
//            $printer->text("$printed_date\n");
//            $printer->text("Description      QTY\n");
//            foreach ($carts as $cart) {
//                $printer->text("{$cart->menu->name} x {$cart->quantity}\n");
//            }
//            $printer->text("Served by: $user , $branch\n");
//            $printer->feed(1);
//            $printer->cut();
//            $printer->feedReverse(2);
//
//            /* Close printer */
//            $printer->close();
//        } catch (Exception $e) {
//        }

    }


}
