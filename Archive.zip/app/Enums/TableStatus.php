<?php

namespace App\Enums;

enum TableStatus: string
{
    case OPEN = 'open';
    case CLOSE = 'close';
    case RESERVED = 'reserved';
    case HOLD = 'hold';
    case OCCUPIED = 'occupied';

    public function html(): string
    {
        return match ($this) {
            TableStatus::OPEN => '<span class="px-2 py-0.5 rounded-[0.25rem] text-white font-medium bg-emerald-500 text-[0.75rem]">' . $this::title() . '</span>',
            TableStatus::CLOSE => '<span class="px-2 py-0.5 rounded-[0.25rem] text-white font-medium bg-amber-500 text-[0.75rem]">' . $this::title() . '</span>',
            TableStatus::RESERVED, TableStatus::HOLD, TableStatus::OCCUPIED => '<span class="px-2 py-0.5 rounded-[0.25rem] text-white font-medium bg-rose-500 text-[0.75rem]">' . $this::title() . '</span>',
        };

    }

    public function title(): string
    {
        return match ($this) {
            TableStatus::OPEN => 'Open',
            TableStatus::CLOSE => 'Close',
            TableStatus::RESERVED => 'Reserved',
            TableStatus::HOLD => 'Hold',
            TableStatus::OCCUPIED => 'Occupied',
            default => 'Unknown',
        };
    }


}
