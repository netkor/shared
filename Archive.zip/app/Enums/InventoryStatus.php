<?php

namespace App\Enums;

enum InventoryStatus: int
{
    case ACTIVE = 1;
    case INACTIVE = 2;
    case PENDING = 3;
    case DELETED = 4;


    public function html(): string
    {
        return match ($this) {
            InventoryStatus::ACTIVE => '<span class="px-2 py-0.5 rounded-[0.25rem] text-white font-medium bg-emerald-500 text-[0.75rem]">' . $this::title() . '</span>',
            InventoryStatus::INACTIVE => '<span class="px-2 py-0.5 rounded-[0.25rem] text-white font-medium bg-amber-500 text-[0.75rem]">' . $this::title() . '</span>',
            InventoryStatus::PENDING => '<span class="px-2 py-0.5 rounded-[0.25rem] text-white font-medium bg-rose-500 text-[0.75rem]">' . $this::title() . '</span>',
            InventoryStatus::DELETED => '<span class="px-2 py-0.5 rounded-[0.25rem] text-white font-medium bg-gray-500 text-[0.75rem]">' . $this::title() . '</span>',
        };
    }

    public function title(): string
    {
        return match ($this) {
            InventoryStatus::ACTIVE => 'Active',
            InventoryStatus::INACTIVE => 'Inactive',
            InventoryStatus::PENDING => 'Pending',
            InventoryStatus::DELETED => 'Deleted',
        };
    }


}
