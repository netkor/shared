<?php

namespace App\Enums;

enum AccountStatus: string
{
    case ACTIVE = 'active';
    case INACTIVE = 'inactive';
    case SUSPENDED = 'suspended';
    case PENDING = 'pending';
    case DELETED = 'deleted';

    public function html(): string
    {
        return match ($this) {
            AccountStatus::ACTIVE => '<span class="px-2 py-0.5 rounded-[0.25rem] text-white font-medium bg-emerald-500 text-[0.75rem]">' . $this::title() . '</span>',
            AccountStatus::INACTIVE => '<span class="px-2 py-0.5 rounded-[0.25rem] text-white font-medium bg-amber-500 text-[0.75rem]">' . $this::title() . '</span>',
            AccountStatus::SUSPENDED, AccountStatus::PENDING => '<span class="px-2 py-0.5 rounded-[0.25rem] text-white font-medium bg-rose-500 text-[0.75rem]">' . $this::title() . '</span>',
            AccountStatus::DELETED => '<span class="px-2 py-0.5 rounded-[0.25rem] text-white font-medium bg-gray-500 text-[0.75rem]">' . $this::title() . '</span>',
        };
    }

    public function title(): string
    {
        return match ($this) {
            AccountStatus::ACTIVE => 'Active',
            AccountStatus::INACTIVE => 'Inactive',
            AccountStatus::SUSPENDED => 'Suspended',
            AccountStatus::PENDING => 'Pending',
            AccountStatus::DELETED => 'Deleted',
        };
    }

}
