<?php

namespace App\Enums;

enum TransactionStatus: string
{
    case COMPLETED = 'completed';
    case PENDING = 'pending';
    case REJECTED = 'rejected';
    case FAILED = 'failed';
    case null = 'null';

    public function html(): string
    {
        return match ($this) {
            TransactionStatus::COMPLETED => '<span class="px-2 py-0.5 rounded-[0.25rem] text-white font-medium bg-emerald-500 text-[0.75rem]">' . $this::title() . '</span>',
            TransactionStatus::PENDING => '<span class="px-2 py-0.5 rounded-[0.25rem] text-white font-medium bg-amber-500 text-[0.75rem]">' . $this::title() . '</span>',
            TransactionStatus::REJECTED, TransactionStatus::FAILED => '<span class="px-2 py-0.5 rounded-[0.25rem] text-white font-medium bg-rose-500 text-[0.75rem]"">' . $this::title() . '</span>',
            default => '<span class="px-2 py-0.5 rounded-[0.25rem] text-white font-medium bg-rose-500 text-[0.75rem]"">Failed</span>',
            //                                    return '<span class=" badge bg-green-500">' . Str::title($data->status) . '</span>';

        };
    }

    public function title(): string
    {
        return match ($this) {
            TransactionStatus::COMPLETED => 'Completed',
            TransactionStatus::PENDING => 'Pending',
            TransactionStatus::REJECTED => 'Rejected',
            TransactionStatus::FAILED => 'Failed',
            default => 'Failed',
        };
    }
}
