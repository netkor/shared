<?php

namespace App\DataTables;

use App\Models\Store;
use Illuminate\Database\Eloquent\Builder as QueryBuilder;
use Illuminate\Support\Str;
use Yajra\DataTables\EloquentDataTable;
use Yajra\DataTables\Html\Builder;
use Yajra\DataTables\Html\Column;
use Yajra\DataTables\Services\DataTable;

class StoreDataTable extends DataTable
{
    /**
     * Build DataTable class.
     *
     * @param QueryBuilder $query Results from query() method.
     * @return EloquentDataTable
     */
    public function dataTable(QueryBuilder $query): EloquentDataTable
    {
        $dataTable = new EloquentDataTable($query);
        $columns = array_column($this->getColumns(), 'data');
        return $dataTable
            ->editColumn('price', function ($store) {
                return 'Rs. ' . $store->price->price;
            })
            ->editColumn('created_at', function ($store) {
                return $store->created_at->format('jS F Y');
            })
            ->editColumn('updated_at', function ($store) {
                return $store->updated_at->format('jS F Y');
            })
            ->editColumn('type', function ($store) {
                return Str::of($store->type)->ucfirst();
            })
            ->addColumn('action', 'store.action')
            ->rawColumns(array_merge($columns, ['action', 'price']));
    }

    /**
     * Get columns.
     *
     * @return array
     */
    protected function getColumns(): array
    {
        return [
//            Column::computed('action')
//                ->exportable(false)
//                ->printable(false)
//                ->width(60)
//                ->addClass('text-center'),
//            Column::make('id'),
            Column::make('product.name'),
            Column::make('inventory.batch_no'),
            Column::make('stock'),
            Column::make('unit.name'),
            Column::make('type'),
            Column::make('price')
                ->title('Price')
                ->defaultContent('-'),
            Column::make('created_at'),
            Column::make('updated_at'),
        ];
    }

    /**
     * Get query source of dataTable.
     *
     * @param Store $model
     * @return QueryBuilder
     */
    public function query(Store $model): QueryBuilder
    {
        return $model
            ->select('stores.*')
            ->with('product')
            ->with('inventory')
            ->with('price')
            ->with('unit');
    }

    /**
     * Optional method if you want to use html builder.
     *
     * @return Builder
     */
    public function html()
    {
        return $this->builder()
            ->columns($this->getColumns())
            ->minifiedAjax()
            ->addAction(['width' => '80px', 'printable' => false, 'responsivePriority' => '100'])
            ->parameters(array_merge(
                config('datatables-buttons.parameters'),
                [
                    'language' => json_decode(
                        file_get_contents(
                            base_path('resources/lang/' . app()->getLocale() . '/datatable.json')
                        ),
                        true
                    ),
                ]
            ));
    }

    /**
     * Get filename for export.
     *
     * @return string
     */
    protected function filename(): string
    {
        return 'Store_' . date('YmdHis');
    }
}
