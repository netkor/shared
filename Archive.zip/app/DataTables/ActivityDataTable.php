<?php

namespace App\DataTables;

use App\Models\Activity;
use Illuminate\Database\Eloquent\Builder as QueryBuilder;
use Illuminate\Support\Str;
use Yajra\DataTables\EloquentDataTable;
use Yajra\DataTables\Html\Builder;
use Yajra\DataTables\Html\Column;
use Yajra\DataTables\Services\DataTable;

class ActivityDataTable extends DataTable
{
    /**
     * Build DataTable class.
     *
     * @param QueryBuilder $query Results from query() method.
     * @return EloquentDataTable
     */
    public function dataTable(QueryBuilder $query): EloquentDataTable
    {
        $columns = array_column($this->getColumns(), 'data');
        return (new EloquentDataTable($query))
            ->editColumn('created_at', function ($activity) {
                return $activity->created_at->format('jS F Y');
            })
            ->editColumn('updated_at', function ($activity) {
                return $activity->updated_at->format('jS F Y');
            })
            ->editColumn('properties', function ($activity) {
                return '<pre><code class="language-json">' . json_encode($activity->properties, JSON_PRETTY_PRINT) . '</code></pre>';
            })
            ->editColumn('subject_type', function ($activity) {
                return Str::of($activity->subject_type)->ucfirst();
            })
            ->addColumn('action', 'activity.action')
            ->rawColumns(array_merge($columns, ['action', 'properties']));

    }

    /**
     * Get columns.
     *
     * @return array
     */
    protected function getColumns(): array
    {
        return [
            Column::make('id')->hidden(),
            Column::make('description'),
            Column::make('subject_type'),
            Column::make('causer.first_name'),
            Column::make('properties')->searchable(false)->orderable(false),
            Column::make('created_at'),
            Column::make('updated_at'),
        ];
    }

    /**
     * Get query source of dataTable.
     *
     * @param Activity $model
     * @return QueryBuilder
     */
    public function query(Activity $model): QueryBuilder
    {
        return $model->newQuery()
//            ->select('activities.*')
            ->with('causer')
            ->orderBy('created_at', 'desc');
    }

    /**
     * Optional method if you want to use html builder.
     *
     * @return Builder
     */
    public function html()
    {
        return $this->builder()
            ->columns($this->getColumns())
            ->minifiedAjax()
            ->addAction(['width' => '80px', 'printable' => false, 'responsivePriority' => '100'])
            ->parameters(array_merge(
                config('datatables-buttons.parameters'),
                [
                    'language' => json_decode(
                        file_get_contents(
                            base_path('resources/lang/' . app()->getLocale() . '/datatable.json')
                        ),
                        true
                    ),
                ]
            ));
    }

    /**
     * Get filename for export.
     *
     * @return string
     */
    protected function filename(): string
    {
        return 'Activity_' . date('YmdHis');
    }
}
