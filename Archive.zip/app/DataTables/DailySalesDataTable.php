<?php

namespace App\DataTables;

use App\Models\Cart;
use App\Models\OrderItem;
use Illuminate\Database\Eloquent\Builder as QueryBuilder;
use Yajra\DataTables\EloquentDataTable;
use Yajra\DataTables\Html\Builder as HtmlBuilder;
use Yajra\DataTables\Html\Column;
use Yajra\DataTables\Html\SearchPane;
use Yajra\DataTables\Services\DataTable;

class DailySalesDataTable extends DataTable
{
    /**
     * Build DataTable class.
     *
     * @param QueryBuilder $query Results from query() method.
     * @return EloquentDataTable
     */
    public function dataTable(QueryBuilder $query): EloquentDataTable
    {
        return (new EloquentDataTable($query))
        //edit column menu id with menu name

            ->editColumn('menu_id', function ($order) {
                return $order->menu->name;
            })
            ->editColumn('created_at', function ($order) {
                return $order->created_at->format('d-M-Y h:i A');
            })
            ->editColumn('price', function ($order) {
                return 'Rs ' . number_format($order->menu->price, 2);
            })
            ->editColumn('total', function ($order) {
                return 'Rs ' .
            number_format($order->quantity * $order->menu->price,2);
            })

            ->startsWithSearch(false)
            ->setMultiTerm(true)


            ->rawColumns(['menu', 'price', 'total']);





    }

    /**
     * Get query source of dataTable.
     *
     * @param OrderItem $model
     * @return QueryBuilder
     */
    public function query(OrderItem $model): QueryBuilder
    {


        return $model
        //search by menu name
            ->orderBy('created_at', 'desc')
            // ->withoutGlobalScope(UserBranch::class)
            ->newQuery();
    }

    /**
     * Optional method if you want to use html builder.
     *
     * @return HtmlBuilder
     */
    public function html(): HtmlBuilder
    {
        return $this->builder()
            ->columns($this->getColumns())
            ->minifiedAjax()
            ->searchPanes(SearchPane::make())
            ->parameters(array_merge(
                config('datatables-buttons.parameters'),
                [
                    'language' => json_decode(
                        file_get_contents(
                            base_path('resources/lang/' . app()->getLocale() . '/datatable.json')
                        ),
                        true
                    ),
                ]
            ));
    }

    /**
     * Get columns.
     *
     * @return array
     */
    protected function getColumns(): array
    {
        return [

            Column::make('menu_id')->title('Menu')->width('20%'),
            Column::make('quantity')->title('Quantity')->width('20%'),
            Column::make('price')->title('Price')->width('20%'),
            Column::make('total')->title('Total')->width('20%'),
            Column::make('created_at')->title('Created At')->width('20%'),
        ];
    }

    /**
     * Get filename for export.
     *
     * @return string
     */
    protected function filename(): string
    {
        return 'Reports_ ' . date('YmdHis');
    }


}
