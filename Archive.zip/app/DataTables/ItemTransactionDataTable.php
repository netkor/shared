<?php

namespace App\DataTables;

use App\Models\ItemTransaction;
use Illuminate\Database\Eloquent\Builder as QueryBuilder;
use Yajra\DataTables\EloquentDataTable;
use Yajra\DataTables\Html\Builder as HtmlBuilder;
use Yajra\DataTables\Html\Column;
use Yajra\DataTables\Html\SearchPane;
use Yajra\DataTables\Services\DataTable;

class ItemTransactionDataTable extends DataTable
{

    public function dataTable(QueryBuilder $query): EloquentDataTable
    {
        return (new EloquentDataTable($query))
            ->editColumn('created_at', function (ItemTransaction $transaction) {
                return $transaction?->created_at->format('d/m/Y h:i a');
            })
            ->editColumn('quantity', function (ItemTransaction $transaction) {
                if ($transaction->quantity > 0) {
                    return "<span class='bg-green-500 text-white text-[0.7rem] rounded-lg font-semibold px-2 py-1'>" . $transaction->quantity . ' ' . $transaction->unit?->symbol . '</span>';
                }
                return "<span class='bg-red-500 text-white text-[0.7rem] rounded-lg font-semibold px-2 py-1'>" . $transaction->quantity . '  ' . $transaction->unit?->symbol . '</span>';
            })
            ->editColumn('stock', function (ItemTransaction $transaction) {
                return $transaction?->stock . ' ' . $transaction->unit?->symbol;
            })
            ->startsWithSearch(false)
            ->setMultiTerm(true)


            //            ->searchPane('amount', ['attributes' => ['placeholder' => 'Search by Reference Code']])
            ->rawColumns(['quantity', 'stock']);
    }

    public function html(): HtmlBuilder
    {
        return $this->builder()
            ->columns($this->getColumns())
            ->minifiedAjax()
            ->searchPanes(SearchPane::make())
            ->parameters(array_merge(
                config('datatables-buttons.parameters'),
                [
                    'language' => json_decode(
                        file_get_contents(
                            base_path('resources/lang/' . app()->getLocale() . '/datatable.json')
                        ),
                        true
                    ),
                ]
            ));
    }

    /**
     * Get columns.
     *
     * @return array
     */
    protected function getColumns(): array
    {
        return [
            Column::make('ref_no')->width('20%'),
            Column::make('quantity')->width('10%'),
            Column::make('note')->width('20%'),
            Column::make('stock')->width('20%'),
            Column::make('created_at')->width('20%'),
        ];
    }


    public function query(ItemTransaction $model): QueryBuilder
    {
        return $model
            ->with('unit')
//            ->when(auth()->user()->currentBranch()?->id, fn($query) => $query->where('transactionable_id', auth()->user()->currentBranch()->id))
//            ->where('transactionable_type', 'branch')
            ->orderBy('created_at', 'desc')
//            ->withoutGlobalScope(UserBranch::class)
            ->newQuery();
    }

    /**
     * Get filename for export.
     *
     * @return string
     */
    protected function filename(): string
    {
        return 'Transcation_ ' . date('YmdHis');
    }
}
