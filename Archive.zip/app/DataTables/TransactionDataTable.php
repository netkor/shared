<?php

namespace App\DataTables;

use App\Enums\TransactionStatus;
use App\Models\Scopes\UserBranch;
use App\Models\Transaction;
use Illuminate\Database\Eloquent\Builder as QueryBuilder;
use Yajra\DataTables\EloquentDataTable;
use Yajra\DataTables\Html\Builder as HtmlBuilder;
use Yajra\DataTables\Html\Column;
use Yajra\DataTables\Html\SearchPane;
use Yajra\DataTables\Services\DataTable;

class TransactionDataTable extends DataTable
{
    /**
     * Build DataTable class.
     *
     * @param QueryBuilder $query Results from query() method.
     * @return EloquentDataTable
     */
    public function dataTable(QueryBuilder $query): EloquentDataTable
    {
        return (new EloquentDataTable($query))
            ->editColumn('transactionable_type', function (Transaction $transaction) {
                return "<a href=" . $transaction?->transactionable->url() . " target='_blank'>" . str($transaction->transactionable_type)->ucfirst() . "::" . $transaction->transactionable->label() . "</a>";
            })
            ->editColumn('created_at', function (Transaction $transaction) {
                return $transaction?->created_at->format('d/m/Y h:i a');
            })
            ->editColumn('amount', function (Transaction $transaction) {
                return getFormatedAmount($transaction?->amount);
            })

            ->editColumn('balance', function (Transaction $transaction) {
                return 'Rs ' . $transaction?->balance;
            })

            ->startsWithSearch(false)
            ->setMultiTerm(true)


            //            ->searchPane('amount', ['attributes' => ['placeholder' => 'Search by Reference Code']])
            ->rawColumns(['transactionable_type', 'amount', 'balance', 'status']);
    }

    /**
     * Optional method if you want to use html builder.
     *
     * @return HtmlBuilder
     */
    public function html(): HtmlBuilder
    {
        return $this->builder()
            ->columns($this->getColumns())
            ->minifiedAjax()
            ->searchPanes(SearchPane::make())
            ->parameters(array_merge(
                config('datatables-buttons.parameters'),
                [
                    'language' => json_decode(
                        file_get_contents(
                            base_path('resources/lang/' . app()->getLocale() . '/datatable.json')
                        ),
                        true
                    ),
                ]
            ));
    }

    /**
     * Get columns.
     *
     * @return array
     */
    protected function getColumns(): array
    {
        return [
            Column::make('ref_code')->width('20%'),
            Column::make('amount')->width('10%'),
            Column::make('transactionable_type')->title('Title')->width('20%'),
            Column::make('note')->width('20%'),
            Column::make('balance')->width('20%'),
            Column::make('created_at')->width('20%'),
        ];
    }

    /**
     * Get query source of dataTable.
     *
     * @param Transaction $model
     * @return QueryBuilder
     */
    public function query(Transaction $model): QueryBuilder
    {
        return $model
            ->with('transactionable')
            ->when(auth()->user()->currentBranch()?->id, fn($query) => $query->where('transactionable_id', auth()->user()->currentBranch()->id))
//            ->where('transactionable_type', 'branch')
            ->orderBy('created_at', 'desc')
            ->withoutGlobalScope(UserBranch::class)
            ->newQuery();
    }

    /**
     * Get filename for export.
     *
     * @return string
     */
    protected function filename(): string
    {
        return 'Transcation_ ' . date('YmdHis');
    }
}
