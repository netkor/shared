<?php

namespace App\DataTables\Scopes;

use Illuminate\Database\Eloquent\Builder;
use Yajra\DataTables\Contracts\DataTableScope;

class SubjectActivities implements DataTableScope
{
    public function __construct(protected string $subjectType, protected string $subjectId)
    {
    }


    /**
     * Apply a query scope.
     *
     * @param \Illuminate\Database\Query\Builder|Builder $query
     * @return mixed
     */
    public function apply($query)
    {
        return $query->where('subject_type', $this->subjectType)
            ->where('subject_id', $this->subjectId);
    }
}
