<?php

namespace App\Pipelines;

use Closure;
use Illuminate\Pipeline\Pipeline;

class TraverseChildPipeline extends Pipeline
{
    public function handle($model, Closure $next)
    {
        if ($model->unit->children->count() && !$model->unit->parent_id) {
            $model->unit = $model->unit->children->first();
            $model->conversion_factor = $model->conversion_factor / $model->unit->conversion_factor;
            $model = $this->handle($model, $next);
        }

        return $next($model);
    }


}
