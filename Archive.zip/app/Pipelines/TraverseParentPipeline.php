<?php

namespace App\Pipelines;

use Closure;
use Illuminate\Pipeline\Pipeline;

class TraverseParentPipeline extends Pipeline
{
    public function handle($model, Closure $next)
    {
        if ($model->unit->parent_id) {
            if ($model->unit->parent->conversion_factor) {
                $model->conversion_factor = $model->conversion_factor * $model->unit->parent->conversion_factor;
            }
            $model->unit = $model->unit->parent;
            $model = $this->handle($model, $next);
        }

        return $next($model);
    }
}

