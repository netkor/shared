<?php

namespace App\DTO;

use App\Models\Unit;

class UnitConversionDTO
{
    public float $conversion_factor;

    public function __construct(public Unit $unit)
    {
        $this->conversion_factor = $this->unit->conversion_factor;
    }

    public function convert($volume, $productUnit)
    {
        if ($this->unit->id == $productUnit->id) {
            return $volume;
        }

        if ($this->unit->hierarchy < $productUnit->hierarchy) {
            $volume = $volume / $this->unit->conversion_factor;
            $this->unit = $this->unit->parent;
        }

        if ($this->unit->hierarchy > $productUnit->hierarchy) {
            $volume = $volume * $productUnit->conversion_factor;
            $productUnit = $productUnit->parent;
        }

        if ($productUnit->parent_id == null) {
            $volume = $volume * $productUnit->conversion_factor;
            return $volume;
        }

        if ($this->unit->parent_id == null) {
            $volume = $volume / $this->unit->conversion_factor;
            return $volume;
        }

        return $this->convert($volume, $productUnit);

    }

}
