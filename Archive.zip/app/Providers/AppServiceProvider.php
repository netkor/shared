<?php

namespace App\Providers;

use App\Models\Branch;
use App\Models\Card;
use App\Models\Cart;
use App\Models\Category;
use App\Models\Customer;
use App\Models\Ingredient;
use App\Models\Inventory;
use App\Models\Menu;
use App\Models\Order;
use App\Models\Payment;
use App\Models\Price;
use App\Models\Product;
use App\Models\Role;
use App\Models\Setting;
use App\Models\Stock;
use App\Models\Store;
use App\Models\Table;
use App\Models\Tag;
use App\Models\Tenant;
use App\Models\Transaction;
use App\Models\Type;
use App\Models\User;
use App\Models\Variant;
use App\Models\Vendor;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\Relation;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\ServiceProvider;
use Spatie\Permission\Models\Permission;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        Schema::defaultStringLength(191);

        if (!$this->app->runningInConsole()) {
            // 'key' => 'value'
            $settings = Setting::all('key', 'value')
                ->keyBy('key')
                ->transform(function ($setting) {
                    return $setting->value;
                })
                ->toArray();
            config([
                'settings' => $settings
            ]);

            config(['app.name' => config('settings.app_name')]);
        }


        Model::shouldBeStrict(false);

        Paginator::useBootstrap();

        Relation::requireMorphMap();

        Relation::morphMap([
            'branch' => Branch::class,
            'card' => Card::class,
            'cart' => Cart::class,
            'category' => Category::class,
            'customer' => Customer::class,
            'ingredient' => Ingredient::class,
            'inventory' => Inventory::class,
            'menu' => Menu::class,
            'order' => Order::class,
            'payment' => Payment::class,
            'permission' => Permission::class,
            'price' => Price::class,
            'product' => Product::class,
            'role' => Role::class,
            'stock' => Stock::class,
            'store' => Store::class,
            'table' => Table::class,
            'tag' => Tag::class,
            'tenant' => Tenant::class,
            'transaction' => Transaction::class,
            'type' => Type::class,
            'user' => User::class,
            'variant' => Variant::class,
            'vendor' => Vendor::class,
        ]);

    }
}
