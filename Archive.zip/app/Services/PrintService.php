<?php

namespace App\Services;

use App\EPOS\ReceiptPrinter;
use Exception;
use Illuminate\Support\Facades\Log;

class PrintService
{
    public function __construct(protected string $printerName)
    {
    }

    public function print(array $data): void
    {
        $store_name = $data['title'];
        $store_address = 'Damak, Jhapa';
        $store_phone = '023-583229';
        $store_email = '';
        $transaction_id = $data['order_no'];
        $currency = 'NPR ';

        try {
            $printer = new ReceiptPrinter();
            $printer->init('windows', $this->printerName);
            $printer->setStore('1', $store_name, $store_address, $store_phone, $store_email, $currency);
            $printer->setCurrency($currency);

            foreach ($data['items'] as $item) {
                $printer->addItem($item['name'], $item['qty'], $item['price']);
            }

            $printer->calculateSubTotal();
            $printer->calculateDiscount($data['discount_amount']);
            $printer->calculateGrandTotal();
            $printer->setTransactionID($transaction_id);
            $printer->printReceipt();
        } catch (Exception $e) {
            Log::alert($e->getMessage());
        }
    }

}
