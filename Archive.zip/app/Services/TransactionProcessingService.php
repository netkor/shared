<?php

namespace App\Services;

use App\Contracts\CashTransactionContract;
use App\Exceptions\TransactionProcessingException;
use Exception;

class TransactionProcessingService
{
    /**
     * @throws TransactionProcessingException
     */
    public function process(CashTransactionContract $model, float $amount, string $source, string $description, string $ref_code, $parent_id = null)
    {
        try {
            $transaction = $model->transactions()->create([
                'amount' => $amount,
                'source' => $source,
                'balance' => $model->balance() + $amount,
                'status' => 'success',
                'ref_code' => $ref_code,
                'parent_id' => $parent_id,
                'description' => $description,
            ]);
        } catch (Exception $e) {
            throw new TransactionProcessingException($e->getMessage());
        }

        return $transaction;
    }

}
