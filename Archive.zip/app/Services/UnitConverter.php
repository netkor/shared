<?php

namespace App\Services;

class UnitConverter
{
    public function __construct(protected $fromUnit, protected $toUnit)
    {
    }

    public function convert($volume)
    {
        if ($this->fromUnit == null || $this->toUnit == null) {
            return $volume;
        }

        if ($this->fromUnit->id == $this->toUnit->id) {
            return $volume;
        }

        if ($this->toUnit->parent_id) {
            $volume = $volume * $this->toUnit->conversion_factor;
            $this->toUnit = $this->toUnit->parent;
            return $this->convert($volume);
        }

        if ($this->fromUnit->parent_id) {
            $volume = $volume / $this->fromUnit->conversion_factor;
            $this->fromUnit = $this->fromUnit->parent;
            return $this->convert($volume);
        }

    }


}
