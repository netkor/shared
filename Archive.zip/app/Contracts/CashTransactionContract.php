<?php

namespace App\Contracts;

interface CashTransactionContract
{
    /**
     * Get all the transactions for the model.
     */
    public function transactions();

    /**
     * Get the latest transaction for the model.
     */
    public function transaction();

    /**
     * Get the latest balance for the model.
     */
    public function balance(): float;

    /**
     * Get the url to the model resource.
     */
    public function url(): string;

    /**
     * Get the label to the model resource.
     */
    public function label(): string;


}
