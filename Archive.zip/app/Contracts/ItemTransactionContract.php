<?php

namespace App\Contracts;

interface ItemTransactionContract
{
    /**
     * Get all the transactions for the model.
     */
    public function itemTransactions();

    /**
     * Get the latest transaction for the model.
     */
    public function itemTransaction();

    /**
     * Get the latest balance for the model.
     */
    public function stock(): float;

    /**
     * Get the url to the model resource.
     */
    public function url(): string;

    /**
     * Get the label to the model resource.
     */
    public function label(): string;


}
