<?php

namespace App\EPOS;

use Mike42\Escpos\Printer;

class Generator
{
    public Printer $buffer;


    //printReceiveRecipt(
    //      dynamic data, String type, String ipAddress, String port) async {
    //    //yo garnu xa recipt ko UI
    //    List<int> bytes = [];
    //    final profile = await CapabilityProfile.load(name: 'XP-N160I');
    //
    //    final generator = Generator(PaperSize.mm80, profile);
    //    //header
    //
    //    bytes += generator.text(data['title'].toString(),
    //        styles: const PosStyles(
    //            fontType: PosFontType.fontB,
    //            align: PosAlign.center,
    //            height: PosTextSize.size2,
    //            width: PosTextSize.size2));
    //    bytes += generator.row([
    //      PosColumn(
    //          text: 'Address: Damak,Jhapa',
    //          width: 6,
    //          styles: const PosStyles(
    //              align: PosAlign.left,
    //              height: PosTextSize.size1,
    //              width: PosTextSize.size1)),
    //      PosColumn(
    //          text: 'Phone: 023583229',
    //          width: 6,
    //          styles: const PosStyles(
    //              align: PosAlign.right,
    //              height: PosTextSize.size1,
    //              width: PosTextSize.size1)),
    //    ]);
    //
    //    bytes += generator.text("Customer $type  ",
    //        styles: const PosStyles(
    //            fontType: PosFontType.fontA,
    //            align: PosAlign.center,
    //            height: PosTextSize.size1,
    //            width: PosTextSize.size1));
    //
    //    bytes += generator.text('Invoice Date:${data['invoice_time'].toString()}',
    //        styles: const PosStyles(
    //            align: PosAlign.center,
    //            height: PosTextSize.size1,
    //            width: PosTextSize.size1));
    //    bytes += generator.text('Order No: ${data['order_no'].toString()}',
    //        styles: const PosStyles(
    //            align: PosAlign.center,
    //            height: PosTextSize.size1,
    //            width: PosTextSize.size1));
    //    //table ,customer name and invoice date on row
    //    bytes += generator.row([
    //      PosColumn(
    //          text: 'Table: ${data['table'].toString()}',
    //          width: 12,
    //          styles: const PosStyles(
    //              align: PosAlign.left,
    //              height: PosTextSize.size1,
    //              width: PosTextSize.size1)),
    //    ]);
    //
    //    bytes += generator.row([
    //      PosColumn(
    //          text: 'Customer: ${data['customer_name'].toString()}',
    //          width: 12,
    //          styles: const PosStyles(
    //              align: PosAlign.left,
    //              height: PosTextSize.size1,
    //              width: PosTextSize.size1)),
    //    ]);
    //    bytes += generator.hr();
    //    bytes += generator.row([
    //      PosColumn(
    //          text: 'S.N',
    //          width: 2,
    //          styles: const PosStyles(
    //              align: PosAlign.left,
    //              height: PosTextSize.size1,
    //              width: PosTextSize.size1)),
    //      PosColumn(
    //          text: 'Item',
    //          width: 4,
    //          styles: const PosStyles(
    //              align: PosAlign.left,
    //              height: PosTextSize.size1,
    //              width: PosTextSize.size1)),
    //      PosColumn(
    //          text: 'Qty',
    //          width: 2,
    //          styles: const PosStyles(
    //              align: PosAlign.left,
    //              height: PosTextSize.size1,
    //              width: PosTextSize.size1)),
    //      PosColumn(
    //          text: 'Price',
    //          width: 2,
    //          styles: const PosStyles(
    //              align: PosAlign.left,
    //              height: PosTextSize.size1,
    //              width: PosTextSize.size1)),
    //      PosColumn(
    //          text: 'Total',
    //          width: 2,
    //          styles: const PosStyles(
    //              align: PosAlign.left,
    //              height: PosTextSize.size1,
    //              width: PosTextSize.size1)),
    //    ]);
    //    bytes += generator.hr();
    //
    //    //items with border and for loop
    //    for (var i = 0; i < data['items'].length; i++) {
    //      bytes += generator.row([
    //        PosColumn(
    //            text: '${i + 1}',
    //            width: 2,
    //            styles: const PosStyles(
    //                align: PosAlign.left,
    //                height: PosTextSize.size1,
    //                width: PosTextSize.size1)),
    //        PosColumn(
    //            text: data['items'][i]['name'].toString(),
    //            width: 4,
    //            styles: const PosStyles(
    //                align: PosAlign.left,
    //                height: PosTextSize.size1,
    //                width: PosTextSize.size1)),
    //        PosColumn(
    //            text: data['items'][i]['qty'].toString(),
    //            width: 2,
    //            styles: const PosStyles(
    //                align: PosAlign.left,
    //                height: PosTextSize.size1,
    //                width: PosTextSize.size1)),
    //        PosColumn(
    //            text: data['items'][i]['price'].toString(),
    //            width: 2,
    //            styles: const PosStyles(
    //                align: PosAlign.left,
    //                height: PosTextSize.size1,
    //                width: PosTextSize.size1)),
    //        PosColumn(
    //            text: data['items'][i]['total'].toString(),
    //            width: 2,
    //            styles: const PosStyles(
    //                align: PosAlign.left,
    //                height: PosTextSize.size1,
    //                width: PosTextSize.size1)),
    //      ]);
    //    }
    //    bytes += generator.hr();
    //    bytes += generator.row([
    //      PosColumn(
    //          text: 'Sub Total',
    //          width: 8,
    //          styles: const PosStyles(
    //              align: PosAlign.left,
    //              height: PosTextSize.size1,
    //              width: PosTextSize.size1)),
    //      PosColumn(
    //          text: data['total'].toString(),
    //          width: 4,
    //          styles: const PosStyles(
    //              align: PosAlign.left,
    //              height: PosTextSize.size1,
    //              width: PosTextSize.size1)),
    //    ]);
    //    bytes += generator.row([
    //      PosColumn(
    //          text: 'Received Amount',
    //          width: 8,
    //          styles: const PosStyles(
    //              align: PosAlign.left,
    //              height: PosTextSize.size1,
    //              width: PosTextSize.size1)),
    //      PosColumn(
    //          text: data['received_amount'].toString(),
    //          width: 4,
    //          styles: const PosStyles(
    //              align: PosAlign.left,
    //              height: PosTextSize.size1,
    //              width: PosTextSize.size1)),
    //    ]);
    //    bytes += generator.row([
    //      PosColumn(
    //          text: 'Discount Amount',
    //          width: 8,
    //          styles: const PosStyles(
    //              align: PosAlign.left,
    //              height: PosTextSize.size1,
    //              width: PosTextSize.size1)),
    //      PosColumn(
    //          text: data['discount_amount'].toString(),
    //          width: 4,
    //          styles: const PosStyles(
    //              align: PosAlign.left,
    //              height: PosTextSize.size1,
    //              width: PosTextSize.size1)),
    //    ]);
    //    bytes += generator.row([
    //      PosColumn(
    //          text: 'Change Amount',
    //          width: 8,
    //          styles: const PosStyles(
    //              align: PosAlign.left,
    //              height: PosTextSize.size1,
    //              width: PosTextSize.size1)),
    //      PosColumn(
    //          text: data['change_amount'].toString(),
    //          width: 4,
    //          styles: const PosStyles(
    //              align: PosAlign.left,
    //              height: PosTextSize.size1,
    //              width: PosTextSize.size1)),
    //    ]);
    //    bytes += generator.hr();
    //    bytes += generator.row([
    //      PosColumn(
    //          text: 'Served By:  ${data['on_service_waiter']}',
    //          width: 12,
    //          styles: const PosStyles(
    //              align: PosAlign.left,
    //              height: PosTextSize.size1,
    //              width: PosTextSize.size1)),
    //    ]);
    //    bytes += generator.row([
    //      PosColumn(
    //          text: 'Printed Date: ${data['printed_date'].toString()}',
    //          width: 12,
    //          styles: const PosStyles(
    //              align: PosAlign.left,
    //              height: PosTextSize.size1,
    //              width: PosTextSize.size1)),
    //    ]);
    //    bytes += generator.row([
    //      PosColumn(
    //          text: 'Thank You For Visiting Us',
    //          width: 12,
    //          styles: const PosStyles(
    //              align: PosAlign.center,
    //              height: PosTextSize.size1,
    //              width: PosTextSize.size1)),
    //    ]);
    //
    //    bytes += generator.feed(2);
    //
    //    bytes += generator.cut();
    //    await printerManager.connect(
    //        type: defaultPrinterType,
    //        model: TcpPrinterInput(ipAddress: ipAddress, port: int.parse(port)));
    //    printerManager.send(type: defaultPrinterType, bytes: bytes);
    //  }


}
