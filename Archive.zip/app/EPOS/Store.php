<?php

namespace App\EPOS;


class Store
{


    function __construct(
        private readonly string $mid,
        private readonly string $name,
        private readonly string $address,
        private readonly string $phone,
        private readonly string $email,
        private readonly string $website
    )
    {
    }

    public function getMID(): string
    {
        return $this->mid;
    }

    public function getName(): string
    {
        return $this->name;
    }

    public function getAddress(): string
    {
        return $this->address;
    }

    public function getPhone(): string
    {
        return $this->phone;
    }

    public function getEmail(): string
    {
        return $this->email;
    }

    public function getWebsite(): string
    {
        return $this->website;
    }
}
