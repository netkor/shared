<?php

namespace App\Generators;

class ReferenceCodeGenerator
{
    public static function generate($model, $length = 10): string
    {
        $ref_code = strtoupper(substr($model->getTable(), 0, 3)) . '-' . substr(str_shuffle(str_repeat($x = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($length / strlen($x)))), 1, $length);

        if ($model->where('ref_code', $ref_code)->exists()) {
            return self::generate($model, $length);
        }

        return $ref_code;
    }

}
