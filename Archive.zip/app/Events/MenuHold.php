<?php

namespace App\Events;

use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class MenuHold implements ShouldBroadcast
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    /**
     * Create a new event instance.
     *
     * @return void
     */
    public function __construct(public $carts)
    {
        //
    }

    /**
     * Get the channels the event should broadcast on.
     *
     * @return Channel|array
     */
    public function broadcastOn()
    {
//        try {
//            $printer = new PrintService('XP-80C');
//            $printer->print($this->carts);

//        Http::withHeaders(
//            ['Authorization' =>
//                'key=AAAATiG9N9c:APA91bECsYaddrkQE9eArQFxUDFpZ8q-RcujrqK_Ut1FHcEgeoOwGVYydOXnzgv8m8xmcF3SJIjC-cDY3T19jzynFHYjDo1jW4X--dEzOr-_-5H63QVDqUpOS8f02LJpf34JDe3RXdod'])
//            ->post('https://fcm.googleapis.com/fcm/send',
//                [
//                    "registration_ids" => [
//                        "IlHW1oPQK3UOMuI47hKvBHDbjhHDV0LM4Ij4ZkcCQhMQ0vq8pELrQS18whNnXmHUss7j08tt0iLpEA_N",
//                        "dDPSFdFYTsqf--yhvklPB9:APA91bFJlgb4ViUExFDhqzicjoZUh2MGxY1IB6-VMBczAClt9kjt0mW073VOXhW0r35N_OcEpvDXBnn34V6S0K74LGtn-iRp3pwGbbYQHCqmZz8qESJW-DJVtAZnCp-mTzZKUuaPCVSq",
//                        "c3mH1r_uSs2I2cDe5C4fvt:APA91bGFxAtA2PvUHPVm3H8T6Fi3xPC4aL4zQRj3rGVopU3e2aRfwiTeCtq6ty4-A0sQf0lEHTmKtIITRA7m-eaQPO-s8gTZA5si5Qjd6VYvQs56se66ZbYFJEICNNqn-5jtdz4_BZNh"
//                    ],
//                    "notification" => [
//                        "title" => "Menu hold",
//                        "body" => "Menu item has been hold",
//                        "android_channel_id" => "pos",
//                        "sound" => true
//                    ]
//                ]
//            );

//        } catch (Exception $e) {
//        }


        return new Channel('branch-' . auth()->user()->currentBranch()->id);
    }

    public function broadcastAs()
    {
        return $this->carts['event'];
    }

    public function broadcastWith()
    {
        return $this->carts;
    }

}
