<?php

namespace App\Events\Traits;

trait HasBroadcastWith
{
    public function broadcastWith()
    {
        $carts = $this->carts;
        $printed_date = date('M d, Y h:i:s');
        $group = "#{$carts->first()->group}";
        $table = $carts->first()->table->name;
        $user = auth()->user()->first_name;
        $branch = auth()->user()->currentBranch()->name;

        return [
            'title' => config('app.name'),
            'table' => $table,
            'group' => $group,
            'printed_date' => $printed_date,
            'type' => 'kot',
            'terminal' => 'kitchen',
            'user' => $user,
            'items' => $carts->map(function ($cart) {
                return [
                    'name' => $cart->menu->name,
                    'qty' => $cart->quantity
                ];
            })
        ];

    }


    public function broadcastAs()
    {
        return 'bar-event';
    }


}
