<?php

namespace App\Http\Controllers;

use App\Enums\TableStatus;
use App\Models\Table;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class TableController extends Controller
{

//    public function __construct()
//    {
//        $this->authorizeForUser(auth()->user(), 'viewAny', Table::class);
//    }


    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
        if (request()->wantsJson()) {
            return response(
                Table::all()
            );
        }

        $tables = Table::paginate(10);

        return view('tables.index', compact('tables'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        //create table
        return view('tables.create');

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param Request $request
     * @return Response
     */
    public function store(Request $request)
    {
        $table = new Table();
        $table->name = $request->name;
        $table->description = $request->description;
//        $table->status = $request->status ?? 'open';
        $table->status = TableStatus::tryFrom($request->get('status', 'open'))?->value;
        $table->save();
        return redirect()->route('tables.index');
    }

    /**
     * Display the specified resource.
     *
     * @param Table $table
     * @return Response
     */
    public function show(Table $table)
    {
        return view('tables.show', compact('table'));

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param Table $table
     * @return Response
     */
    public function edit(Table $table)
    {
        return view('tables.edit', compact('table'));

    }

    /**
     * Update the specified resource in storage.
     *
     * @param Request $request
     * @param Table $table
     * @return Response
     */
    public function update(Request $request, Table $table)
    {
        $table->name = $request->name;
        $table->description = $request->description;
        $table->status = $request->status ?? 'open';
        $table->save();
        return redirect()->route('tables.index');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param Table $table
     * @return Response
     */
    public function destroy(Table $table)
    {
        $table->delete();
        return redirect()->route('tables.index');

    }
}
