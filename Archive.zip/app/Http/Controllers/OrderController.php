<?php

namespace App\Http\Controllers;

use App\Events\OrderConfirmedEvent;
use App\Http\Requests\OrderStoreRequest;
use App\Models\Account;
use App\Models\Cart;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Payment;
use App\Models\Setting;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

/**
 * @property int $id
 * @property string|null $log_name
 * @property string $description
 */
class OrderController extends Controller
{
    public function index(Request $request)
    {
        $orders = new Order();
        if ($request->get('start_date')) {
            $orders = $orders->where('created_at', '>=', $request->start_date);
        }
        if ($request->get('end_date')) {
            $orders = $orders->where('created_at', '<=', $request->end_date . ' 23:59:59');
        }

        if ($request->get('ref_no')) {
            $orders = $orders->where('ref_no', 'like', '%' . $request->ref_no . '%');
        }
        if ($request->get('name')) {
            $orders = $orders->whereHas('customer', function ($query) use ($request) {
                $query->where('name', 'like', '%' . $request->name . '%');
            });
        }

        $orders = $orders->with(['order_items', 'payments', 'customer', 'table',])->orderBy('created_at', 'desc')->get();

        $total = $orders->map(function ($i) {
            return $i->total();
        })->sum();
        $receivedAmount = $orders->map(function ($i) {
            return $i->receivedAmount();
        })->sum();
        $discountAmount = $orders->map(function ($i) {
            return $i->discountAmount();
        })->sum();
        $returnAmount = $orders->map(function ($i) {
            return $i->refundAmount();
        })->sum();
        $waiter = auth()->user()->first_name;

        return view('orders.index', compact('orders', 'total', 'receivedAmount', 'waiter', 'discountAmount', 'returnAmount'));
    }

    public function store(OrderStoreRequest $request)
    {
        $isCard = Setting::where('key', 'payment_method')->first()->value == 'Card';

        DB::beginTransaction();

        $carts = Cart::query()
            ->where('table_id', $request->get('table_id'))
            ->when($isCard, function ($query) {
                $query->whereNotNull('card_id');
            })
            ->get();

        $order = Order::query()->create([
            'ref_no' => Order::generateRefNo(),
            'customer_id' => $request->get('customer_id', null),
            'table_id' => $request->get('table_id'),
        ]);

        $order->order_items()->createMany($carts->map(function ($cart) {
            return [
                'menu_id' => $cart->menu_id,
                'price' => $cart->price,
                'quantity' => $cart->quantity,
            ];
        })->toArray());

        $carts->each->update(['status' => 'served']);
        $carts->each->delete();


        $payment = new Payment();

        if ($isCard) {
            $payment->forceFill(['amount' => $order->total()]);
            $payment->forceFill(['received_amount' => $order->total()]);
        } else {
            $payment->forceFill(['amount' => $order->total()]);
            $payment->forceFill(['received_amount' => $request->get('received_amount')]);
            $payment->forceFill(['discount_amount' => $request->get('discount_amount')]);
            $payment->forceFill(['return_amount' => $request->get('discount_amount')]);
        }

        $payment->forceFill(['order_id' => $order->id]);

        $payment->save();

        $order = Order::where('id', $order->id)->with(['order_items', 'payments', 'customer', 'table',])->first();


        if (!$isCard) {
            $previousBalance = auth()->user()->currentBranch()?->cashAccount()?->balance() ?? 0;

            $newBalance = $previousBalance + ($order->total() > $order->receivedAmount() ? $order->receivedAmount() : $order->total());

            $account = Account::find($request->get('account_id'));

            $account->transactions()->create([
                'ref_code' => $order->ref_no,
                'note' => "Payment for order {$order->ref_no}",
                'source' => "Cash",
                'status' => $request->get('status'),
                'amount' => ($order->total() > $order->receivedAmount() ? $order->receivedAmount() : $order->total()),
                'parent_id' => $request->get('parent_id'),
                'balance' => $newBalance ?? 0,
            ]);
            $order->customer->points += $order->total() / config('settings.points', 1);
            $order->customer->save();
        }

        $table = $order->table;
        $table->status = 'open';
        $table->save();

        DB::commit();

        $order->load(['order_items', 'payments', 'customer', 'table',]);

        event(new OrderConfirmedEvent($this->makeReceiptReadyForPrint($order, 'billing')));


        return 'success';
    }

    protected function makeReceiptReadyForPrint($order, $key): array
    {

        $printed_date = date('M d, Y h:i:s');
        return [
            'order_no' => $order->ref_no,
            'title' => config('app.name'),
            'address' => config('settings.address'),
            'email' => config('settings.email'),
            'phone' => config('settings.phone'),
            'event' => str($key)->lower()->append("-event"),
            'table' => $order->table->name,
            'printed_date' => $printed_date,
            'type' => 'receipt',
            'customer_name' => $order?->customer?->name ?? 'N/A',
            'invoice_time' => $order->created_at->format('M d, Y h:i:s'),
            'total' => $order->formattedTotal(),
            'received_amount' => $order->formattedReceivedAmount(),
            'change_amount' => $order->formattedChangeAmount(),
            'discount_amount' => $order->formattedDiscountAmount(),
            'on_service_waiter' => auth()->user()->first_name,
            'items' => $order->order_items->map(function ($item) {
                return [
                    'name' => $item->menu->name,
                    'qty' => $item->quantity,
                    'price' => $item->menu->price,
                    'total' => $item->menu->price * $item->quantity
                ];
            })
        ];
    }

    public function printReceipt($order)
    {
        $order = Order::query()->with(['order_items', 'payments', 'customer', 'table',])->find($order);

        event(new OrderConfirmedEvent($this->makeReceiptReadyForPrint($order, 'billing')));

        return redirect()->back()->with('success', 'Receipt printed successfully');
    }


    public function dailysalesreport(Request $request)
    {
        $ordersItem = OrderItem::query()
            ->when($request->has('menu'), function ($query) use ($request) {
                $query->whereHas('menu', function ($query) use ($request) {
                    return $query->where('name', 'like', '%' . $request->get('menu') . '%');
                });
            })
            ->whereHas('menu')
            ->whereBetween('created_at', [$this->getStartDate($request), $this->getEndDate($request)])
            ->with('menu')
            ->orderBy('created_at', 'desc')
            ->get()
            ->groupBy('menu_id');
//            ->groupBy('price');
//        return $ordersItem;


        $totalQuantity = number_format($ordersItem->sum(function ($item) {
            return $item->sum('quantity');
        }));

        $totalAmount = number_format($ordersItem->sum(function ($item) {
            return $item->first()->price * $item->sum('quantity');
        }));


//        $ordersItem = $ordersItem->map(function ($item) {
//            return collect($item->groupby('price')->map(function ($item) {
//                return collect([
//                    'name' => $item->first()->menu->name,
//                    'quantity' => $item->sum('quantity'),
//                    'price' => $item->first()->price,
//                    'total' => $item->first()->price * $item->sum('quantity'),
//                ]);
//            }));
//        });


        $ordersItem = $ordersItem->map(function ($item) {
            return [
                'name' => $item->first()->menu->name,
                'quantity' => $item->sum('quantity'),
                'price' => $item->unique('price')
                    ->implode('price', ', '),
                'total' => number_format($item->sum('price')),
            ];
        });

        return view('dailysalesreport.index', compact('ordersItem', 'totalQuantity', 'totalAmount'));
    }

    private function getStartDate($request): Carbon
    {
        $date = $request->get('start_date');
        if ($date) {
            return Carbon::parse($date)->startOfDay()->addHours($request->get('start_time', 0));
        }
        return Carbon::now()->startOfDay()->addHours($request->get('start_time', 0));
    }

    private function getEndDate($request): Carbon
    {
        $date = $request->get('end_date');
        if ($date) {
            return Carbon::parse($date)->endOfDay()->addHours($request->get('start_time', 0));
        }
        return Carbon::now()->endOfDay()->addHours($request->get('start_time', 0));
    }
}
