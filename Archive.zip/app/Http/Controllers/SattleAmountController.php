<?php

namespace App\Http\Controllers;

use App\Models\Order;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class SattleAmountController extends Controller
{
    /**
     * Handle the incoming request.
     *
     * @param Request $request
     * @return Response
     */
    public function __invoke(Request $request)
    {
        $order = Order::find($request->order_id);
        //find payment of order
        $payment = $order->payment();



        //update payment
        $payment->update([
            'received_amount' => $payment->received_amount + $request->amount,
            'return_amount' => $payment->amount - $payment->discount_amount + $payment->received_amount,
        ]);



        $previousBalance = auth()->user()->currentBranch()->balance();


        $newBalance = $previousBalance + ($order->total() > $request->amount ? $request->amount: $order->total());

        auth()->user()->currentBranch()->transactions()->create([
            'ref_code' => $order->ref_no,
            'note' => "Payment for order {$order->ref_no}",
            'source' => "Cash",
            'status' => $request->get('status'),
            'amount' => ($order->total() > $request->amount ? $request->amount : $order->total()),
            'parent_id' => $request->get('parent_id'),
            'balance' => $newBalance ?? 0,

        ]);
        //redirect to order index page
        return redirect()->route('orders.index');


    }
}
