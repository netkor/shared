<?php

namespace App\Http\Controllers;

use App\Models\Tenant;
use App\Http\Requests\StoreTendentRequest;
use App\Http\Requests\UpdateTendentRequest;

class TendentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoreTendentRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreTendentRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Tenant  $tendent
     * @return \Illuminate\Http\Response
     */
    public function show(Tenant $tendent)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Tenant  $tendent
     * @return \Illuminate\Http\Response
     */
    public function edit(Tenant $tendent)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdateTendentRequest  $request
     * @param  \App\Models\Tenant  $tendent
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateTendentRequest $request, Tenant $tendent)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Tenant  $tendent
     * @return \Illuminate\Http\Response
     */
    public function destroy(Tenant $tendent)
    {
        //
    }
}
