<?php

namespace App\Http\Controllers;

use App\Enums\AccountStatus;
use App\Http\Requests\StoreBranchRequest;
use App\Http\Requests\UpdateBranchRequest;
use App\Models\Branch;
use App\Models\User;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\View\Factory;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class BranchController extends Controller
{

    public function index(): Application|Factory|View
    {
        $branches = Branch::all();

        return view('branches.index', compact('branches'));
    }


    public function show(Branch $branch): Application|Factory|View
    {
        return view('branches.show', compact('branch'));
    }


    public function edit(Branch $branch): Application|Factory|View
    {
        $users = User::select('id', 'first_name', 'last_name')->get()->mapWithKeys(function ($user) {
            return [$user->id => $user->first_name . " " . $user->last_name];
        });
        $selectedUser = $branch->user_id;

        return view('branches.edit', compact('branch', 'users', 'selectedUser'));
    }

    public function update(UpdateBranchRequest $request, Branch $branch): RedirectResponse
    {

        $branch->name = $request->name;
        $branch->address = $request->address;
        $branch->phone = $request->phone;
        $branch->email = $request->email;
        $branch->pan_no = $request->pan_no;
        $branch->vat_no = $request->vat_no;
        $branch->user_id = $request->user_id;


        if ($request->hasFile('logo')) {
            // Delete old avatar
            if ($branch->logo) {
                Storage::delete($branch->logo);
            }
            // Store logo
            $branch_logo = $request->file('logo')->store('branch', 'public');
            // Save to Database
            $branch->logo = $branch_logo;
        }
        if (!$branch->save()) {
            return redirect()->back()->with('error', 'Branch could not be updated');
        }
        return redirect()->route('branches.index')->with('success', 'Branch updated successfully');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param StoreBranchRequest $request
     * @return RedirectResponse
     */
    public function store(StoreBranchRequest $request)
    {
        $branch_logo = '';

        if ($request->hasFile('logo')) {
            $branch_logo = $request->file('logo')->store('branch', 'public');
        }

        DB::beginTransaction();

        $branch = Branch::create([
            'name' => $request->get('name'),
            'address' => $request->get('address'),
            'phone' => $request->get('phone'),
            'email' => $request->get('email'),
            'pan_no' => $request->get('pan_no'),
            'vat_no' => $request->get('vat_no'),
            'user_id' => $request->get('user_id'),
            'status' => $request->get('status', 1),
            'logo' => $branch_logo
        ]);

        $branch->users()->attach($request->user_id);


        $account = $branch->accounts()->create([
            'name' => 'Cash',
            'number' => rand(1000000000, 9999999999),
            'type' => 'cash',
            'status' => AccountStatus::ACTIVE,
            'description' => 'Cash account for branch ' . $branch->name,
        ]);

        $account->assignTenant($branch->id);

        DB::commit();

        return redirect()->route('branches.index')->with('success', 'Branch created successfully');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        $users = User::select('id', 'first_name', 'last_name')->get()->mapWithKeys(function ($user) {
            return [$user->id => $user->first_name . " " . $user->last_name];
        });

        $selectedUser = null;

        return view('branches.create', compact('users', 'selectedUser'));

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param Branch $branch
     * @return Response
     */
    public function destroy(Branch $branch)
    {
        //soft delete the branch
        $branch->delete();
        return redirect()->route('branches.index')->with('success', 'Branch deleted successfully');
    }


}
