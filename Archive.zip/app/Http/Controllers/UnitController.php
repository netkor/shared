<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreUnitRequest;
use App\Http\Requests\UpdateUnitRequest;
use App\Models\Unit;
use Illuminate\Http\Response;

class UnitController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
        if (request()->wantsJson()) {
            return response(
                Unit::all()

            );
        }
        $units = Unit::query()->with('parent')->get();
        return view('units.index', compact('units'));


    }

    /**
     * Store a newly created resource in storage.
     *
     * @param StoreUnitRequest $request
     * @return Response
     */
    public function store(StoreUnitRequest $request)
    {


        $unit = Unit::create($request->validated());


        if ($unit) {
            return redirect()->route('units.index')->with('success', 'Unit created successfully');
        }
        return back()->withInput()->with('errors', 'Error creating new Unit');

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        $units = Unit::query()->select('id', 'name')->get();
        return view('units.create', compact('units'));
    }

    /**
     * Display the specified resource.
     *
     * @param Unit $unit
     * @return Response
     */
    public function show(Unit $unit)
    {

        $unit = Unit::where('id', $unit->id)->first();
        return view('units.show', compact('unit'));

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param Unit $unit
     * @return Response
     */
    public function edit(Unit $unit)
    {

        $units = Unit::query()->select('id', 'name')->get();

        $selectedUnit = $unit->id;
        return view('units.edit', compact('unit', 'units', 'selectedUnit'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param UpdateUnitRequest $request
     * @param Unit $unit
     * @return Response
     */
    public function update(UpdateUnitRequest $request, Unit $unit)
    {

        $unit->update($request->validated());

        if ($unit) {
            return redirect()->route('units.index')->with('success', 'Unit updated successfully');
        }
        return back()->withInput()->with('errors', 'Error updating Unit');


    }

    /**
     * Remove the specified resource from storage.
     *
     * @param Unit $unit
     * @return Response
     */
    public function destroy(Unit $unit)
    {
        $findUnit = Unit::find($unit->id);
        if ($findUnit->delete()) {

            //redirect
            return redirect()->route('units.index')
                ->with('success', 'Unit deleted successfully');
        }

        return back()->withInput()->with('error', 'Unit could not be deleted');
    }
}
