<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreVariantRequest;
use App\Http\Requests\UpdateVariantRequest;
use App\Models\Product;
use App\Models\Unit;
use App\Models\Variant;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\View\Factory;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Response;

class VariantController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Application|Factory|View
     */
    public function index(Product $product)
    {
        $variants = $product->variants()->paginate(10);

        return view('variants.index', compact('variants', 'product'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param StoreVariantRequest $request
     * @return RedirectResponse
     */
    public function store(StoreVariantRequest $request, Product $product)
    {
        $product->variants()->create($request->validated());

        return redirect()->route('variants.index', $product);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create(Product $product)
    {

        $variant = new Variant;

        $units = Unit::query()
            ->select('id', 'name')
            ->where('physical_quantity', $product->keepingUnit->physical_quantity)
            ->get()
            ->mapWithKeys(function ($unit) {
                return [$unit->id => $unit->name];
            });

        $selectedUnit = [];

        $selectedProduct = [];

        return view('variants.create')
            ->with('variant', $variant)
            ->with('units', $units)
            ->with('product', $product)
            ->with('selectedUnit', $selectedUnit)
            ->with('selectedProduct', $selectedProduct);


    }

    /**
     * Display the specified resource.
     *
     * @param Variant $variant
     * @return Response
     */
    public function show(Variant $variant)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param Variant $variant
     * @return Application|Factory|View
     */
    public function edit(Product $product, Variant $variant)
    {
        $units = Unit::query()
            ->where('physical_quantity', $product->keepingUnit->type)
            ->select('id', 'name')->get()->mapWithKeys(function ($unit) {
                return [$unit->id => $unit->name];
            });

        $selectedUnit = $variant->unit_id;

        return view('variants.edit')
            ->with('variant', $variant)
            ->with('product', $product)
            ->with('units', $units)
            ->with('selectedUnit', $selectedUnit);

    }

    /**
     * Update the specified resource in storage.
     *
     * @param UpdateVariantRequest $request
     * @param Variant $variant
     * @return RedirectResponse
     */
    public function update(UpdateVariantRequest $request, Product $product, Variant $variant)
    {
        $variant->update($request->validated());

        return redirect()->route('variants.index', $variant->product);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param Variant $variant
     * @return Response
     */
    public function destroy(Variant $variant)
    {
        //
    }
}
