<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreVariantRequest;
use App\Http\Requests\UpdateVariantRequest;
use App\Models\Product;
use App\Models\Unit;
use App\Models\Variant;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\View\Factory;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;

class VariantController extends Controller
{

    public function index(Product $product): Application|Factory|View
    {
        $variants = $product->variants()->paginate(10);

        return view('variants.index', compact('variants', 'product'));
    }


    public function store(StoreVariantRequest $request, Product $product): RedirectResponse
    {
        $product->variants()->create($request->validated());

        return redirect()->route('variants.index', $product);
    }

    public function create(Product $product): Application|Factory|View
    {

        $variant = new Variant;

        $units = Unit::query()
            ->select('id', 'name')
            ->where('physical_quantity', $product->keepingUnit->physical_quantity)
            ->get()
            ->mapWithKeys(function ($unit) {
                return [$unit->id => $unit->name];
            });

        $selectedUnit = [];

        $selectedProduct = [];

        return view('variants.create')
            ->with('variant', $variant)
            ->with('units', $units)
            ->with('product', $product)
            ->with('selectedUnit', $selectedUnit)
            ->with('selectedProduct', $selectedProduct);
    }

    public function show(Variant $variant): Application|Factory|View
    {
        return view('variants.show', $variant);
    }

    public function edit(Product $product, Variant $variant): Application|Factory|View
    {
        $units = Unit::query()
            ->select('id', 'name')
            ->where('physical_quantity', $product->keepingUnit->physical_quantity)
            ->get()
            ->mapWithKeys(function ($unit) {
                return [$unit->id => $unit->name];
            });

        $selectedUnit = $variant->unit_id;

        return view('variants.edit')
            ->with('variant', $variant)
            ->with('product', $product)
            ->with('units', $units)
            ->with('selectedUnit', $selectedUnit);

    }

    public function update(UpdateVariantRequest $request, Product $product, Variant $variant): RedirectResponse
    {
        $variant->update($request->validated());

        return redirect()->route('variants.index', $variant->product);
    }

    public function destroy(Product $product, Variant $variant): RedirectResponse
    {
        $variant->delete();
        if ($product->variants->count() == 0) {
            return redirect()->route('products.index');
        }

        return redirect()->route('variants.index', $product);
    }

}
