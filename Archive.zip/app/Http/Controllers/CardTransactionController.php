<?php

namespace App\Http\Controllers;

use App\Enums\TransactionStatus;
use App\Models\Account;
use App\Models\Card;
use App\Models\Transaction;
use Illuminate\Http\Request;

class CardTransactionController extends Controller
{
    public function __invoke(Request $request, Card $card)
    {


        $request->validate([

            'amount' => 'required|numeric|gt:0',
            'source' => 'required|in:deposit,withdraw',
            'account' => 'required',
            'note' => 'nullable|string',
        ]);
        $input = $request->all();
        $input['note'] = $input['note'] ?? "Amount {$request->get('amount')} {$request->get('source')}";
        $account = Account::find($request->account);
        $previousBalance = $card->balance();

        if ($request->get('source') == 'withdraw') {
            if ($request->get('amount') > $previousBalance) {
                return redirect()->back()->with('error', 'You can not withdraw more than your balance');
            }
        }



        match ($request->get('source')) {
            'deposit' => $card->deposit($input['amount'], $input['note'], $account),
            'withdraw' => $card->withdraw($input['amount'], $input['note'], $account),
        };

        $amount = 0;



        return redirect()
            ->route('cards.index', $card)
            ->with('success', "Card {$input['source']} successfully.");

    }


    public function cardTransaction(Request $request, Card $card){
        $account = Account::find($request->account);

        $previousBalance = $account->balance();

        if ($request->get('transactionable_type') == 'Cash Out') {
            if ($request->get('amount') > $previousBalance) {
                return redirect()->back()->with('error', 'You can not cash out more than your balance');
            }
        }

        $amount = 0;

        if ($request->get('transactionable_type') == 'Cash In') {
            $amount = $request->get('amount');
        } else if ($request->get('transactionable_type') == 'Cash Out') {
            $amount = -$request->get('amount');
        }


        $account->transactions()->create([
            'ref_code' => Transaction::generateRefCode("DPO"),
            'source' => 'Deposit',
            'status' => TransactionStatus::COMPLETED,
            'amount' => $amount,
            'note' => $request->get('note'),
            'parent_id' => $request->get('parent_id'),
            'balance' => $previousBalance + $amount,
            //            'balance' => $previousBalance ? +$amount : 0,
        ]);

        return redirect()->route('cards.index');
    }

}
