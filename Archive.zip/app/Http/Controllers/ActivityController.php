<?php

namespace App\Http\Controllers;

use App\DataTables\ActivityDataTable;
use App\DataTables\Scopes\RoleActivities;
use App\DataTables\Scopes\SubjectActivities;
use App\Http\Requests\StoreActivityRequest;
use App\Http\Requests\UpdateActivityRequest;
use App\Models\Activity;
use Illuminate\Http\Response;

class ActivityController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index(ActivityDataTable $activityDataTable)
    {
        return $activityDataTable->addScope(new RoleActivities())->render('activity-logs.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param StoreActivityRequest $request
     * @return Response
     */
    public function store(StoreActivityRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param Activity $activity
     * @return Response
     */
    public function show($activity)
    {
        $activity = Activity::with(['causer', 'subject'])->findOrFail($activity);

        return view('activity-logs.show', compact('activity'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param Activity $activity
     * @return Response
     */
    public function edit(Activity $activity)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param UpdateActivityRequest $request
     * @param Activity $activity
     * @return Response
     */
    public function update(UpdateActivityRequest $request, Activity $activity)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param Activity $activity
     * @return Response
     */
    public function destroy(Activity $activity)
    {
        //
    }

    public function subjectActivity($subject, $id)
    {
        $activityDataTable = new ActivityDataTable();
        $activityDataTable->addScope(new SubjectActivities($subject, $id));

        return $activityDataTable->render('activity-logs.index');


        $activities = Activity::where('subject_type', $subject)->where('subject_id', $id)
            ->orderBy('created_at', 'desc')
            ->paginate(10);

        return view('activity-logs.index', compact('activities'));

    }


}
