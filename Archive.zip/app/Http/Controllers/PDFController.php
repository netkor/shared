<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Barryvdh\DomPDF\PDF;

class PDFController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
  static  public function generatePDF()
    {

        $pdf = app('dompdf.wrapper');
        $pdf->loadHTML('<h1>Mero name pankaj Dahal ho</h1>');



        return $pdf->stream();
        $pdf->loadView('pdf');
    }
}
