<?php

namespace App\Http\Controllers;

use App\Models\Cart;

class CartDetailsController extends Controller
{
    public function __invoke()
    {
        $carts = Cart::query()
            ->withTrashed()
            ->with('table', 'menu.type')
            ->orderBy('updated_at', 'desc')
            ->get()
            ->groupBy('group');


        $carts = $carts->map(function ($cart) {
            return $cart->map(function ($item) use ($cart) {
                return [
                    'id' => $item->id,
                    'table' => $item->table->name,
                    'group' => $item->group,
                    'total' => $item->menu->price,
                    'status' => $item->status,
                    'progress' => $this->calculateProgress($item),
                    'type' => $cart->map(function ($item) {
                        return $item->menu->type->name;
                    })->unique(),
                    'updated_at' => $item->updated_at->format('d/m/Y H:i:s'),
                ];
            });
        });


        $carts = $carts->map(function ($cart) {
            $cart = collect(collect($cart));
            return [
                'id' => $cart->first()['id'],
                'group' => $cart->first()['group'],
                'table' => $cart->first()['table'],
                'total' => $cart->sum('total'),
                'items' => $cart->count(),
                'progress' => $cart->avg('progress'),
                'types' => $cart->pluck('type')->flatten()->unique(),
                'status' => str($cart->first()['status'])->title()->__toString(),
            ];
        })->values();

        $carts = $carts->toJson();


        return view('cart.cart-details', compact('carts'));
    }

    protected function calculateProgress($cart): float|int
    {
        return match ($cart['status']) {
                'served' => 1,
                'serving' => 0.75,
                'preparing' => 0.5,
                'hold' => 0.25,
                default => 0,
            } * 100;
    }


}
