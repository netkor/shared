<?php

namespace App\Http\Controllers\Api;

use App\Http\Resources\MenuResource;
use App\Models\Menu;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;

class MenuAPIController
{
    public function __invoke(Request $request)
    {
        $pos_menus = Menu::query()->with('ingredients.product');

        if ($request->search) {
            $pos_menus = $pos_menus->where('name', 'LIKE', "%{$request->search}%");
        }

        $pos_menus = $pos_menus->get();

        $menus = collect();


        foreach ($pos_menus as $pos_menu) {
            $menus->push($this->accept($pos_menu));
        }


        $menus = $menus->reject(function ($menu) {
            return $menu->count() == 0;
        });


        return MenuResource::collection($menus);


    }

    private function accept(Menu $menu): Menu|Collection
    {
        if (isset($menu->ingredients)) {
            if (!$menu->ingredients->count() > 0) {
                return collect();
            }
        }

        if (isset($menu->ingredients)) {
            foreach ($menu->ingredients as $ingredient) {
                if ($ingredient->should_be_in_stock) {
                    if ($ingredient->quantity >= $ingredient->product->remaining_stock) {
                        return collect();
                    }
                }
            }
        }

        return $menu;
    }

}
