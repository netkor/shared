<?php

namespace App\Http\Controllers\Api;

use App\Models\Menu;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;

class ItemAPIController
{

    public function __invoke(Request $request)
    {
        $menus = new Collection();

        $items = Menu::query()
            ->with(['ingredients.product'])
            ->select(['id', 'name', 'price']);

        if ($request->has('search')) {
            $items = $items->where('name', 'LIKE', "%{$request->get('search')}%");
        }

        $items->chunk(100, function ($item) use ($request, $menus) {
            foreach ($item as $i) {
//                $menus->push($this->accept($i));
                $menus->push($i);
            }
        });

        $menus = $menus->filter(fn($menu) => $menu->count() > 0)->values();

//        return view('welcome', compact('menus'));

        return $this->transform($menus);
    }

    private function transform(Collection $collection): array
    {
        return $collection->map(function ($item) {
            return [
                'id' => $item->id,
                'name' => $item->name,
                'price' => $item->price,
                'image' => $item->getFirstMediaUrl('menus', 'preview'),
            ];
        })->toArray();
    }

    private function accept(Menu|Collection $menu): Collection|Menu
    {
        if (isset($menu->ingredients)) {
            if (!$menu->ingredients->count() > 0) {
                return collect();
            }
        }

        if (isset($menu->ingredients)) {
            foreach ($menu->ingredients as $ingredient) {
                if ($ingredient->should_be_in_stock) {
                    if ($ingredient->quantity >= $ingredient->product->remaining_stock) {
                        return collect();
                    }
                }
            }
        }

        return $menu;
    }

}
