<?php

namespace App\Http\Controllers\Api;

use App\Http\Resources\MenuResource;
use App\Models\Menu;
use Illuminate\Http\Request;

class ItemAPIController
{

    public function __invoke(Request $request)
    {
        $items = new Menu();

        if ($request->search) {
            $items = $items->where('name', 'LIKE', "%{$request->search}%");
        }
        $items=$items->get();

        $items = $items->map(function ($item) {
            return [
                'id' => $item->id,
                'name' => $item->name,
                'price' => $item->price,
                'image' => $item->image,
                'description' => $item->description,
                'category' => $item->category->name,
                'category_id' => $item->category_id,
                'image'=>$item->getFirstMediaUrl('menus', 'preview'),

            ];
        });


        return $items;
      // return MenuResource::collection($items);
    }

}
