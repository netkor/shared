<?php

namespace App\Http\Controllers\Api;

use App\Events\MenuHold;
use App\Models\Cart;
use App\Models\Table;
use App\Services\UnitConverter;
use Exception;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\Routing\ResponseFactory;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class CartAPIController
{

    public function index(Request $request)
    {
        $cart = Cart::with('menu')
            ->where('table_id', $request->table_id)
            ->where('status', '!=', 'hold')
            ->get();
        if (!$cart) {
            //send cart is empty
            return response()->json(['message' => 'Cart is empty'], 200);
        }
        return $cart;
    }

    public function empty(Request $request)
    {
        $request->validate([
            'table_id' => 'required|exists:tables,id'
        ]);
        $cart = Cart::where('table_id', $request->table_id)->first();
        if ($cart->status == "hold") {
            return response([
                'message' => 'You can not empty cart while it is on hold. You have to make a Payment first',
            ], 400);
        }
        $table = $request->table_id;
        Cart::where('table_id', $request->table_id)->where('status', '!=', 'hold')->delete();
        Table::find($table)->update(['status' => "open"]);
        return;
    }

    public function delete(Request $request)
    {
        $request->validate([
            'menu_id' => 'required|exists:menus,id',
            'table_id' => 'required|exists:tables,id'
        ]);

        $carts = Cart::query()
            ->where('table_id', $request->table_id)
            ->where('menu_id', $request->menu_id)
            ->where('status', '!=', 'hold')->get();
        $carts->each->update(['status' => 'served']);
        $carts->each->delete();
        //if cart is empty update table status to open
        $cart = Cart::where('table_id', $request->table_id)->first();
        if (!$cart) {
            //send cart is empty
            Table::find($request->table_id)->update(['status' => "open"]);
        }

        return;
    }

    public function swap(Request $request)
    {
        $request->validate([
            'table_id' => 'required|exists:tables,id',
            'new_table_id' => 'required|exists:tables,id'
        ]);

        $cart = Cart::where('table_id', $request->table_id)->first();
        if ($cart->status != "hold") {
            return response([
                'message' => 'Table has pending items. Remove or hold them first',
            ], 400);
        }

        $table = $request->table_id;
        $new_table = $request->new_table_id;

        $carts = Cart::where('table_id', $request->table_id)->get();
        $carts->each->update(['table_id' => $new_table]);

        Table::find($table)->update(['status' => "open"]);
        Table::find($new_table)->update(['status' => "serving"]);
        return;
    }

    public function viewOrders(Request $request)
    {
        $carts = Cart::query()
            ->with('menu', 'menu.type', 'menu.category')
            ->where('table_id', $request->table_id)
            ->where('status', '=', 'hold')
            ->orWhere('status', '=', 'preparing')
            ->orWhere('status', '=', 'serving')
            ->orderBy('updated_at', 'desc')
            ->get();

        $carts = $carts->map(
            function ($item) use ($carts) {
                return [
                    'id' => $item->menu->id,
                    'name' => $item->menu->name,
                    'price' => $item->menu->price,
                    'group' => $item->group,

                    'status' => $item->status,
                    'category' => $item->menu->category->name,
                    'type' => $item->menu->type->name,
                    'image' =>  $item->menu->image,
                    'quantity' => $item->quantity,
                    'progress' => $this->calculateProgress($item),
                    'created_at' => $item->created_at,
                    'updated_at' => $item->updated_at,

                ];
            }
        );


        return response($carts->toJson());
    }

    protected function calculateProgress($cart): float|int
    {
        return match ($cart['status']) {
            'served' => 1,
            'serving' => 0.75,
            'preparing' => 0.5,
            'hold' => 0.25,
            default => 0,
        }
            * 100;
    }


    public function holdItems(Request $request)
    {
        $request->validate([
            'cart.*.menu_id' => 'required|exists:menus,id',
            'cart.*.table_id' => 'required|exists:tables,id',
            'cart.*.quantity' => 'required|numeric',
        ]);

        $input = $request->all();
        $group = strtoupper(substr(md5(microtime()), rand(0, 26), 5));

        foreach ($input['cart'] as $item) {
            //create cart
            $cart = Cart::create([
                'menu_id' => $item['menu_id'],
                'table_id' => $item['table_id'],
                'quantity' => $item['quantity'],
                'group' => $group,
                'status' => 'hold',
            ]);
            $this->reduceIngredients($cart, $cart->quantity);
        }

        Table::find($input['cart'][0]['table_id'])->update(['status' => "hold"]);

        return response()->json(['message' => 'Items are on hold'], 200);
    }


    public function hold(Request $request)
    {
        if (!auth()->check()) {
            return response()->json(['message' => 'You are not logged in'], 401);
        }

        $request->validate([
            'table_id' => 'required|exists:tables,id'
        ]);
        $table = $request->get('table_id');
        $carts = Cart::query()
            ->with('menu.ingredients')
            ->with('menu.type')
            ->where('table_id', $request->get('table_id'))
            ->whereNotIn('status', ['hold', 'done'])
            ->get();


        $carts->each(function ($cart) {
            $this->reduceIngredients($cart, $cart->quantity);
        });
        $carts->each->update(['status' => "hold"]);
        $items = $carts->groupBy('menu.type.name');
        foreach ($items as $key => $item) {
            $item = $this->makeReadyForPrint($item, $key);
            event(new MenuHold($item));
        }
        Table::find($table)->update(['status' => "hold"]);
        return;
    }
    private function reduceIngredients($cart, $quantity)
    {
        $ingredients = $cart->menu->ingredients;

        foreach ($ingredients as $ingredient) {

            $product = $ingredient->product;

            if ($product->keepingUnit->hierarchy > $ingredient->unit->hierarchy) {
                $fromUnit = $ingredient->unit;
                $toUnit = $product->keepingUnit;
            } else {
                $fromUnit = $product->keepingUnit;
                $toUnit = $ingredient->unit;
            }

            $converter = new UnitConverter(fromUnit: $fromUnit, toUnit: $toUnit);

            $volume = $converter->convert($ingredient->quantity * (float)$quantity);


            $product->update([
                'remaining_stock' => $product->remaining_stock - $volume
            ]);
        }
    }

    protected function makeReadyForPrint($carts, $key)
    {
        if (!auth()->check()) {
            return;
        }
        $printed_date = date('M d, Y h:i:s');
        $group = "#{$carts?->first()?->group}";
        $table = $carts?->first()?->table->name;
        $user = auth()->user()->first_name;
        $branch = auth()->user()->currentBranch()->name;


        return [
            'title' => config('app.name'),
            'event' => str($key)->lower()->append("-event"),
            'table' => $table,
            'group' => $group,
            'printed_date' => $printed_date,
            'type' => 'kot',
            'terminal' => str($key)->ucfirst(),
            'user' => $user,
            'items' => $carts->map(function ($cart) {
                return [
                    'name' => $cart->menu->name,
                    'qty' => $cart->quantity
                ];
            })
        ];
    }

    public function changeQty(Request $request): Response|Application|ResponseFactory
    {

        $request->validate([
            'group' => 'required',
            'menu_id' => 'required|exists:menus,id',
            'quantity' => 'required|integer|min:1',
            'table_id' => 'required|exists:tables,id',
        ]);

        try {
            $cart = Cart::query()
                ->where('group', $request->get('group'))
                ->where('table_id', $request->get('table_id'))
                ->where('menu_id', $request->get('menu_id'));


            if ($request->get('quantity') <= 0) {
                $cart->delete();
            } else {
                $cart->update([
                    'quantity' => $request->get('quantity'),
                ]);
            }
        } catch (Exception $e) {
            return response($e->getMessage(), 500);
        }

        return response([
            'success' => true
        ]);
    }
}
