<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Transformers\UserTransformer;
use Illuminate\Http\Request;

class UserAPIController extends Controller
{

    public function login(Request $request)
    {
        $this->validate($request, [
            'email' => 'required|email',
            'password' => 'required',
        ]);

        if (auth()->attempt(['email' => $request->input('email'), 'password' => $request->input('password')])) {
            $user = auth()->user();
            $user->makeVisible('api_token');
            $user->load('roles');
            return (new UserTransformer)->transform($user);
        }
    }


    public function profile()
    {
        $user = auth()->user();
        $user->makeVisible('api_token');
        $user->load('roles');
        return (new UserTransformer)->transform($user);
    }

    //update device token
    public function updateDeviceToken(Request $request)
    {
        $this->validate($request, [
            'device_token' => 'required',
        ]);

        $user = auth()->user();
        $user->device_token = $request->device_token;
        $user->save();

        return response()->json(['message' => 'Device token updated successfully']);
    }


}
