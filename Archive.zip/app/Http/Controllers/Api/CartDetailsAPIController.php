<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Cart;
use Illuminate\Http\Request;

class CartDetailsAPIController extends Controller
{
    public function __invoke(string $group)
    {

        $carts = Cart::query()
            ->withTrashed()
            ->with('table', 'menu', 'menu.type', 'menu.category')
            ->where('group', $group)
            ->orderBy('updated_at', 'desc')
            ->get();

        $carts = $carts->map(
            function ($item) use ($carts) {
                return [
                    'id' => $item->menu->id,
                    'name' => $item->menu->name,
                    'price' => $item->menu->price,
                    'status' => $item->status,
                    'category' => $item->menu->category->name,
                    'image' => asset('storage/' . $item->menu->image),
                    'quantity' => $item->quantity,
                    'progress' => $this->calculateProgress($item),

                ];
            }
        );


        return response($carts->toJson());


    }

    protected function calculateProgress($cart): float|int
    {
        return match ($cart['status']) {
                'served' => 1,
                'serving' => 0.75,
                'preparing' => 0.5,
                'hold' => 0.25,
                default => 0,
            } * 100;
    }


    public function allOrder(){
        $carts = Cart::query()
        ->where('status','=','hold')
        ->orWhere('status','=','preparing')
        ->orWhere('status', '=', 'serving')
            ->with('table', 'menu', 'menu.type', 'menu.category')
            ->orderBy('updated_at', 'desc')
            ->get();

        $carts = $carts->map(
            function ($item) use ($carts) {
                return [
                    'id' => $item->menu->id,
                    'name' => $item->menu->name,
                    'table' => $item->table->name,
                    'group' => $item->group,
                    'price' => $item->menu->price,
                    'cart_id' => $item->id,
                    'status' => $item->status,
                    'category' => $item->menu->category->name,
                    'type' => $item->menu->type->name,
                    'image' =>  $item->menu->image,
                    'quantity' => $item->quantity,
                    'progress' => $this->calculateProgress($item),
                    'created_at' => $item->created_at,
                    'updated_at' => $item->updated_at,

                ];
            }
        );
        return response($carts->toJson());

    }

    public function changeStatus(Request $request)
    {
        $cart = Cart::find($request->id);
        $cart->update(['status' => $request->status]);
        return ;
    }


}
