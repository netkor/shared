<?php

namespace App\Http\Controllers\Api;

use App\Models\Setting;

class SettingsAPIController
{

    public function __invoke()
    {
        $settings = Setting::query()->where('key', 'payment_method')->first();
        return response()->json($settings);
    }
}
