<?php

namespace App\Http\Controllers\Api;

use App\Models\Card;
use Illuminate\Http\Request;

class CardAPIController
{

    public function __invoke(Request $request)
    {

        $card = Card::query()
            ->where('name', $request->get('name'))
            ->first();

        if ($card) {
            return response()->json([...$card->toArray(),'balance' => $card->balance()]);
        } else {
            return response()->json(['message' => 'Card not found'], 404);
        }
    }


}
