<?php

namespace App\Http\Controllers\Api;

use App\Models\Card;
use Illuminate\Http\Request;

class CardsAPIController
{

    public function __invoke()
    {
        $cards =Card::query()->get();
        return response()->json(

             $cards->map(function ($card) {
                return [
                     ...$card->toArray(),

                    'balance' => $card->balance(),
                ];
            }),
        );
    }

    public function store(Request $request)
    {
        //validate incoming request
        $request->validate( [
            'name' => 'required',
            'address' => 'required',
        ]);

        //create new card
        $card = new Card;
        $card->name = $request->input('name');
        $card->address = $request->input('address');
        $card->save();
        return response()->json(['card' => $card, 'message' => 'Created successfully'], 201);


    }



}
