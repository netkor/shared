<?php

namespace App\Http\Controllers\Api;

use App\Models\Account;
use App\Models\Setting;

class AccountsAPIController
{

    public function __invoke()
    {
        $accounts = Account::query()->get();
        return response()->json($accounts);
    }
}
