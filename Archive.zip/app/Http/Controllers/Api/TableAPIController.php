<?php

namespace App\Http\Controllers\Api;

use App\Models\Table;
use Illuminate\Http\Request;


class TableAPIController

{

    public function __invoke(Request $request)

    {

        $tables = Table::query();

        if ($request->search) {

            $tables = $tables->where('name', 'LIKE', "%{$request->search}%");

        }

        $tables = $tables->get();

        return $tables;

    }

}

