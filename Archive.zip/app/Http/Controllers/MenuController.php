<?php

namespace App\Http\Controllers;

use App\DataTables\MenuDataTable;
use App\Http\Requests\StoreMenuRequest;
use App\Http\Requests\UpdateMenuRequest;
use App\Http\Resources\MenuResource;
use App\Models\Category;
use App\Models\Menu;
use App\Models\Type;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\View\Factory;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class MenuController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index(MenuDataTable $menuDataTable)
    {
        return $menuDataTable->render('menus.index');
    }


    public function posMenu(Request $request)
    {

        $pos_menus = Menu::query()->with('ingredients.product');

        if ($request->search) {
            $pos_menus = $pos_menus->where('name', 'LIKE', "%{$request->search}%");
        }

        $pos_menus = $pos_menus->get();

        $menus = collect();

        foreach ($pos_menus as $pos_menu) {
            $menus->push($this->accept($pos_menu));
        }
        $menus = $menus->reject(function ($menu) {
            return $menu->count() == 0;
        });


        return MenuResource::collection($menus);
    }

    private function accept($menu)
    {
        if (!$menu->ingredients->count() > 0) {
            return collect();
        }

        foreach ($menu->ingredients as $ingredient) {
            if ($ingredient->should_be_in_stock) {


                if ($ingredient->quantity >= $ingredient->product->remaining_stock) {
                    return collect();
                }
            }
        }

        return $menu;

    }

    /**
     * Display the specified resource.
     *
     * @param Menu $menu
     * @return Application|Factory|View
     */
    public function show(Menu $menu)
    {
        return view('menus.show', compact('menu'));

    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Menu $menu): Application|Factory|View
    {

        $types = Type::query()->select('id', 'name')->get()->pluck('name', 'id');
        $categories = Category::query()->select('id', 'name')->get()->pluck('name', 'id');

        $selectedCategory = $menu->category_id;
        $selectedType = $menu->type_id;

        return view('menus.edit')
            ->with('types', $types)
            ->with('categories', $categories)
            ->with('selectedCategory', $selectedCategory)
            ->with('selectedType', $selectedType)
            ->with('menu', $menu);

    }

    public function update(UpdateMenuRequest $request, Menu $menu): RedirectResponse
    {
        $menu->update(
            [
                'name' => $request->get('name'),
                'price' => $request->get('price'),
                'type_id' => $request->get('type_id'),
                'category_id' => $request->get('category_id')
            ]
        );

        $request->whenHas('image', function () use ($menu) {
            $menu->clearMediaCollection('menus')->addMediaFromRequest('image')->toMediaCollection('menus');
        });

        return redirect()->route('menus.index')->with('success', " Menu updated successfully");
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreMenuRequest $request): RedirectResponse
    {

        $menu = Menu::query()->create(
            [
                'name' => $request->get('name'),
                'price' => $request->get('price'),
                'type_id' => $request->get('type_id'),
                'category_id' => $request->get('category_id')
            ]
        );

        $request->whenHas('image', function () use ($menu) {
            $menu->clearMediaCollection('menus')->addMediaFromRequest('image')->toMediaCollection('menus');
        });

        return redirect()->route('menus.index')->with('success', "{$menu->name} Menu created successfully");

    }

    /**
     * Show the form for creating a new resource.
     */
    public function create(): Application|Factory|View
    {
        $types = Type::query()->select('id', 'name')->get()->pluck('name', 'id');
        $categories = Category::query()->select('id', 'name')->get()->pluck('name', 'id');

        $selectedCategory = [];
        $selectedType = [];

        return view('menus.create')
            ->with('types', $types)
            ->with('categories', $categories)
            ->with('selectedCategory', $selectedCategory)
            ->with('selectedType', $selectedType);


    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Menu $menu): RedirectResponse
    {
        $menu->delete();

        return redirect()->route('menus.index')->with('success', "{$menu->name} Menu deleted successfully");
    }
}
