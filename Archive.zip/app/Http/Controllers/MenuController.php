<?php

namespace App\Http\Controllers;

use App\DataTables\MenuDataTable;
use App\Http\Requests\StoreMenuRequest;
use App\Http\Requests\UpdateMenuRequest;
use App\Http\Resources\MenuResource;
use App\Models\Category;
use App\Models\Menu;
use App\Models\Type;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class MenuController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index(MenuDataTable $menuDataTable)
    {
        return $menuDataTable->render('menus.index');
    }


    public function posMenu(Request $request)
    {

        $pos_menus = Menu::query()->with('ingredients.product');

        if ($request->search) {
            $pos_menus = $pos_menus->where('name', 'LIKE', "%{$request->search}%");
        }

        $pos_menus = $pos_menus->get();

        $menus = collect();

        foreach ($pos_menus as $pos_menu) {
            $menus->push($this->accept($pos_menu));
        }
        $menus = $menus->reject(function ($menu) {
            return $menu->count() == 0;
        });


        return MenuResource::collection($menus);
    }

    private function accept($menu)
    {
        if (!$menu->ingredients->count() > 0) {
            return collect();
        }

        foreach ($menu->ingredients as $ingredient) {
            if ($ingredient->should_be_in_stock) {


                if ($ingredient->quantity >= $ingredient->product->remaining_stock) {
                    return collect();
                }
            }
        }

        return $menu;

    }

    /**
     * Display the specified resource.
     *
     * @param Menu $menu
     * @return Response
     */
    public function show(Menu $menu)
    {
        return view('menus.show', compact('menu'));

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param Menu $menu
     * @return Response
     */
    public function edit(Menu $menu)
    {

        $types = Type::query()->select('id', 'name')->get()->pluck('name', 'id');
        $categories = Category::query()->select('id', 'name')->get()->pluck('name', 'id');

        $selectedCategory = $menu->category_id;
        $selectedType = $menu->type_id;

        return view('menus.edit')
            ->with('types', $types)
            ->with('categories', $categories)
            ->with('selectedCategory', $selectedCategory)
            ->with('selectedType', $selectedType)
            ->with('menu', $menu);


    }

    /**
     * Update the specified resource in storage.
     *
     * @param UpdateMenuRequest $request
     * @param Menu $menu
     * @return Response
     */
    public function update(UpdateMenuRequest $request, Menu $menu)
    {
        $menu->update(
            [
                'name' => $request->get('name'),
                'price' => $request->get('price'),
//                'image' => $request->hasFile('image') ? $request->file('image')->store('menus', 'public') : $menu->image,
                'type_id' => $request->get('type_id'),
                'category_id' => $request->get('category_id')
            ]
        );

        $menu->addMediaFromRequest('image')->toMediaCollection('menus');


        return redirect()->route('menus.index')->with('success', " Menu updated successfully");

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param StoreMenuRequest $request
     * @return Response
     */
    public function store(StoreMenuRequest $request)
    {

        $menu = Menu::query()->create(
            [
                'name' => $request->get('name'),
                'price' => $request->get('price'),
//                'image' => $request->hasFile('image') ? $request->file('image')->store('menus', 'public') : null,
                'type_id' => $request->get('type_id'),
                'category_id' => $request->get('category_id')
            ]
        );

        $menu->addMediaFromRequest('image')->toMediaCollection('menus');


        return redirect()->route('menus.index')->with('success', "{$menu->name} Menu created successfully");

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        $types = Type::query()->select('id', 'name')->get()->pluck('name', 'id');
        $categories = Category::query()->select('id', 'name')->get()->pluck('name', 'id');

        $selectedCategory = [];
        $selectedType = [];

        return view('menus.create')
            ->with('types', $types)
            ->with('categories', $categories)
            ->with('selectedCategory', $selectedCategory)
            ->with('selectedType', $selectedType);


    }

    /**
     * Remove the specified resource from storage.
     *
     * @param Menu $menu
     * @return Response
     */
    public function destroy(Menu $menu)
    {

        $menu->delete();

        return redirect()->route('menus.index')->with('success', "{$menu->name} Menu deleted successfully");

    }
}
