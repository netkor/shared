<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreCategoryRequest;
use App\Http\Requests\UpdateCategoryRequest;
use App\Models\category;
use Illuminate\Http\Response;

class CategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
        $categories = Category::query()->get();
        return view('categories.index', compact('categories'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param StoreCategoryRequest $request
     * @return Response
     */
    public function store(StoreCategoryRequest $request)
    {
        $category = Category::create($request->validated());


        if ($category) {
            return redirect()->route('categories.index')->with('success', 'Category created successfully');
        }
        return back()->withInput()->with('errors', 'Error creating new category');

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        $categories = Category::query()->select('id', 'name')->get();

        return view('categories.create', compact('categories'));
    }

    /**
     * Display the specified resource.
     *
     * @param category $category
     * @return Response
     */
    public function show(category $category)
    {
        return view('categories.show', compact('category'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param category $category
     * @return Response
     */
    public function edit(category $category)
    {
        $categories = Category::query()->select('id', 'name')->get();
        $selectedCategory = $category->parent_id;
        return view('categories.edit', compact('category', 'categories', 'selectedCategory'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param UpdateCategoryRequest $request
     * @param category $category
     * @return Response
     */
    public function update(UpdateCategoryRequest $request, category $category)
    {
        $categoryUpdate = $category->update([
            'name' => $request->name,
            'description' => $request->description,
        ]);
        if ($categoryUpdate) {
            return redirect()->route('categories.index')->with('success', 'Category updated successfully');
        }
        return back()->withInput();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param category $category
     * @return Response
     */
    public function destroy(category $category)
    {
        $findcategory = $category->delete();
        if ($findcategory) {
            return redirect()->route('categories.index')->with('success', 'Category deleted successfully');
        }
        return back()->withInput()->with('error', 'Category could not be deleted');
    }
}
