<?php

namespace App\Http\Controllers;

use App\Http\Requests\StorePermissionRequest;
use App\Http\Requests\UpdatePermissionRequest;
use App\Http\Resources\PermissionResource;
use App\Http\Resources\RoleResource;
use App\Models\Permission;
use App\Models\Role;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class PermissionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index(Request $request)
    {
        $permissions = Permission::query();

        if ($request->search) {
            $permissions = $permissions->where('name', 'LIKE', "%{$request->search}%");
        }

        $permissions = $permissions->orderBy('name')->get();

        if ($request->wantsJson()) {
            return PermissionResource::collection($permissions);
        }


        return view('permissions.index');
    }

    public function getRoles(Request $request)
    {
        $roles = Role::with('permissions')->get();
        if ($request->wantsJson()) {
            return RoleResource::collection($roles);
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param StorePermissionRequest $request
     * @return Response
     */
    public function store(StorePermissionRequest $request)
    {

        $permission = Permission::query()->create([
            'name' => $request->get('name'),
            'guard_name' => 'web',

        ]);

        if (!$permission) {
            return redirect()->back()->with('error', 'Permission could not be created');
        }
        return redirect()->back()->with('success', 'Permission created successfully');


    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param Permission $permission
     * @return Response
     */
    public function show(Permission $permission)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param Permission $permission
     * @return Response
     */
    public function edit(Permission $permission)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param UpdatePermissionRequest $request
     * @param Permission $permission
     * @return Response
     */
    public function update(UpdatePermissionRequest $request, Permission $permission)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param Permission $permission
     * @return Response
     */
    public function destroy(Permission $permission)
    {

        $permission->delete();
        return redirect()->back()->with('success', 'Permission deleted successfully');
    }


    public function refreshPermissions(Request $request)
    {
        dd($request->all());

    }

    public function givePermissionToRole(Request $request)
    {
        $role = Role::query()->find($request->get('roleId'));
        $role->givePermissionTo($request->get('permission'));
        return redirect()->back()->with('success', 'Permission given to role successfully');

    }

    public function revokePermissionToRole(Request $request)
    {
        $role = Role::query()->find($request->get('roleId'));
        $role->revokePermissionTo($request->get('permission'));
        return redirect()->back()->with('success', 'Permission revoked from role successfully');


    }

    public function roleHasPermission(Request $request)
    {
        dd($request->all());

    }


}
