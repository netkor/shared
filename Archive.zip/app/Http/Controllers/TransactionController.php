<?php

namespace App\Http\Controllers;

use App\DataTables\TransactionDataTable;
use App\Enums\TransactionStatus;
use App\Http\Requests\StoreTrasactionRequest;
use App\Http\Requests\UpdateTrasactionRequest;
use App\Models\Transaction;
use Illuminate\Http\Response;

class TransactionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index(TransactionDataTable $transactionDataTable)
    {
        //get all Transaction order by created_at desc
        $transactions = Transaction::orderBy('created_at', 'desc')->get();

        return $transactionDataTable->render('transactions.index');

        // return view('transactions.index', compact('transactions'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param StoreTrasactionRequest $request
     * @return Response
     */
    public function store(StoreTrasactionRequest $request)
    {
        $previousBalance = auth()->user()->currentBranch()->balance??0;

        if ($request->get('amount') > $previousBalance) {
            return redirect()->back()->with('error', 'You can not cash out more than your balance');
        }

        $amount = 0;

        if ($request->get('transactionable_type') == 'Cash In') {
            $amount = $request->get('amount');
        } else if ($request->get('transactionable_type') == 'Cash Out') {
            $amount = -$request->get('amount');
        }

        auth()->user()->currentBranch()->transactions()->create([
            'ref_code' => Transaction::generateRefCode("DPO"),
            'note' => $request->get('note'),
            'source' => 'Deposit',
            'status' => TransactionStatus::COMPLETED,
            'amount' => $amount,
            'parent_id' => $request->get('parent_id'),
            'balance' => $previousBalance? + $amount : 0,
        ]);

        return redirect()->route('transactions.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        return view('transactions.create');
    }

    /**
     * Display the specified resource.
     *
     * @param Transaction $trasaction
     * @return Response
     */
    public function show(Transaction $trasaction)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param Transaction $trasaction
     * @return Response
     */
    public function edit(Transaction $trasaction)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param UpdateTrasactionRequest $request
     * @param Transaction $trasaction
     * @return Response
     */
    public function update(UpdateTrasactionRequest $request, Transaction $trasaction)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param Transaction $trasaction
     * @return Response
     */
    public function destroy(Transaction $trasaction)
    {
        //
    }
}
