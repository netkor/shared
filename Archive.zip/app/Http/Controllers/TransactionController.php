<?php

namespace App\Http\Controllers;

use App\DataTables\DaybookDataTable;
use App\DataTables\TransactionDataTable;
use App\Enums\TransactionStatus;
use App\Http\Requests\StoreTrasactionRequest;
use App\Http\Requests\UpdateTrasactionRequest;
use App\Models\Account;
use App\Models\Transaction;
use App\Models\Vendor;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\View\Factory;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Response;

class TransactionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index(TransactionDataTable $transactionDataTable)
    {
        return $transactionDataTable->render('transactions.index');
    }

    public function daybookindex(DaybookDataTable $daybookDataTable)
    {
        $daybook = Transaction::orderBy('created_at', 'desc')->get();

        return $daybookDataTable->render('daybook.index');

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param StoreTrasactionRequest $request
     * @return RedirectResponse
     */
    public function store(StoreTrasactionRequest $request)
    {
        $account = Account::find($request->account);

        $previousBalance = $account->balance();

        if ($request->get('transactionable_type') == 'Cash Out') {
            if ($request->get('amount') > $previousBalance) {
                return redirect()->back()->with('error', 'You can not cash out more than your balance');
            }
        }

        $amount = 0;

        if ($request->get('transactionable_type') == 'Cash In') {
            $amount = $request->get('amount');
        } else if ($request->get('transactionable_type') == 'Cash Out') {
            $amount = -$request->get('amount');
        }


        $account->transactions()->create([
            'ref_code' => Transaction::generateRefCode("DPO"),
            'source' => 'Deposit',
            'status' => TransactionStatus::COMPLETED,
            'amount' => $amount,
            'note' => $request->get('note'),
            'parent_id' => $request->get('parent_id'),
            'balance' => $previousBalance + $amount,
//            'balance' => $previousBalance ? +$amount : 0,
        ]);

        return redirect()->route('transactions.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Application|Factory|View
     */
    public function create()
    {
        $accounts = Account::all();
        $vendors = Vendor::all();
        return view('transactions.create', compact('accounts', 'vendors'));
    }

    /**
     * Display the specified resource.
     *
     * @param Transaction $trasaction
     * @return Response
     */
    public function show(Transaction $trasaction)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param Transaction $trasaction
     * @return Response
     */
    public function edit(Transaction $trasaction)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param UpdateTrasactionRequest $request
     * @param Transaction $trasaction
     * @return Response
     */
    public function update(UpdateTrasactionRequest $request, Transaction $trasaction)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param Transaction $trasaction
     * @return Response
     */
    public function destroy(Transaction $trasaction)
    {
        //
    }
}
