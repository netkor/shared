<?php

namespace App\Http\Controllers;

use App\DataTables\ItemTransactionDataTable;
use App\DataTables\ProductDataTable;
use App\DataTables\Scopes\ItemTransactionOfProduct;
use App\Http\Requests\ProductStoreRequest;
use App\Http\Requests\ProductUpdateRequest;
use App\Http\Resources\ProductResource;
use App\Models\Category;
use App\Models\Product;
use App\Models\Type;
use App\Models\Unit;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\View\Factory;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Storage;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index(ProductDataTable $productDataTable, Request $request)
    {
//        return $productDataTable->render('product.index');
        $products = new Product();

        if ($request->search) {
            $products = $products->where('name', 'LIKE', "%{$request->search}%");
        }

        $products = $products->with('variants')->latest()->get();
        $pos_products = $products->where('status', 1);

        if (request()->wantsJson()) {

            return ProductResource::collection($pos_products);
        }

        return view('products.index')->with('products', $products);
    }

    /**
     * Display the specified resource.
     *
     * @param Product $product
     * @return Response
     */
    public function show(Product $product)
    {
        $itemTransactionDataTables = new ItemTransactionDataTable();
        // add scope to filter by product id
        $itemTransactionDataTables->addScope(new ItemTransactionOfProduct($product->id));

        return $itemTransactionDataTables->render('products.show', compact('product'));

//        return view('products.show')->with('product', $product);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param Product $product
     * @return Application|Factory|View
     */
    public function edit(Product $product)
    {
        $categories = Category::select('id', 'name')->get()->mapWithKeys(function ($category) {
            return [$category->id => $category->name];
        });

        $types = Type::select('id', 'name')->get()->mapWithKeys(function ($type) {
            return [$type->id => $type->name];
        });

        $units = Unit::query()
            ->where('id', $product->keeping_unit_id)
            ->whereNull('parent_id')
            ->select('id', 'name')
            ->get()
            ->mapWithKeys(function ($unit) {
                return [$unit->id => $unit->name];
            });

        $selectedUnit = $product->keeping_unit_id;

        $selectedCategory = $product->category_id;

        $selectedType = $product->type_id;

        return view('products.edit')
            ->with('product', $product)
            ->with('categories', $categories)
            ->with('selectedCategory', $selectedCategory)
            ->with('types', $types)
            ->with('selectedType', $selectedType)
            ->with('units', $units)
            ->with('selectedUnit', $selectedUnit);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param Request $request
     * @param Product $product
     * @return Response
     */
    public function update(ProductUpdateRequest $request, Product $product)
    {
        $product->name = $request->name;
        $product->description = $request->description;
        $product->status = $request->status;
        $product->remaining_stock = $request->get('remaining_stock', 0);
        $product->keeping_unit_id = $request->keeping_unit_id;

        if ($request->hasFile('image')) {
            // Delete old image
            if ($product->image) {
                Storage::delete($product->image);
            }

            $product->addMediaFromRequest('products')->toMediaCollection('menus');


//            // Store image
//            $image_path = $request->file('image')->store('products', 'public');
//            // Save to Database
//            $product->image = $image_path;
        }

        if (!$product->save()) {
            return redirect()->back()->with('error', 'Sorry, there\'re a problem while updating product.');
        }
        return redirect()->route('products.index')->with('success', 'Success, your product have been updated.');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param Request $request
     * @return Response
     */
    public function store(ProductStoreRequest $request)
    {
//        $image_path = '';


        $product = Product::query()->create([
            'name' => $request->get('name'),
            'description' => $request->get('description'),
//            'image' => $image_path,
            'keeping_unit_id' => $request->get('keeping_unit_id'),
            'remaining_stock' => $request->get('remaining_stock', 0),
            'status' => $request->get('status') ?? 0,
        ]);

        if ($request->hasFile('image')) {
            $product->addMediaFromRequest('image')->toMediaCollection('menus');

//            $image_path = $request->file('image')->store('products', 'public');
        }

        if (!$product) {
            return redirect()->back()->with('error', 'Sorry, there a problem while creating product.');
        }

        return redirect()->route('products.index')->with('success', 'Success, you product have been created.');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        $product = new Product();

        $categories = Category::select('id', 'name')->get()->mapWithKeys(function ($category) {
            return [$category->id => $category->name];
        });

        $types = Type::select('id', 'name')->get()->mapWithKeys(function ($type) {
            return [$type->id => $type->name];
        });

        $units = Unit::query()->whereNull('parent_id')->select('id', 'name')->get()->mapWithKeys(function ($unit) {
            return [$unit->id => $unit->name];
        });

        $selectedCategory = null;
        $selectedUnit = null;

        $selectedType = null;

        return view('products.create')
            ->with('product', $product)
            ->with('categories', $categories)
            ->with('selectedCategory', $selectedCategory)
            ->with('types', $types)
            ->with('selectedType', $selectedType)
            ->with('units', $units)
            ->with('selectedUnit', $selectedUnit);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param Product $product
     * @return Response
     */
    public function destroy(Product $product)
    {
        if ($product->image) {
            Storage::delete($product->image);
        }
        $product->delete();

        return redirect()->route('products.index')->with('success', 'Success, you product cipe have been deleted.');
    }

    //price update
    public function updatePrice(Request $request, Product $product)
    {
        $request->validate([
            'price' => 'required|numeric'
        ]);
        //check if latest price is same as new price
        if ($product->price->price == $request->price) {
            return redirect()->back()->with('error', 'Sorry, the price is same as the latest price.');
        }
        $product->price()->create([
            'price' => $request->price
        ]);

        return redirect()->back()->with('success', 'Success, your product price have been updated.');
    }

    public function adjustments(Product $product): Factory|View|Application
    {
        $product->load('keepingUnit');
        $units = Unit::query()->where('physical_quantity', $product->keepingUnit->physical_quantity)->get();
//        $units = Unit::tree($product->keepingUnit->physical_quantity);


        return view('products.adjustment')
            ->with('units', $units)
            ->with('product', $product);
    }


}
