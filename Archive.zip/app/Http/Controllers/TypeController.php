<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreTypeRequest;
use App\Http\Requests\UpdateTypeRequest;
use App\Models\Type;
use Illuminate\Http\Response;

class TypeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
        $types = Type::query()->get();
        return view('types.index', compact('types'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param StoreTypeRequest $request
     * @return Response
     */
    public function store(StoreTypeRequest $request)
    {

        $type = Type::create($request->validated());
        if ($type) {
            return redirect()->route('types.index')->with('success', 'Type created successfully');
        }
        return back()->withInput()->with('errors', 'Error creating new type');

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        return view('types.create');

    }

    /**
     * Display the specified resource.
     *
     * @param Type $type
     * @return Response
     */
    public function show(Type $type)
    {
        $type = Type::find($type->id);
        return view('types.show', compact('type'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param Type $type
     * @return Response
     */
    public function edit(Type $type)
    {
        $type = Type::find($type->id);
        return view('types.edit', compact('type'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param UpdateTypeRequest $request
     * @param Type $type
     * @return Response
     */
    public function update(UpdateTypeRequest $request, Type $type)
    {
        $typeUpdate = Type::where('id', $type->id)
            ->update([
                'name' => $request->input('name'),
            ]);
        if ($typeUpdate) {
            return redirect()->route('types.index', $type->id)->with('success', 'Type updated successfully');
        }
        return back()->withInput();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param Type $type
     * @return Response
     */
    public function destroy(Type $type)
    {
        $findType = Type::find($type->id);
        if ($findType->delete()) {
            return redirect()->route('types.index')->with('success', 'Type deleted successfully');
        }
        return back()->withInput()->with('error', 'Type could not be deleted');
    }
}
