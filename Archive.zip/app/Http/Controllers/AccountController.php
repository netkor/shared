<?php

namespace App\Http\Controllers;

use App\DataTables\AccountDataTable;
use App\Http\Requests\StoreAccountRequest;
use App\Http\Requests\UpdateAccountRequest;
use App\Models\Account;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\View\Factory;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;


class AccountController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index(AccountDataTable $dataTable, Request $request)
    {
        return $dataTable->render('finance.accounts.index');
    }

    public function list(Request $request)
    {
        if ($request->wantsJson()) {
            $accounts = Account::with('branch')->get();
            return response($accounts);
        }
    }

    public function store(StoreAccountRequest $request): RedirectResponse
    {

        auth()->user()->currentBranch()->accounts()->create($request->validated());

//        $account = Account::create([...$request->validated(), 'holder_id' => auth()->user()->currentBranch()->id, 'holder_type' => 'branch']);

        return redirect()->route('accounts.index')->with('success', 'Account created successfully.');
    }


    public function create(): Application|Factory|View
    {
        return view('finance.accounts.create');
    }

    /**
     * Display the specified resource.
     *
     * @param Account $account
     * @return Response
     */
    public function show(Account $account)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param Account $account
     * @return Response
     */
    public function edit(Account $account)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param UpdateAccountRequest $request
     * @param Account $account
     * @return Response
     */
    public function update(UpdateAccountRequest $request, Account $account)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param Account $account
     * @return Response
     */
    public function destroy(Account $account)
    {
        //
    }
}
