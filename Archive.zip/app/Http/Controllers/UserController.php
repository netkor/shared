<?php

namespace App\Http\Controllers;

use App\Models\Branch;
use App\Models\Role;
use App\Models\User;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\View\Factory;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
        if (!auth()->user()->roles()->exists()) {
            return redirect()->back()->with('error', 'You are not authorized to access this page');
        }

        $users = User::query()
            ->with('roles')
            ->whereHas('roles', function ($query) {
                $query->where('level', '>=', auth()->user()->roles->first()->level);
            })
            ->latest()
            ->paginate(10);

        return view('users.index')->with('users', $users);


    }

    /**
     * Store a newly created resource in storage.
     *
     * @param Request $request
     * @return Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'first_name' => 'required',
            'last_name' => 'required',
            'email' => 'required|email|unique:users',
            'phone' => 'required',
            'address' => 'required',
            'status' => 'required',
        ]);

        $user = User::create([
            'first_name' => $request->first_name,
            'last_name' => $request->last_name,
            'email' => $request->email,
            'phone' => $request->phone,
            'address' => $request->address,
            'password' => bcrypt($request->password ?? '12345678'),
            'api_token' => str()->random(60),
            'status' => $request->status,
            'branch_id' => $request->branch_id,
            'role_id' => $request->role_id,
        ]);

        $user->branches()->sync($request->branch_id);
        $user->roles()->sync($request->role_id);

        if (!$user) {
            return redirect()->back()->with('error', 'User could not be created');
        }
        return redirect()->route('users.index')->with('success', 'User created successfully.');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        $roles = Role::query()
            ->where('level', '>', auth()->user()->roles->first()->level)
            ->select('id', 'name')
            ->get()
            ->mapWithKeys(function ($role) {
                return [$role->id => $role->name];
            });
//            ->pluck('name', 'id');


        $branches = Branch::all()->pluck('name', 'id');
        $selectedRole = null;
        $selectedBranch = null;

        return view('users.create', compact('roles', 'branches', 'selectedRole', 'selectedBranch'));
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id): Application|Factory|View
    {
        $user = User::find($id);
        return view('users.show')->with('user', $user);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id): Application|Factory|View|RedirectResponse
    {

        if (!auth()->user()->roles()->exists()) {
            return redirect()->back()->with('error', 'You are not authorized to access this page');
        }

        $authLevel = auth()->user()->roles->first()->level;

        // unauthorized user can't edit user with higher level
        if (User::find($id)->roles->first()->level < $authLevel) {
            return redirect()->back()->with('error', 'You are not authorized to access this page');
        }


        $roles = Role::query()->where('level', '>', auth()->user()->roles->first()->level)
            ->select('id', 'name')->get()->pluck('name', 'id');

        $user = User::find($id);
        $branches = Branch::select('id', 'name')->get()->pluck('name', 'id');
        $selectedRole = $user->roles->first()->id ?? '';
        $selectedBranch = $user->currentBranch()?->id ?? "";

        return view('users.edit', compact('user', 'roles', 'branches', 'selectedRole', 'selectedBranch',));
    }


    public function update(Request $request, string $id): RedirectResponse
    {
        $request->validate([
            'first_name' => 'required',
            'last_name' => 'required',
            'email' => 'required|email|unique:users,email,' . $id,
            'password' => 'nullable|min:6',
            'phone' => 'required',
            'address' => 'required',
            'status' => 'required',
        ]);
        $user = User::find($id);
        $user->first_name = $request->first_name;
        $user->last_name = $request->last_name;
        $user->email = $request->email;
        $user->password = $request->password ? bcrypt($request->password) : $user->password;
        $user->phone = $request->phone;
        $user->address = $request->address;
        $user->api_token = str()->random(60);
        $user->email_verified_at = now();
        $user->status = $request->status;
        $user->save();

        $user->branches()->sync($request->branch_id);
        $user->roles()->sync($request->role_id);

        if (!$user) {
            return redirect()->back()->with('error', 'User could not be updated');
        }
        return redirect()->route('users.index')->with('success', 'User updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     * @return Response
     */
    public function destroy($id)
    {
        $user = User::find($id);
        $user->delete();
        if (!$user) {
            return redirect()->back()->with('error', 'User could not be deleted');
        }
        return redirect()->route('users.index')->with('success', 'User deleted successfully.');
    }

}
