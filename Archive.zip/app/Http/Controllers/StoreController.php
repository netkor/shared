<?php

namespace App\Http\Controllers;

use App\DataTables\StoreDataTable;
use App\Http\Requests\StoreStoreRequest;
use App\Http\Requests\UpdateStoreRequest;
use App\Models\Inventory;
use App\Models\Store;
use App\Models\Unit;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\View\Factory;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class StoreController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index(StoreDataTable $storeDataTable,Request $request)
    {
        $stores = new Store();

//        if ($request->search) {
//            $stores = $stores->where('name', 'LIKE', "%{$request->search}%");
//            $stores = $stores->orWhere('barcode', 'LIKE', "%{$request->search}%");
//        }

        $stores = $stores->latest()->paginate(10);
        //stores with products


        if (request()->wantsJson()) {

            return $stores;
        }

        return $storeDataTable->render('store.index', compact('stores'));


    }


    /**
     * Store a newly created resource in storage.
     *
     * @param StoreStoreRequest $request
     * @return Response
     */
    public function store(StoreStoreRequest $request)
    {
        $columns = $request->input('data');


        $inventory = $columns[0];
        $store = $columns[1]['items'];
        $bar = $columns[2]['items'];
        $kitchen = $columns[3]['items'];
        $trash = $columns[4]['items'];

        $store = collect($store)->map(function ($item) use ($inventory) {
            return [
                'product_id' => $item['id'],
                'sku' => Str::snake($item['name']),
                'stock' => $item['quantity'],
                'unit_id' => $item['unit_id'],
                'inventory_id' => $inventory['id'],
                'price' => $item['price'] ?? 0,
                'type' => 'store',
            ];
        });

        $bar = collect($bar)->map(function ($item) use ($inventory) {
            return [
                'product_id' => $item['id'],
                'sku' => Str::snake($item['name']),
                'stock' => $item['quantity'],
                'inventory_id' => $inventory['id'],
                'unit_id' => $item['unit_id'],
                'price' => $item['price'],
                'type' => 'bar',
            ];
        });

        $kitchen = collect($kitchen)->map(function ($item) use ($inventory) {
            return [
                'product_id' => $item['id'],
                'sku' => Str::snake($item['name']),
                'stock' => $item['quantity'],
                'unit_id' => $item['unit_id'],
                'inventory_id' => $inventory['id'],
                'price' => $item['price'] ?? 0,
                'type' => 'kitchen',
            ];
        });

        $trash = collect($trash)->map(function ($item) use ($inventory) {
            return [
                'product_id' => $item['id'],
                'sku' => Str::snake($item['name']),
                'stock' => $item['quantity'],
                'inventory_id' => $inventory['id'],
                'unit_id' => $item['unit_id'],
                'price' => $item['price'] ?? 0,
                'type' => 'trash',
            ];
        });

        $store = $store->merge($bar)->merge($kitchen)->merge($trash);

        DB::transaction(function () use ($store) {
            foreach ($store as $item) {
                $store = Store::create($item);
                $store->prices()->create([
                    'price' => $item['price'],
                ]);

                $inventory = Inventory::find($item['inventory_id'])->whereHas('products', function ($query) use ($item) {
                    $query->where('product_id', $item['product_id']);
                })->with('products')->first();

                if ($inventory) {
                    $inventory->products()->updateExistingPivot($item['product_id'], [
                        'stock' => $inventory->products->first()->pivot->stock - $item['stock'],
                    ]);
                }
            }
        });


    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Application|Factory|View
     */
    public function create($inventory)
    {
        $inventory = Inventory::with('products')->findOrFail($inventory);
        $inventory = collect([
            'id' => $inventory->id,
            'name' => 'Inventory Item',
            'editable' => false,
            'type' => 'inventory',
            'items' => $inventory->products->map(function ($product) use ($inventory) {
                return [
                    'id' => $product->id,
                    'identifier' => $product->id . '|' . $inventory->id,
                    'name' => $product->name,
                    'quantity' => $product->pivot->quantity,
                    'stock' => $product->pivot->stock,
                    'type' => \str($product->types->first()?->name)->lower()->__toString(),
                    'unit_name' => Unit::find($product->pivot->unit_id)->name,
                    'unit_id' => $product->pivot->unit_id,
                    'expiry_date' => $product->pivot->expiry_date,
                    'editable' => $product->pivot->stock > 0,
                ];
            }),
        ]);

        $store = [
            'id' => $store_id = Str::uuid(),
            'name' => 'Store',
            'editable' => true,
            'type' => 'store',
            'items' => true ? [] : Store::where('type', 'store')->with('price')->get()->map(function ($store) use ($store_id) {
                return [
                    'id' => $store->id,
                    'identifier' => $store->id . '|' . $store_id,
                    'name' => $store->product->name,
                    'quantity' => $store->stock,
                    'stock' => $store->stock,
                    'type' => \str($store->product->types->first()?->name)->lower()->__toString(),
                    'unit_name' => Unit::find($store->unit_id)->name,
                    'unit_id' => $store->unit_id,
                    'expiry_date' => null,
                    'price' => $store->price->price,
                    'editable' => false,
                ];
            }),
        ];

        $bar = [
            'id' => Str::uuid(),
            'name' => 'Bar',
            'editable' => true,
            'type' => 'bar',
            'items' => [],
        ];

        $kitchen = [
            'id' => Str::uuid(),
            'name' => 'Kitchen',
            'editable' => true,
            'type' => 'kitchen',
            'items' => [],
        ];

        $trash = [
            'id' => Str::uuid(),
            'name' => 'Trash',
            'editable' => false,
            'type' => 'trash',
            'items' => [],
        ];

        $columns = collect([$inventory, $store, $bar, $kitchen, $trash]);


        return view('store.create', compact('columns'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param UpdateStoreRequest $request
     * @param Store $store
     * @return Response
     */
    public function update(UpdateStoreRequest $request, Store $store)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param Store $store
     * @return Response
     */
    public function show(Store $store)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param Store $store
     * @return Response
     */
    public function edit(Store $store)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param Store $store
     * @return Response
     */
    public function destroy(Store $store)
    {
        //
    }
}
