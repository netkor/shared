<?php

namespace App\Http\Controllers;

use App\Enums\TransactionStatus;
use App\Events\CartItemAdded;
use App\Http\Requests\StoreCartRequest;
use App\Models\Cart;
use App\Models\Setting;
use App\Models\Table;
use App\Models\Transaction;
use App\Services\UnitConverter;
use Exception;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;

class CartController extends Controller
{
    public function index(Request $request)
    {
        if ($request->wantsJson()) {

            $cart = Cart::with('menu')->where('table_id', $request->get('table_id'))->get();


            return response($cart);
        }
        $payment_method = Setting::query()->where('key', 'payment_method')->first();
        $user = auth()->user();
        $user->makeVisible('api_token');
        $user->load('roles');
        $role = $user->roles->pluck('name');
        return view('cart.index', compact('payment_method', 'role'));
    }

    // public function dailysalesreport(Request $request)

    // {

    //     $carts = new Cart();
    //     if ($request->get('start_date')) {
    //         $carts = $carts->where('created_at', '>=', $request->start_date);
    //     }
    //     if ($request->get('end_date')) {
    //         $carts = $carts->where('created_at', '<=', $request->end_date . ' 23:59:59');
    //     }
    //     if ($request->get('menu')) {
    //         $carts = $carts->whereHas('menu', function ($q) use ($request) {
    //             return $q->where('name', 'like', '%' . $request->menu . '%');
    //         });
    //     }
    //     $carts = $carts->where('status', 'hold')->orderBy('created_at', 'desc')->get();

    //     $totalQuantity = $carts->sum('quantity');
    //     $totalAmount = $carts->map(function ($cart) {
    //         return $cart->menu->price;
    //     })->sum();


    //     return view('dailysalesreport.index', compact('carts', 'totalQuantity', 'totalAmount'));


    // }

    public function show(Request $request, $id)
    {

        $carts = Cart::where('table_id', $id)->with('menu')->get();

        $products = $carts->map(function ($cart) {
            return [
                'id' => $cart->menu->id,
                'name' => $cart->menu->name,
                'menu_id' => $cart->menu->id,
                'price' => $cart->price,
                'group' => $cart->group,
                'status' => $cart->status,
                'quantity' => $cart->quantity,
                'total' => $cart->menu->price * $cart->quantity,
            ];
        });

        return response($products);
    }

    public function store(StoreCartRequest $request)
    {

        $menu_id = $request->get('menu_id');
        $table_id = $request->get('table_id');

        $cart = Cart::create([
            'user_id' => $request->user()->id,
            'table_id' => $table_id,
            'menu_id' => $menu_id,
            'quantity' => 1,
            'group' => $request->get('group'),
        ]);

        event(new CartItemAdded($cart));

        return response('', 204);
    }

    public function changeQty(Request $request)
    {

        $request->validate([
            'group' => 'required',
            'menu_id' => 'required|exists:menus,id',
            'quantity' => 'required|integer|min:1',
            'table_id' => 'required|exists:tables,id',
        ]);

        try {
            $cart = Cart::query()
                ->where('group', $request->get('group'))
                ->where('table_id', $request->get('table_id'))
                ->where('menu_id', $request->get('menu_id'));


            if ($request->get('quantity') <= 0) {
                $cart->delete();
            } else {
                $cart->update([
                    'quantity' => $request->get('quantity'),
                ]);
            }
        } catch (Exception $e) {
            return response($e->getMessage(), 500);
        }

        return response([
            'success' => true
        ]);
    }

    public function delete(Request $request)
    {

        $request->validate([
            'menu_id' => 'required|exists:menus,id',
            'table_id' => 'required|exists:tables,id',
            'group' => 'required|exists:carts,group',
        ]);

        $carts = Cart::query()
            ->where('table_id', $request->get('table_id'))
            ->where('menu_id', $request->get('menu_id'))
            ->where('group', $request->get('group'))
            ->where('status', '=', 'hold')->get();

        $carts->each(function ($cart) {
            $this->recoverIngredients($cart, $cart->quantity);
        });

        $carts->each->update(['status' => 'deleted']);
        $carts->each->delete();

        return response('', 204);
    }

    private function recoverIngredients($cart, $quantity)
    {
        $ingredients = $cart->menu->ingredients;

        foreach ($ingredients as $ingredient) {

            if ($ingredient->should_reduce_stock) {

                $product = $ingredient->product;

                if ($product->keepingUnit->hierarchy > $ingredient->unit->hierarchy) {
                    $fromUnit = $ingredient->unit;
                    $toUnit = $product->keepingUnit;
                } else {
                    $fromUnit = $product->keepingUnit;
                    $toUnit = $ingredient->unit;
                }

                $converter = new UnitConverter(fromUnit: $fromUnit, toUnit: $toUnit);

                $volume = $converter->convert($ingredient->quantity * (float)$quantity);

                $product->update([
                    'remaining_stock' => $product->remaining_stock + $volume
                ]);
            }
        }
    }

    public function empty(Request $request)
    {
        $request->validate([
            'table_id' => 'required|exists:tables,id'
        ]);
        $cart = Cart::where('table_id', $request->table_id)->first();
        if ($cart->status == "hold") {
            return response([
                'message' => 'You can not empty cart while it is on hold. You have to make a Payment first',
            ], 400);
        }
        $table = $request->table_id;
        Cart::where('table_id', $request->table_id)->where('status', '!=', 'hold')->delete();
        Table::find($table)->update(['status' => "open"]);
        return response('', 204);
    }

    public function swap(Request $request)
    {
        $request->validate([
            'table_id' => 'required|exists:tables,id',
            'new_table_id' => 'required|exists:tables,id'
        ]);

        $cart = Cart::where('table_id', $request->table_id)->first();
        if ($cart->status != "hold") {
            return response([
                'message' => 'you have to hold the cart first to swap',
            ], 400);

        }

        $table = $request->table_id;
        $new_table = $request->new_table_id;

        $carts = Cart::where('table_id', $request->table_id)->get();
        $carts->each->update(['table_id' => $new_table]);

        Table::find($table)->update(['status' => "open"]);
        Table::find($new_table)->update(['status' => "serving"]);
        return response('', 204);
    }

    public function hold(Request $request)
    {

        $request->validate([
            'table_id' => 'required|exists:tables,id'
        ]);

        $table = $request->get('table_id');

        $carts = Cart::query()
            ->with('menu.ingredients')
            ->with('menu.type')
            ->where('table_id', $request->get('table_id'))
            ->whereNotIn('status', ['hold', 'done'])
            ->get();


        $carts->each(function ($cart) {
            $this->reduceIngredients($cart, $cart->quantity);
        });

        $carts->each->update(['status' => "hold"]);

        $items = $carts->groupBy('menu.type.name');

        // foreach ($items as $key => $item) {
        //     $item = $this->makeReadyForPrint($item, $key);
        //     event(new MenuHold($item));
        // }


        Table::find($table)->update(['status' => "hold"]);

        return response('', 204);
    }

    private function reduceIngredients($cart, $quantity)
    {
        $ingredients = $cart->menu->ingredients;

        foreach ($ingredients as $ingredient) {

            if ($ingredient->should_reduce_stock) {

                $product = $ingredient->product;

                // $productUnit = $product->keepingUnit;

                // $ingredientUnit = $ingredient->unit;

                // $volume = $ingredient->quantity * $quantity;


                if ($product->keepingUnit->hierarchy > $ingredient->unit->hierarchy) {
                    $fromUnit = $ingredient->unit;
                    $toUnit = $product->keepingUnit;
                } else {
                    $fromUnit = $product->keepingUnit;
                    $toUnit = $ingredient->unit;
                }

                $converter = new UnitConverter(fromUnit: $fromUnit, toUnit: $toUnit);

                $volume = $converter->convert($ingredient->quantity * (float)$quantity);

                $note = "{$product->name} reduced by {$volume} {$product->keepingUnit->name} for {$cart->menu->name} ({$cart->quantity}x)";

                $this->productTransaction(
                    product: $product,
                    volume: -$volume,
                    type: 'Sale',
                    note: $note
                );


                // while ($productUnit->id != $ingredientUnit->id) {
                //     if ($productUnit->hierarchy < $ingredientUnit->hierarchy) {
                //         $volume = $volume * $productUnit->conversion_factor;
                //         $productUnit = $productUnit->parent;
                //     } else {
                //         $volume = $volume / $ingredientUnit->conversion_factor ?? 1;
                //         $ingredientUnit = $ingredientUnit->parent;
                //     }
                //     if ($ingredientUnit == null) {
                //         break;
                //     }
                // }

                $product->update([
                    'remaining_stock' => $product->remaining_stock - $volume
                ]);
            }

        }
    }

    protected function productTransaction(Model $product, $volume, $type, $note)
    {
        $product->itemTransactions()->create([
            'ref_no' => Transaction::generateRefCode("INV"),
            'note' => $note,
            'source' => $type,
            'unit_id' => $product->keeping_unit_id,
            'status' => TransactionStatus::COMPLETED,
            'quantity' => $volume,
            'stock' => $product->stock() + $volume
        ]);

    }

    protected function makeReadyForPrint($carts, $key)
    {
        $printed_date = date('M d, Y h:i:s');
        $group = "#{$carts?->first()?->group}";
        $table = $carts?->first()?->table->name;
        $user = auth()->user()->first_name;
        $branch = auth()->user()->currentBranch()->name;

        return [
            'title' => config('app.name'),
            'address' => config('settings.address'),
            'email' => config('settings.email'),
            'phone' => config('settings.phone'),
            'event' => str($key)->lower()->append("-event"),
            'table' => $table,
            'group' => $group,
            'printed_date' => $printed_date,
            'type' => 'kot',
            'terminal' => str($key)->ucfirst(),
            'user' => $user,
            'items' => $carts->map(function ($cart) {
                return [
                    'name' => $cart->menu->name,
                    'qty' => $cart->quantity
                ];
            })
        ];
    }

}
