<?php

namespace App\Http\Controllers;

use Exception;
use Mike42\Escpos\PrintConnectors\WindowsPrintConnector;
use Mike42\Escpos\Printer;


class PrintController extends Controller
{

    public function print(): string
    {

//        $printers = new PrintNode('rgXEzdFOVGgGQVay0w0ROn0A09xuO2b3isxCh8Mx9o0');

//        dd($printers->printJob());
//
//
//        $printers = Printing::printers();
//        dd($printers);

//        $printer = new ReceiptPrinter();


        /* Most printers are open on port 9100, so you just need to know the IP
         * address of your receipt printer, and then fsockopen() it on that port.
         */
        try {

            $connector = new WindowsPrintConnector("XP-80C");

            $printer = new Printer($connector);
//            $printer->text("Hello World! \n");
//            $printer->qrCode('Hello mr');
//            $printer->feed(2);
//            $printer->cut();
            $printer->pulse();

            $printer->feed();

            /* Close printer */
            $printer->close();
            return 'Printed';
        } catch (Exception $e) {
            return "Couldn't print to this printer: " . $e->getMessage() . "\n";
        }

//        $filePath = storage_path('app/test.pdf');

//        if (is_writeable($filePath)) {
//            try {
//                shell_exec("copy " . $filePath . ' /B ' . '\\127.0.0.1\printtopdf');
//                return 'Command to print prn file executed successfully';
//            } catch
//            (Exception $e) {
//                return $e->getMessage();
//            }
//        } else {
//            return 'File ' . $filePath . ' is not writable!';
//        }

//        $printJob = Printing::newPrintTask()
//            ->printer(71756362)
//            ->jobTitle('Test Job')
//            ->file(storage_path('app/test.pdf'))
//            ->send();
//
//        $printJob->id();

//        return collect($printJob)->toArray();

    }

}
