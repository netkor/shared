<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UpdateInventoryRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [
            'inventory_id' => 'required|exists:inventories,id',
            'vendor_id' => 'nullable|exists:vendors,id',
            'products' => 'required|array',
//            'products.*.id' => 'required|exists:products,id',
            'products.*.quantity' => 'required|numeric',
            'products.*.cost_price' => 'required|numeric',
            'products.*.variant_id' => 'nullable|exists:variants,id',
            'products.*.expiry_date' => 'nullable|date',
            'products.*.vat' => 'numeric',
            'products.*.discount' => 'numeric',


        ];
    }
}
