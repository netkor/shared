<?php

namespace App\Notifications;

use Benwilkins\FCM\FcmMessage;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;


class NewOrderCreatedNotification extends Notification
{
    use Queueable;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct(protected readonly array $item)
    {
        //
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param mixed $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['fcm'];
    }


    public function toFcm($notifiable)
    {
        $group = $this->item['group'];
        $table = $this->item['table'];

        $message = new FcmMessage();
        $message->content([
            'title' => "New order for $table",
            'body' => "$group Order has been placed on table $table",
            'sound' => 'true', // Optional
            'badge' => '1', // Optional
            'logo' => "https://booster.io/wp-content/uploads/custom-order-numbers-e1438361586475.png", // Optional
            'image' => "https://booster.io/wp-content/uploads/custom-order-numbers-e1438361586475.png", // Optional
//            'click_action' => 'FLUTTER_NOTIFICATION_CLICK' // Optional
            "android_channel_id" => "pos",

        ])->priority(FcmMessage::PRIORITY_HIGH); // Optional - Default is 'normal'.

        return $message;
    }


}
