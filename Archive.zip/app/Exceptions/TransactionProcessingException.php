<?php

namespace App\Exceptions;

use Exception;

class TransactionProcessingException extends Exception
{
}
