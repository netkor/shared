<?php

namespace App\Models;

use App\Contracts\CashTransactionContract;
use App\Models\Traits\HasCashTransaction;
use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Account extends Model implements CashTransactionContract
{
    use HasFactory;
    use HasUuids;
    use HasCashTransaction;

    public function url(): string
    {
        return route('accounts.show', $this);
    }

    public function label(): string
    {
        return $this->ref_no;
    }
}
