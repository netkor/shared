<?php

namespace App\Models;

use App\Contracts\CashTransactionContract;
use App\Models\Traits\HasCashTransaction;
use App\Models\Traits\HasTenant;
use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Account extends Model implements CashTransactionContract
{
    use HasFactory;
    use HasUuids;
    use HasTenant;
    use HasCashTransaction;

    protected $fillable = [
        'name',
        'number',
        'holder_id',
        'holder_type',
        'type',
        'associated_with',
        'status',
        'description',
    ];

    public function url(): string
    {
        return route('accounts.show', $this);
    }

    public function label(): string
    {
        return $this->name;
    }

    public function branch()
    {
        return $this->morphTo();
    }
}
