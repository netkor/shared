<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Tag extends Model
{
    use HasFactory;
    use HasUuids;

    protected $guarded = [];

    public function taggable()
    {
        return $this->morphTo();
    }

    public function scopeCategory($query)
    {
        return $query->where('type', 'category');
    }

    public function scopeType($query)
    {
        return $query->where('type', 'type');
    }

    public function scopeBrand($query)
    {
        return $query->where('type', 'brand');
    }

    public function scopeColor($query)
    {
        return $query->where('type', 'color');
    }

    public function scopeSize($query)
    {
        return $query->where('type', 'size');
    }

    public function scopeMaterial($query)
    {
        return $query->where('type', 'material');
    }

    public function scopeStyle($query)
    {
        return $query->where('type', 'style');
    }

    public function scopeSeason($query)
    {
        return $query->where('type', 'season');
    }

    public function scopeOccasion($query)
    {
        return $query->where('type', 'occasion');
    }

}
