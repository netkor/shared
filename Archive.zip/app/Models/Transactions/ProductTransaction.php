<?php

namespace App\Models\Transactions;

use App\Models\Transaction;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class ProductTransaction extends Transaction
{
    use HasFactory;
    use HasUuids;

    public $table = 'transactions';

    public static function boot()
    {
        parent::boot();

        static::addGlobalScope('account', function (Builder $builder) {
            $builder->where('transactionable_type', 'product');
        });
    }

}
