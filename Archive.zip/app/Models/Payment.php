<?php

namespace App\Models;

use App\Models\Traits\HasTendent;
use App\Models\Traits\TrackActivity;
use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;


class Payment extends Model
{
    use HasTendent;
    use TrackActivity;
    use HasUuids;


    protected $fillable = [
        'amount',
        'order_id',
        'discount_amount',
        'received_amount',
        'return_amount',
    ];
}
