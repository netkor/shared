<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;

class OrderItem extends Model
{
    use HasUuids;

    protected $table = 'order_items';

    protected $fillable = [
        'price',
        'quantity',
        'menu_id',
        'order_id'
    ];

    public function menu()
    {
        return $this->belongsTo(Menu::class);
    }
}
