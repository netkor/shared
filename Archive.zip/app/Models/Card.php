<?php

namespace App\Models;

use App\Contracts\CashTransactionContract;
use App\Models\Traits\HasCashTransaction;
use App\Models\Traits\HasTenant;
use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

class Card extends Model implements CashTransactionContract
{
    use HasFactory;
    use HasUuids;
    use LogsActivity;
    use HasTenant;
    use HasCashTransaction;
    use SoftDeletes;


    protected $fillable = [
        'name',
        'address',
    ];

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->logOnly(['name', 'address'])
            ->logOnlyDirty()
            ->logExcept(['created_at', 'updated_at'])
            ->useLogName('Card');
    }


    public function url(): string
    {
        return route('cards.show', $this);
    }


    public function withdraw(float $amount, string|null $note, $account)
    {
        $this->transactions()->create([
            'ref_code' => $this->generateRefCode('W'),
            'amount' => -$amount,
            'balance' => $this->balance() - $amount,
            'source' => 'withdraw',
            'note' => $note,
        ]);

        $account->transactions()->create([
            'ref_code' => $this->generateRefCode('W'),
            'amount' => -$amount,
            'balance' => $account->balance() - $amount,
            'source' => 'withdraw',
            'note' => $note,
        ]);


    }

    protected function generateRefCode(string $type): string
    {
        return 'CD-' . $type . '-' . now()->timestamp;
    }

    public function deposit(float $amount, string|null $note, $account)
    {
        $this->transactions()->create([
            'ref_code' => $this->generateRefCode('D'),
            'amount' => $amount,
            'balance' => $this->balance() + $amount,
            'source' => 'deposit',
            'note' => $note,
        ]);

        $account->transactions()->create([
            'ref_code' => $this->generateRefCode('W'),
            'amount' => +$amount,
            'balance' => $account->balance() + $amount,
            'source' => 'withdraw',
            'note' => $note,
        ]);

    }

    public function label(): string
    {
        return $this->name;
    }


}
