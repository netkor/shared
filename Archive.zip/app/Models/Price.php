<?php

namespace App\Models;

use App\Models\Traits\HasTendent;
use App\Models\Traits\TrackActivity;
use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

class Price extends Model
{
    use HasFactory;
    use LogsActivity;
    use HasUuids;



    protected $fillable = [
        'pricable_type',
        'pricable_id',
        'price',
    ];

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->logOnly(['price'])
            ->logOnlyDirty()
            ->useLogName('Price');
    }
}
