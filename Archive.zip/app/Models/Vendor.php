<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

class Vendor extends Model
{
    use HasFactory;
    use HasUuids;
    use LogsActivity;


    protected $fillable = [
        'name',
        'address',
        'email',
        'phone',
        'logo',
        'pan_no',
        'vat_no',
        'status',
        'user_id',
    ];


    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->logOnly(['name', 'address', 'email', 'phone', 'logo', 'pan_no', 'vat_no', 'status', 'user_id'])
            ->logExcept(['created_at', 'updated_at'])
            ->useLogName('Vendor');
    }

    public function products()
    {
        return $this->hasMany(Product::class);
    }
}
