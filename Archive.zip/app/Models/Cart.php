<?php

namespace App\Models;

use App\Models\Traits\HasTendent;
use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

class Cart extends Model
{
    use HasTendent;
    use HasUuids;
    use LogsActivity;
    use SoftDeletes;

    protected $table = 'carts';

    protected $fillable = [
        'menu_id', 'quantity', 'table_id', 'status', 'group',
    ];

    public function menu()
    {
        return $this->belongsTo(Menu::class);

    }

    public function table()
    {
        return $this->belongsTo(Table::class);
    }

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->logOnly(['menu_id', 'quantity', 'table_id', 'status', 'group'])
            ->useLogName('Cart');
    }
}
