<?php

namespace App\Models;

use App\Models\Scopes\UserBranch;
use App\Models\Traits\HasTendent;
use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\MorphTo;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;


class Transaction extends Model
{
    use HasFactory;
    use HasUuids;
    use HasTendent;
    use LogsActivity;
    use SoftDeletes;


    public $table = 'transactions';

    protected $fillable = [
        'transactionable_id',
        'transactionable_type',
        'ref_code',
        'note',
        'source',
        'status',
        'amount',
        'parent_id',
        'balance',
    ];

    public static function generateRefCode($char)
    {
        $refCode = 'TR-' . str($char)->upper() . "-" . date('Ymd') . '-' . rand(100000, 999999);
        $checkRefCode = Transaction::where('ref_code', $refCode)->first();
        if ($checkRefCode) {
            return self::generateRefCode($char);
        }
        return $refCode;
    }

    public function transactionable(): MorphTo
    {
        return $this->morphTo()->withoutGlobalScope(UserBranch::class);
    }

//generateRefCode//

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->logExcept(['created_at', 'updated_at'])
            ->logOnlyDirty()
            ->dontSubmitEmptyLogs()
            ->setDescriptionForEvent(function (string $eventName) {

                return "{$eventName} " . Str::singular($this->transactionable_type);
            })
            ->useLogName('Trasaction');
    }


}
