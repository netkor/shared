<?php

namespace App\Models\Traits;

use App\Models\Price;

trait HasPrice
{
    public function price()
    {
        return $this->morphOne(Price::class, 'pricable')->latest();
    }

    public function prices()
    {
        return $this->morphMany(Price::class, 'pricable')->orderBy('created_at', 'desc');
    }

}
