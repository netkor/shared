<?php

namespace App\Models\Traits;

use App\Models\Scopes\UserBranch;
use App\Models\Tenant;


trait HasTendent
{

    public static function bootHasTendent()
    {

        static::addGlobalScope(new UserBranch);

        static::created(function ($model) {
            if (auth()->user()->currentBranch()) {
                Tenant::firstOrCreate([
                    'tenantable_type' => strtolower(class_basename($model)),
                    'tenantable_id' => $model->id,
                    // 'branch_id' => 1,
                    'branch_id' => auth()->user()->currentBranch()?->id,
                ]);
            }
        });
    }

    public function registerTenant(): void
    {
        if (auth()->user()->currentBranch()) {
            Tenant::firstOrCreate([
                'tenantable_type' => strtolower(class_basename($this)),
                'tenantable_id' => $this->id,
                'branch_id' => auth()->user()->currentBranch()?->id,
            ]);
        }
    }

    public function unregisterTenant(): void
    {
        if (auth()->user()->currentBranch()) {
            Tenant::where([
                'tenantable_type' => strtolower(class_basename($this)),
                'tenantable_id' => $this->id,
                'branch_id' => auth()->user()->currentBranch()?->id,
            ])->delete();
        }
    }

    public function checkregister($model): bool
    {
        if (auth()->user()->currentBranch()) {
            return Tenant::where([
                'tenantable_type' => strtolower(class_basename($this)),
                'tenantable_id' => $this->id,
                'branch_id' => auth()->user()->currentBranch()?->id,
            ])->exists();
        }
        return false;
    }

    public function tendent()
    {
        return $this->morphOne(Tenant::class, 'tenantable');
    }


}
