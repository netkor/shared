<?php

namespace App\Models\Traits;

use App\Models\Scopes\UserBranch;
use App\Models\Tenant;
use Illuminate\Database\Eloquent\Relations\MorphOne;


trait HasTenant
{

    public static function bootHasTenant()
    {
        static::addGlobalScope(new UserBranch);

        static::created(function ($model) {
            (new self)->setTenant($model);
        });
    }

    public function setTenant($model): void
    {
        if (auth()->user()->currentBranch()) {
            $model->tenant()->firstOrCreate([
                'branch_id' => $this->getBranchId(),
            ]);
        }
    }

    public function tenant(): MorphOne
    {
        return $this->morphOne(Tenant::class, 'tenantable');
    }

    public function getBranchId()
    {
        return auth()->user()->currentBranch()?->id;
    }

    public function unregisterTenant(): void
    {
        if (auth()->user()->currentBranch()) {
            Tenant::where([
                'tenantable_type' => strtolower(class_basename($this)),
                'tenantable_id' => $this->id,
                'branch_id' => auth()->user()->currentBranch()?->id,
            ])->delete();
        }
    }

    public function checkregister($model): bool
    {
        if (auth()->user()->currentBranch()) {
            return Tenant::where([
                'tenantable_type' => strtolower(class_basename($this)),
                'tenantable_id' => $this->id,
                'branch_id' => auth()->user()->currentBranch()?->id,
            ])->exists();
        }
        return false;
    }


    public function assignTenant($branchId): void
    {
        $this->tenant()->firstOrCreate([
            'branch_id' => $branchId,
        ]);
    }


}
