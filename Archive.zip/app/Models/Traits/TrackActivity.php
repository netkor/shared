<?php

namespace App\Models\Traits;

use App\Models\Activity;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use ReflectionClass;

trait TrackActivity
{
    protected static function bootTrackActivity()
    {
        if (auth()->guest()) return;

        foreach (static::getActivitiesToRecord() as $event) {
            static::$event(function ($model) use ($event) {
                $model->recordActivity($event);
            });
        }

        // static::deleting(function ($model) {
        //     $model->activity()->delete();
        // });
    }

    protected static function getActivitiesToRecord()
    {
        return [
            'created',
            'updated',
            'deleted',
        ];
    }

    protected function recordActivity($event)
    {
        $this->activity()->create([
            'causer_type' => get_class(auth()->user()),
            'causer_id' => auth()->id(),
            'subject_type' => $this->getActivityType($event),
            'subject_id' => $this->id,
            'log_name' => $this->getActivityLogName($event),
            'description' => $this->getActivityDescription($event),
            'properties' => $this->getActivityProperties($event),
        ]);
    }

    public function activity(): MorphMany
    {
        return $this->morphMany(Activity::class, 'subject')->orderBy('created_at', 'desc');
    }

    protected function getActivityType($event): string
    {
        $type = strtolower((new ReflectionClass($this))->getShortName());

        return "{$event}_{$type}";
    }

    protected function getActivityLogName($event)
    {
        return 'default';
    }

    protected function getActivityDescription($event): string
    {
        return "{$event}_" . strtolower((new ReflectionClass($this))->getShortName());
    }

    protected function getActivityProperties($event)
    {


        return json_encode($this->toArray());

    }
}
