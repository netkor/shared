<?php

namespace App\Models\Traits;

use App\Models\Taggable;

trait HasTags
{
    public function tags()
    {
        return $this->morphMany(Taggable::class, 'taggable');
    }

}

