<?php

namespace App\Models\Traits;

trait HasAccount
{
    public function getBalanceAttribute()
    {
        return $this->transactions()->latest()->first()->balance ?? 0;
    }

}
