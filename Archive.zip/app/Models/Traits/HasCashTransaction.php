<?php

namespace App\Models\Traits;

use App\Models\Transaction;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Database\Eloquent\Relations\MorphOne;

/**
 * @method morphOne(string $class, string $string)
 * @method morphMany(string $class, string $string)
 */
trait HasCashTransaction
{
    /**
     * Get all the transactions for the model.
     */
    public function transactions(): MorphMany
    {
        return $this->morphMany(Transaction::class, 'transactionable');
    }

    /**
     * Get the latest transaction for the model.
     */
    public function transaction(): MorphOne
    {
        return $this->morphOne(Transaction::class, 'transactionable')->latestOfMany();
    }

    /**
     * Get the latest balance for the model.
     */
    public function balance(): float
    {
        return (float)$this->transaction?->balance ?? 0;
    }

}
