<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

class Category extends Model
{
    use HasUuids;
    use SoftDeletes;
    use LogsActivity;

//    use HasTendent;

    protected $fillable = [
        'name',
        'parent_id',
    ];

    protected static function boot()
    {
        parent::boot();

        static::creating(function ($model) {
            $model->slug = Str::slug($model->name);
        });

        static::updating(function ($model) {
            $model->slug = Str::slug($model->name);
        });

    }


    public function getDescriptionForEvent(string $eventName): string
    {
        $changes = $this->getChanges();
        $changes = array_keys($changes);
        $changes = implode(', ', $changes);
        return "Category {$eventName} {$changes}";
    }

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->logOnly(['name'])
            ->logOnlyDirty()
            ->logExcept(['created_at', 'updated_at'])
            ->useLogName('Category');
    }

}
