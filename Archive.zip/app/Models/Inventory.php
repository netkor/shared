<?php

namespace App\Models;

use App\Models\Traits\HasTenant;
use App\Models\Traits\TrackActivity;
use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class Inventory extends Model
{
    use HasFactory;
    use HasTenant;
    use TrackActivity;
    use HasUuids;
    use SoftDeletes;


    protected $guarded = [];

    protected $casts = [
        'status' => 'boolean',
    ];

    public function stocks()
    {
        return $this->hasMany(Stock::class);
    }

    public function vendor(): BelongsTo
    {
        return $this->belongsTo(Vendor::class);
    }

    public function expireWarningProduct($days = 3)
    {
        return $this->products()
            ->wherePivot('expiry_date', '<=', now()->addDays($days))
            ->wherePivot('expiry_date', '>', now());
    }

    public function expiredProduct()
    {
        return $this->products()
            ->wherePivot('expiry_date', '<', now());
    }

    public function lowOnStock($qty = 10)
    {
        return $this->products()
            ->wherePivot('stock', '<=', $qty);
    }

    public function isApproved(): bool
    {
        // verified_at is a timestamp
        return $this->approved_at !== null;
    }

}
