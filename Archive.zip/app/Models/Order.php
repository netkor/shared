<?php

declare(strict_types=1);

namespace App\Models;

use App\Contracts\CashTransactionContract;
use App\Models\Traits\HasCashTransaction;
use App\Models\Traits\HasTenant;
use App\Models\Traits\TrackActivity;
use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Order extends Model implements CashTransactionContract
{
    use HasTenant;
    use TrackActivity;
    use HasUuids;
    use HasCashTransaction;

    protected $fillable = [
        'ref_no',
        'customer_id',
        'table_id',
    ];

    public static function generateRefNo(): string
    {
        $refNo = 'ORD-' . date('Ymd') . '-' . str_pad((string)rand(1, 99999), 5, '0', STR_PAD_LEFT);
        if (self::query()->where('ref_no', $refNo)->exists()) {
            return self::generateRefNo();
        }
        return $refNo;
    }


    public function order_items(): HasMany
    {
        return $this->hasMany(OrderItem::class);

    }


    public function customer(): BelongsTo
    {
        return $this->belongsTo(Customer::class);
    }

    public function menus(): BelongsToMany
    {
        return $this->belongsToMany(Menu::class, 'order_items');
    }

    public function menu(): BelongsTo
    {
        return $this->belongsTo(Menu::class);
    }

    public function table(): BelongsTo
    {
        return $this->belongsTo(Table::class);
    }

    public function waiter(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function formattedTotal(): string
    {
        return number_format($this->total(), 2);
    }

    public function total()
    {
        return $this->order_items->sum(function ($item) {
            return $item->menu?->price * $item?->quantity;
        });

    }

    public function formattedDiscountAmount(): string
    {
        return number_format((float)$this->payments()->sum('discount_amount'), 2);
    }

    public function payments(): HasMany
    {
        return $this->hasMany(Payment::class);
    }


    public function formattedChangeAmount(): string
    {
        return number_format((float)($this->receivedAmount() - $this->total() + $this->payment()->discount_amount), 2);
    }

    public function receivedAmount()
    {
        return $this->payments->map(function ($i) {
            return $i->received_amount;
        })->sum();
    }

    public function payment(): Model
    {
        return $this->payments()->latest()->first();
    }

    public function refundAmount()
    {
        return $this->receivedAmount() - $this->total() + $this->payment()->discount_amount;
    }

    public function formattedDiscountdAmount(): string
    {
        return number_format($this->discountAmount(), 2);
    }

    public function discountAmount()
    {
        return $this->payments->map(function ($i) {
            return $i->discount_amount;
        })->sum();
    }

    public function formattedReceivedAmount(): string
    {
        return number_format($this->receivedAmount(), 2);
    }

    public function url(): string
    {
        return route('orders.show', $this);
    }

    public function label(): string
    {
        return $this->ref_no;
    }


}
