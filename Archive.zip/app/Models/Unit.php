<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;

/**
 * @property mixed $conversion_factor
 */
class Unit extends Model
{
    use HasUuids;


    protected $guarded = [];

    public static function tree($physical_quantity = null)
    {
        $allUnits = Unit::query()
            ->when($physical_quantity, function ($query) use ($physical_quantity) {
                $query->where('physical_quantity', $physical_quantity);
            })
            ->get();

        $rootUnits = $allUnits->whereNull('parent_id');

        self::formatTree($rootUnits, $allUnits);

        return $rootUnits;
    }

    private static function formatTree($units, $allUnits)
    {
        foreach ($units as $unit) {
            $unit->children = $allUnits->where('parent_id', $unit->id)->values();
            if ($unit->children->isNotEmpty()) {
                self::formatTree($unit->children, $allUnits);
            }
        }
    }

    public function parent()
    {
        return $this->belongsTo(Unit::class, 'parent_id');
    }

    public function children()
    {
        return $this->hasMany(Unit::class, 'parent_id');
    }

    public function product()
    {
        return $this->belongsTo(Product::class);
    }

}

