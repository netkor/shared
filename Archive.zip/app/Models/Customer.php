<?php

namespace App\Models;

use App\Models\Traits\TrackActivity;
use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;


class Customer extends Model
{
    use LogsActivity;
    use HasUuids;


    protected $fillable = [
        'name',
        'phone',
        'points'

    ];



    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->logOnly(['name',  'phone','points'])
            ->useLogName('Customer');
    }
}
