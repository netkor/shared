<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;

class Activity extends \Spatie\Activitylog\Models\Activity
{
    use HasUuids;
}
