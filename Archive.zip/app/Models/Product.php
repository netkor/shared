<?php

namespace App\Models;

use App\Contracts\ItemTransactionContract;
use App\Models\Traits\HasItemTransaction;
use App\Models\Traits\HasTendent;
use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use Spatie\Activitylog\ActivitylogServiceProvider;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;
use Spatie\Image\Manipulations;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class Product extends Model implements ItemTransactionContract, HasMedia
{
    use InteractsWithMedia;
    use HasTendent;
    use LogsActivity;
    use HasUuids;
    use SoftDeletes;
    use HasItemTransaction;

    protected $guarded = [];

    protected array $logAttributes = [
        'name',
        'description',
        'remaining_stock',
        'keeping_unit_id',
        'image',
        'status',
    ];

    public function registerMediaConversions(Media $media = null): void
    {
        $this
            ->addMediaConversion('preview')
            ->fit(Manipulations::FIT_CROP, 300, 300)
            ->nonQueued();
    }
    public function getImageAttribute(): string
    {
        return $this->getFirstMediaUrl('products', 'preview');
    }

    public function variants(): HasMany
    {
        return $this->hasMany(Variant::class);
    }

    public function orders(): BelongsToMany
    {
        return $this->belongsToMany(Order::class);
    }

    public function units(): BelongsToMany
    {
        return $this->belongsToMany(Unit::class, 'product_units')->withPivot('value');
    }

    public function keepingUnit(): BelongsTo
    {
        return $this->belongsTo(Unit::class, 'keeping_unit_id');
    }

    public function unit(): BelongsTo
    {
        return $this->belongsTo(Unit::class);
    }

    public function scopeSellable($query, $quantity = 1)
    {
        return $query->where('remaining_stock', '>', $quantity);

    }


    public function format()
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'description' => $this->description,
            'category' => $this->categories->first()?->name,
            'type' => $this->types->first()?->name,
            'price' => $this->stores->first()?->price,
            'barcode' => $this->barcode,
        ];
    }

    // public function getImageAttribute($value)
    // {
    //     if ($value) {
    //         return asset('storage/' . $value);
    //     }
    // }

    public function activities(): MorphMany
    {
        return $this->morphMany(ActivitylogServiceProvider::determineActivityModel(), 'subject')->orderBy('created_at', 'desc');
    }

    public function stores()
    {
        return $this->hasMany(Store::class);
    }

    public function lowOnStock()
    {
        return $this->inventories()->wherePivot('stock', '<=', $this->alert_quantity);
    }

    public function inventories()
    {
        return $this->belongsToMany(Inventory::class, 'inventory_product')
            ->withPivot(['quantity', 'cost_price', 'stock', 'unit_id', 'expiry_date', 'vat', 'discount']);
    }

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->logOnly($this->logAttributes)
            ->logExcept(['created_at', 'updated_at'])
            ->logOnlyDirty()
            ->dontSubmitEmptyLogs()
            ->useLogName('Product');
    }

    public function url(): string
    {
        return route('products.show', $this->id);
    }

    public function label(): string
    {
        return $this->name;
    }

    public function stock(): float
    {
        return (float)$this->itemTransaction?->stock ?? 0;

    }

}
