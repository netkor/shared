<?php

namespace App\Models;

use App\Models\Traits\HasTenant;
use App\Models\Traits\TrackActivity;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Image\Manipulations;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class Menu extends Model implements HasMedia
{
    use InteractsWithMedia;
    use HasFactory;
    use HasUuids;
    use TrackActivity;
    use HasTenant;

    protected $fillable = [
        'name',
        'price',
        'image',
        'type_id',
        'category_id'
    ];


    protected $casts = [
        'id' => 'string',
        'price' => 'float',

    ];

    protected $appends = ['image'];

    public function registerMediaConversions(Media $media = null): void
    {
        $this
            ->addMediaConversion('preview')
            ->fit(Manipulations::FIT_CROP, 300, 300)
            ->nonQueued();
    }

    public function getImageAttribute(): string
    {
        return $this->getFirstMediaUrl('menus', 'preview');
    }


    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    public function scopeCountInactiveMenus()
    {
        return $this->sellable()->count();
    }

    public function scopeSellable(Builder $query): Builder
    {
        $query = $query->whereHas('ingredients', function (Builder $query) {
            $query->sellable();
        });

        return $query;


//        return $this->whereHas('ingredients');


//        return $query->has('ingredients', function ($query) {
//            $query->sellable();
//        });
    }

    public function type()
    {
        return $this->belongsTo(Type::class);
    }

//    public function getImageAttribute($value)
//    {
//        if ($value) {
//            return asset('storage/' . $value);
//        }
//    }

    public function ingredients()
    {
        return $this->hasMany(Ingredient::class);
    }

}
