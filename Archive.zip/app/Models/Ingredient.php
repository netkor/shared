<?php

namespace App\Models;

use App\Models\Traits\HasTenant;
use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * @property mixed $quantity
 */
class Ingredient extends Model
{
    use HasUuids;
    use HasTenant;
    use LogsActivity;

    public $table = 'ingredients';

    protected $fillable = [
        'menu_id',
        'product_id',
        'quantity',
        'unit_id',
        'notes'
    ];

    public function unit()
    {
        return $this->belongsTo(Unit::class);
    }

    public function product()
    {
        return $this->belongsTo(Product::class);
    }

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->logOnly(['name', 'menu_id', 'unit_id', 'quantity', 'status', 'notes'])
            ->useLogName('Ingredient');
    }

    public function scopeSellable($query, $quantity = 1)
    {
        return $query->whereHas('product', function ($query) use ($quantity) {
            $query->sellable($quantity);
        });

    }
}
