<?php

namespace App\Models;

use App\Enums\TableStatus;
use App\Models\Traits\HasTenant;
use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

/**
 * @property TableStatus $status
 */
class Table extends Model
{
    use HasTenant;
    use LogsActivity;
    use HasUuids;
    use SoftDeletes;


    public bool $logOnlyDirty = true;

    protected $fillable = [
        'name',
        'description',
        'status',

    ];

    public function getDescriptionForEvent(string $eventName): string
    {
        // list the changed attributes
        $changes = $this->getChanges();
        $changes = array_keys($changes);
        $changes = implode(', ', $changes);
        return "Table {$eventName} {$changes}";
    }

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->logOnly(['name', 'description', 'status'])
            ->logOnlyDirty()
            ->logExcept(['created_at', 'updated_at'])
            ->useLogName('Table');
    }
}
