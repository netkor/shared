<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Concerns\HasUuids;

class Item extends Product
{


    protected $table = 'products';
    protected $primaryKey = 'id';
    protected $keyType = 'string';



    public static function boot()
    {
        static::addGlobalScope('sellable', function ($builder) {

                $builder->whereHas('types', function ($query) {
                    $query->whereIn('name', ['Recipe', 'Product','Service']);
                });
        });

    }

}
