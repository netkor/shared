<?php

namespace App\Transformers;

use App\Models\User;
use League\Fractal\TransformerAbstract;

class UserTransformer extends TransformerAbstract
{
    /**
     * @param User $user
     * @return array
     */
    public function transform(User $user): array
    {
        return [
            'id' => (int)$user->id,
            "first_name" => (string)$user->first_name,
            "last_name" => (string)$user->last_name,
            "email" => (string)$user->email,
            "phone" => (string)$user->phone,
            "address" => (string)$user->address,
            "api_token" => $user->api_token,
            "status" => (bool)$user->status,
            "roles" => (string)$user->roles->first()?->name,
        ];

    }
}
