

@extends('layouts.admin')

@section('title', ' Sales Reports')
@section('content-header', 'Sales Reports')
@section('content-actions')
    {{-- <a href="#" class="btn btn-primary">Add Menu</a> --}}
@endsection
@section('css')
    <link rel="stylesheet" href="{{ asset('plugins/sweetalert2/sweetalert2.min.css') }}">
@endsection
@section('content')

    <div class="content">
        <div class="clearfix"></div>
        <div class="card">
            <div class="card-header">
                <ul class="nav nav-tabs align-items-end card-header-tabs w-100">
                    <li class="nav-item">
                        <a class="nav-link active" href="{!! url()->current() !!}"><i
                                class="fa fa-list mr-2"></i>Sales Report </a>
                    </li>



                    @include('layouts.right_toolbar', compact('dataTable'))
                </ul>
            </div>
            <div class="card-body">
                @include('dailysalesreport.table')
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
@endsection
