@extends('layouts.admin')

@section('title', 'Table List')
@section('content-header', 'Table List')
@section('content-actions')
    <a href="{{route('tables.create')}}" class="btn btn-primary">Add Table</a>
@endsection
@section('css')
    <link rel="stylesheet" href="{{ asset('plugins/sweetalert2/sweetalert2.min.css') }}">
@endsection
@section('content')
    <div class="card">
        <div class="card-body">
            <table class="table table-striped table-valign-middle">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Status</th>
                    <th>Created At</th>
                    @if(auth()->user()->hasRole('super-admin'))
                        <th>Branch</th>
                    @endif
                    <th>Actions</th>
                </tr>
                </thead>
                <tbody>
                @foreach ($tables as $table)
                    <tr>
                        <td>{{$table->id}}</td>

                        <td>{{$table->name}}</td>
                        <td>{{$table->description}}</td>
                        <td>{{$table->status}}</td>
                        <td>{{$table->created_at}}</td>
                        @if(auth()->user()->hasRole('super-admin'))
                            <td> {{ $table->tendent?->branch->name }} </td>
                        @endif
                        <td>
                            <a href="{{ route('tables.edit', $table) }}" class="btn btn-primary"><i
                                    class="fas fa-edit"></i></a>
                            <button class="btn btn-danger btn-delete" data-url="{{route('tables.destroy', $table)}}"><i
                                    class="fas fa-trash"></i></button>
                            <a href="{{ route('subject-activity-logs', [class_basename($table), $table->id]) }}">View
                                Log</a>
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
            {{ $tables->render() }}
        </div>
    </div>
@endsection

@section('js')
    <script src="{{ asset('plugins/sweetalert2/sweetalert2.min.js') }}"></script>
    <script>
        $(document).ready(function () {
            $(document).on('click', '.btn-delete', function () {
                $this = $(this);
                const swalWithBootstrapButtons = Swal.mixin({
                    customClass: {
                        confirmButton: 'btn btn-success',
                        cancelButton: 'btn btn-danger'
                    },
                    buttonsStyling: false
                })

                swalWithBootstrapButtons.fire({
                    title: 'Are you sure?',
                    text: "Do you really want to delete this table?",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, delete it!',
                    cancelButtonText: 'No',
                    reverseButtons: true
                }).then((result) => {
                    if (result.value) {
                        $.post($this.data('url'), {_method: 'DELETE', _token: '{{csrf_token()}}'}, function (res) {
                            $this.closest('tr').fadeOut(500, function () {
                                $(this).remove();
                            })
                        })
                    }
                })
            })
        })
    </script>
@endsection
