@extends('layouts.admin')

@section('title', 'Recipe Ingredients')

@section('content')
    <div id="recipeIngredients" data-units="{{ $units }}" data-ingredients="{{ $ingredients }}" data-recipe="{{ $recipe }}"></div>
@endsection
