@extends('layouts.admin')

@section('title', ' Card Info')
@section('content-header', ' Card Info')

@section('content')

<div class="card">
    <div class="card-body">

        <div class="row">
            <div class="col-md-4">
                <div class="product-img">
                   <div class="visible-print text-center">
                                    {!! QrCode::size(300)->style('round')->generate("MECARD:N:$card->address$card->name;ADR:$card->name;TEL:;EMAIL:;;") !!}
                                    {{-- {!! QrCode::size(300)->style('round')->generate($card->name) !!} --}}
                                </div>
                </div>
            </div>
            <div class="col-md-8">
                <div class="product-details">
                    <h3 class="product-name">Card Name: {{ $card->name }}</h3>
                    <p class="product-description">Card Address: {{ $card->address }}</p>
                    <p class="product-description">Card Balance: {{ $card->balance() }}</p>
                    <p class="product-created-at">Created At: {{ $card->created_at->format('Y-M-j h:i a') }}</p>
                </div>
            </div>


        </div>


    </div>
</div>
@endsection
