@extends('layouts.admin')

@section('title', 'Update Settings')
@section('content-header', 'Update Settings')

@section('content')
    <div class="card">
        <div class="card-body">
            <form action="{{ route('settings.store') }}" method="post">
                @csrf

                <div class="form-group">
                    <label for="app_name">Company Name </label>
                    <input type="text" name="app_name" class="form-control @error('app_name') is-invalid @enderror"
                        id="app_name" placeholder="App name" value="{{ old('app_name', config('settings.app_name')) }}">
                    @error('app_name')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>

                <div class="form-group">
                    <label for="app_description">Company Description</label>
                    <textarea name="app_description" class="form-control @error('app_description') is-invalid @enderror"
                        id="app_description" placeholder="App description">{{ old('app_description', config('settings.app_description')) }}</textarea>
                    @error('app_description')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>

                <div class="row">
                    <div class="col-md-3">

                        <div class="form-group">
                            <label for="app_logo">Company Logo</label>
                            <input type="file" name="app_logo"
                                class="form-control @error('app_logo') is-invalid @enderror" id="app_logo"
                                placeholder="App logo" value="{{ old('app_logo', config('settings.app_logo')) }}">
                            @error('app_logo')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror

                        </div>
                    </div>
                    <div class="col-md-3">


                        <div class="form-group">
                            <label for="currency_symbol">Currency symbol</label>
                            <input type="text" name="currency_symbol"
                                class="form-control @error('currency_symbol') is-invalid @enderror" id="currency_symbol"
                                placeholder="Currency symbol"
                                value="{{ old('currency_symbol', config('settings.currency_symbol')) }}">
                            @error('currency_symbol')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>
                    <div class="col-md-3">

                        <div class="form-group">
                            <label for="points">Pauna Point conversion percent</label>
                            <input type="number" name="points" class="form-control @error('points') is-invalid @enderror"
                                id="points" placeholder="Point Ratio"
                                value="{{ old('points', config('settings.points')) }}">
                            @error('points')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>
                    <div class="col-md-3">

                        <div class="form-group">
                            <label for="payment_method">Payment Method</label>
                            <select name="payment_method" id="payment_method"
                                class="form-control @error('payment_method') is-invalid @enderror">
                                <option value="Cash"
                                    {{ old('payment_method', config('settings.payment_method')) == 'Cash' ? 'selected' : '' }}>
                                    Cash
                                </option>
                                <option value="Card"
                                    {{ old('payment_method', config('settings.payment_method')) == 'Card' ? 'selected' : '' }}>
                                    Card
                                </option>
                            </select>
                            @error('payment_method')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary">Change Setting</button>
            </form>
        </div>
    </div>
@endsection
