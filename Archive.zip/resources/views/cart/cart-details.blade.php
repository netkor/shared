@extends('layouts.admin')

@section('title', 'Order Details')
@section('content-header', 'Order Details')

@section('content')
    <div class="p-4 min-vh-100">
        <div id="cart-details" data-carts="{{ $carts }}">
        </div>
    </div>
@endsection

