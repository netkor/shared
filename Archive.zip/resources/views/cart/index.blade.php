@extends('layouts.admin')

@section('title', 'Open POS')

@section('content')

    <div id="cart" data-payment_method="{{ $payment_method }}" data-role="{{ $role }}"></div>
{{--    <livewire:p-o-s-dash />--}}
@endsection
