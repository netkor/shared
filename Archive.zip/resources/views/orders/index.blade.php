@extends('layouts.admin')

@section('title', 'Orders List')
@section('content-header', 'Order List')
@section('content-actions')
    <a href="{{ route('cart.index') }}" class="btn btn-primary">Open POS</a>
@endsection

@section('content')
    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-md-12">
                    <form action="{{ route('orders.index') }}">

                        <div class="row">
                            <div class="col-md-2">
                                <label for="from">Search By Order No</label>

                                <input type="text" placeholder="Order#" name="ref_no" class="form-control"
                                       value="{{ request()->ref_no }}">
                            </div>
                            <div class="col-md-2">
                                <label for="from">Search By Customer</label>

                                <input type="text" placeholder="Customer Name" name="name" class="form-control"
                                       value="{{ request()->name }}">
                            </div>

                            <div class="col-md-2">
                                <label for="from">From</label>
                                <input type="date" name="start_date" class="form-control"
                                       value="{{ request('start_date') }}"/>
                            </div>
                            <div class="col-md-2">
                                <label for="from">To</label>
                                <input type="date" name="end_date" class="form-control"
                                       value="{{ request('end_date') }}"/>
                            </div>

                            <div class="col-md-1">
                                <label for="from">Filter Search</label>
                                <button class="btn btn-outline-primary" type="submit">Search</button>
                            </div>
                            <div class="col-md-1">
                                <label for="from">Reset Search</label>

                                <a href="{{ route('dailysalesreport.index') }}" class="btn btn-outline-danger">Reset</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <table class="table">
                <thead>
                <tr>
                    <th>Order No</th>
                    <th>Customer Name</th>
                    <th>Table</th>
                    <th>Total</th>
                    <th>Received</th>
                    <th>Discount</th>
                    <th>Status</th>
                    <th>To Pay</th>
                    <th>Created At</th>
                    <th>Actions</th>
                </tr>
                </thead>
                <tbody>
                @foreach ($orders as $order)
                    <tr>
                        <td>{{ $order->ref_no }}</td>
                        <td>{{ $order->customer?->name ?? '-' }}</td>
                        <td>{{ $order->table?->name ?? '-' }}</td>
                        <td>{{ config('settings.currency_symbol') }} {{ $order->formattedTotal() }}</td>
                        <td>{{ config('settings.currency_symbol') }} {{ $order->formattedReceivedAmount() }}</td>
                        <td>{{ config('settings.currency_symbol') }} {{ $order->formattedDiscountdAmount() }}</td>
                        <td>
                            @if ($order->receivedAmount() + $order->discountAmount() == 0)
                                <span class="badge badge-danger">Not Paid</span>
                            @elseif($order->receivedAmount() + $order->discountAmount() < $order->total())
                                <span class="badge badge-warning">Partial</span>
                            @elseif($order->receivedAmount() + $order->discountAmount() == $order->total())
                                <span class="badge badge-success">Paid</span>
                            @elseif($order->receivedAmount() + $order->discountAmount() > $order->total())
                                <span class="badge badge-info">Change</span>
                            @endif
                        </td>
                        <td>{{ config('settings.currency_symbol') }}
                            {{-- {{ number_format($order->total() - $order->receivedAmount(), 2) }}</td> --}}
                            {{ number_format($order->refundAmount(), 2) }}</td>
                        <td>{{ $order->created_at->format('d/M/Y h:m A') }}</td>
                        <td>
                            @if (number_format($order->refundAmount(), 2) < 0)
                                <button data-toggle="modal" data-target="#sattlePaymentModal{{ $order->id }}"
                                        class="btn btn-sm btn-success">Sattle
                                </button>
                            @endif


                            <button data-toggle="modal" data-target="#viewOrderModal{{ $order->id }}"
                                    class="btn btn-sm btn-primary">View
                            </button>
                        </td>
                    </tr>
                    <!-- Modal -->
                    <div class="modal fade" id="viewOrderModal{{ $order->id }}" tabindex="-1" role="dialog"
                         aria-labelledby="viewOrderModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="viewOrderModalLabel">
                                        {{ $order->ref_no }}
                                    </h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>

                                <div class="modal-body">
                                    <b>Table</b>:
                                    {{ $order->table?->name ?? '-' }}<br>

                                    <b>Customer Name</b>:
                                    {{ $order->customer?->name ?? '-' }}<br>
                                    <b>Invoice Time</b>: {{ $order->created_at->format('d/M/Y h:m A') }}<br>
                                    <h5>Items</h5>
                                    <hr>

                                    @foreach ($order->order_items as $item)
                                        <div class="row">
                                            <div class="col-md-6">
                                                {{ $item->menu->name ?? '-' }}
                                            </div>
                                            <div class="col-md-6">
                                                {{ $item->quantity }} x {{ config('settings.currency_symbol') }}
                                                {{ $item?->menu?->price??0 }}=
                                                {{ config('settings.currency_symbol') }}
                                                {{ $item?->quantity * $item?->menu?->price??0 }}
                                            </div>
                                        </div>
                                    @endforeach

                                    <hr>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <b>Total</b>
                                        </div>
                                        <div class="col-md-6">
                                            {{ config('settings.currency_symbol') }} {{ $order->formattedTotal() }}
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <b>Received Amount</b>
                                        </div>
                                        <div class="col-md-6">
                                            {{ config('settings.currency_symbol') }}
                                            {{ $order->formattedReceivedAmount() }}
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <b>Discount Amount</b>
                                        </div>
                                        <div class="col-md-6">
                                            {{ config('settings.currency_symbol') }}
                                            {{ $order->formattedDiscountAmount() }}
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <b>Tender Amount</b>
                                        </div>
                                        <div class="col-md-6">
                                            {{ config('settings.currency_symbol') }}
                                            {{ number_format($order->refundAmount(), 2) }}
                                            @if ($order->receivedAmount() + $order->discountAmount() == 0)
                                                <span class="badge badge-danger">Not Paid</span>
                                            @elseif($order->receivedAmount() + $order->discountAmount() < $order->total())
                                                <span class="badge badge-warning">Partial</span>
                                            @elseif($order->receivedAmount() + $order->discountAmount() == $order->total())
                                                <span class="badge badge-success">Paid</span>
                                            @elseif($order->receivedAmount() + $order->discountAmount() > $order->total())
                                                <span class="badge badge-info">Change</span>
                                            @endif
                                        </div>
                                    </div>
                                    <hr>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <b>On service Waiter</b>
                                        </div>
                                        <div class="col-md-6">


                                            {{ $waiter }}
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close
                                        </button>
                                        <a type="button" href="{{ route('orders.print-receipt', $order) }}"
                                           class="btn btn-primary">Print Receipt</a>

                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                    {{-- @endforeach --}}



                    <div class="modal fade" id="sattlePaymentModal{{ $order->id }}" tabindex="-1"
                         role="dialog" aria-labelledby="sattlePaymentModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="sattlePaymentModalLabel">
                                        {{ $order->ref_no }}
                                    </h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>

                                <div class="modal-body">
                                    <b>Table</b>:
                                    {{ $order->table?->name ?? '-' }}<br>

                                    <b>Customer Name</b>:
                                    {{ $order->customer?->name ?? '-' }}<br>
                                    <b>Invoice Time</b>: {{ $order->created_at->format('d/M/Y h:m A') }}<br>
                                    <h5>Items</h5>
                                    <hr>

                                    @foreach ($order->order_items as $item)
                                        <div class="row">
                                            <div class="col-md-6">
                                                {{ $item->menu->name ?? '-' }}
                                            </div>
                                            <div class="col-md-6">
                                                {{ $item->quantity }} x {{ config('settings.currency_symbol') }}
                                                {{ $item->menu?->price??0 }}=
                                                {{ config('settings.currency_symbol') }}
                                                {{ $item->quantity * $item?->menu?->price }}
                                            </div>
                                        </div>
                                    @endforeach

                                    <hr>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <b>Total</b>
                                        </div>
                                        <div class="col-md-6">
                                            {{ config('settings.currency_symbol') }} {{ $order->formattedTotal() }}
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <b>Received Amount</b>
                                        </div>
                                        <div class="col-md-6">
                                            {{ config('settings.currency_symbol') }}
                                            {{ $order->formattedReceivedAmount() }}
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <b>Discount Amount</b>
                                        </div>
                                        <div class="col-md-6">
                                            {{ config('settings.currency_symbol') }}
                                            {{ $order->formattedDiscountAmount() }}
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <b>Due Amount</b>
                                        </div>
                                        <div class="col-md-6">
                                            {{ config('settings.currency_symbol') }}
                                            {{ number_format($order->refundAmount(), 2) }}
                                            @if ($order->receivedAmount() + $order->discountAmount() == 0)
                                                <span class="badge badge-danger">Not Paid</span>
                                            @elseif($order->receivedAmount() + $order->discountAmount() < $order->total())
                                                <span class="badge badge-warning">Partial</span>
                                            @elseif($order->receivedAmount() + $order->discountAmount() == $order->total())
                                                <span class="badge badge-success">Paid</span>
                                            @elseif($order->receivedAmount() + $order->discountAmount() > $order->total())
                                                <span class="badge badge-info">Change</span>
                                            @endif
                                        </div>
                                    </div>
                                    <hr>
                                    <form action="{{ route('sattle-amount', $order->id) }}" method="POST">
                                        @csrf
                                        @method('POST')
                                        <input type="hidden" name="order_id" value="{{ $order->id }}">
                                        <div
                                            class="form-group
                                    {{ $errors->has('amount') ? 'has-error' : '' }}">
                                            <label for="amount">Amount</label>
                                            {{--                                                //if amount is greater than due amount then ask to pay the due amount only--}}

                                            <input type="number" name="amount" id="amount" class="form-control"

                                                   min="0" max="{{-$order->refundAmount()}}"
                                                   value="{{ -$order->refundAmount()}}">

                                            {!! $errors->first('amount', '<span class="help-block">:message</span>') !!}
                                        </div>


                                        <button type="submit" class="btn btn-primary">Pay Due</button>
                                    </form>

                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                @endforeach


                </tbody>
                <tfoot>
                <tr>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th>{{ config('settings.currency_symbol') }} {{ number_format($total, 2) }}</th>
                    <th>{{ config('settings.currency_symbol') }} {{ number_format($receivedAmount, 2) }}</th>
                    <th>{{ config('settings.currency_symbol') }} {{ number_format($discountAmount, 2) }}</th>
                    <th></th>

                    <th></th>
                    <th>{{ config('settings.currency_symbol') }} {{ number_format($returnAmount, 2) }}</th>

                </tr>
                </tfoot>
            </table>
        </div>
    </div>

@endsection
