@extends('layouts.admin')

@section('title', 'Inventory List')
@section('content-header', 'Inventory List')
@section('content-actions')
    <a href="{{ route('inventory.create') }}" class="btn btn-primary">Create Inventory</a>
@endsection
@section('css')
    <link rel="stylesheet" href="{{ asset('plugins/sweetalert2/sweetalert2.min.css') }}">
@endsection
@section('content')
    <div class="card product-list">
        <div class="card-body">
            <div class="row">
                <div class="col-md-7">
                    <form action="{{ route('products.index') }}">

                        <div class="row">
                            <div class="col-md-5">
                                <label for="from">Search By Batch No</label>
                                <input type="text" placeholder="Enter Batch Name" name="search" class="form-control"
                                       value="{{ request()->name }} ">
                            </div>

                            <div class="col-md-2">
                                <label for="from">Filter</label>
                                <button class="btn btn-outline-primary" type="submit">Search</button>
                            </div>
                        </div>
                    </form>
                </div>

            </div>
            <table class="table">
                <thead>
                <tr>
                    <th>Batch</th>
                    <th>Product</th>
                    <th>Status</th>
                    <th>Created At</th>
                    <th>Updated At</th>
                    <th>Actions</th>
                </tr>
                </thead>
                <tbody>
                @foreach ($inventories as $inventory)
                    <tr>
                        <td>{{ $inventory->batch_no }}</td>
                        <td>
                            <table class="table table-striped table-valign-middle">
                                <thead>
                                <tr>
                                    <th>Product Name</th>
                                    <th>Quantity</th>
                                    <th>Variant</th>
                                    <th>Cost Price</th>
                                </thead>
                                <tbody>
                                @foreach ($inventory->stocks as $stock)
                                    <tr>
                                        <td>{{ $stock->product->name }}</td>
                                        <td>{{ $stock->quantity }}</td>
                                        <td>{{ $stock->variant->name }}</td>
                                        <td>{{ $stock->cost_price }}</td>
                                    </tr>
                                @endforeach
                            </table>
                        </td>
                        <td>
                            <span
                                class="right badge badge-{{ $inventory->status ? 'success' : 'danger' }}">{{ $inventory->status ? 'Active' : 'Inactive' }}</span>
                        </td>
                        <td>{{ $inventory->created_at->format('Y-M-j h:i a') }}</td>
                        <td>{{ $inventory->updated_at->format('Y-M-j h:i a') }}</td>
                        <td>

                             @can('inventory-edit')
                              <a href="{{ route('inventories.approve', $inventory) }}" class="btn btn-success"><i
                                    class="fas fa-check"></i></a>
                                        @endcan
                            <a href="{{ route('inventories.edit', $inventory) }}" class="btn btn-primary"><i
                                    class="fas fa-edit"></i></a>
                            <button class="btn btn-danger btn-delete"
                                    data-url="{{ route('inventories.destroy', $inventory) }}"><i
                                    class="fas fa-trash"></i></button>
                        </td>
                    </tr>

                    <!-- Modal -->
                    <div class="modal fade" id="acceptStockModal{{ $inventory->id }}" tabindex="-1" role="dialog"
                         aria-labelledby="viewOrderModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="viewOrderModalLabel">
                                        Accept or Reject Stocks
                                    </h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close
                                    </button>
                                    <button type="button" class="btn btn-success">Accept</button>
                                    <button type="button" class="btn btn-danger">Reject</button>
                                </div>
                            </div>
                        </div>
                    </div>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection




@section('js')
    <script src="{{ asset('plugins/sweetalert2/sweetalert2.min.js') }}"></script>
    <script>
        $(document).ready(function () {
            $(document).on('click', '.btn-delete', function () {
                $this = $(this);
                const swalWithBootstrapButtons = Swal.mixin({
                    customClass: {
                        confirmButton: 'btn btn-success',
                        cancelButton: 'btn btn-danger'
                    },
                    buttonsStyling: false
                })
                swalWithBootstrapButtons.fire({
                    title: 'Are you sure?',
                    text: "Do you really want to delete this product?",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, delete it!',
                    cancelButtonText: 'No',
                    reverseButtons: true
                }).then((result) => {
                    if (result.value) {
                        $.post($this.data('url'), {
                            _method: 'DELETE',
                            _token: '{{ csrf_token() }}'
                        }, function (res) {
                            $this.closest('tr').fadeOut(500, function () {
                                $(this).remove();
                            })
                        })
                    }
                })
            })
        })
    </script>
@endsection
