

@extends('layouts.admin')

@section('title', ' Transaction')
@section('content-header', 'Transaction List')
@section('content-actions')
    {{-- <a href="#" class="btn btn-primary">Add Menu</a> --}}
@endsection
@section('css')
    <link rel="stylesheet" href="{{ asset('plugins/sweetalert2/sweetalert2.min.css') }}">
@endsection
@section('content')

    <div class="content">
        <div class="clearfix"></div>
        <div class="card">
            <div class="card-header">
                <ul class="nav nav-tabs align-items-end card-header-tabs w-100">
                    <li class="nav-item">
                        <a class="nav-link active" href="{!! url()->current() !!}"><i
                                class="fa fa-list mr-2"></i>Transaction List</a>
                    </li>

                    {{-- @can('menus.create') --}}
                        <li class="nav-item">
                            <a class="nav-link" href="{!! route('transactions.create') !!}"><i
                                    class="fa fa-plus mr-2"></i>Create Transaction </a>
                        </li>
                    {{-- @endcan --}}

                    @include('layouts.right_toolbar', compact('dataTable'))
                </ul>
            </div>
            <div class="card-body">
                @include('transactions.table')
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
@endsection
