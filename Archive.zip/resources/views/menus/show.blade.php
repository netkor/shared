@extends('layouts.admin')

@section('title', 'Recipe Details')
@section('content-header', 'Recipe Details')

@section('css')
    <link rel="stylesheet" href="{{ asset('plugins/sweetalert2/sweetalert2.min.css') }}">
@endsection
@section('content')
    {{-- product details page --}}
    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-md-2">
                    <div class="product-img">
                        <img src="{{ asset('storage/'.$menu->image) }}" alt="Product Image" class="img-fluid"
                             height="250px" width="250px">
                    </div>

                </div>
                <div class="col-md-3">
                    <div class="product-details">
                        <h3 class="product-name">{{ $menu->name }}</h3>
                        <p class="product-description">{{ $menu->description }}</p>
                        <p class="product-barcode">Barcode: {{ $menu->barcode }}</p>
                        <p class="product-price">Price: Rs. {{ $menu->price }}</p>
                        <p class="product-category">Category: {{ $menu->category?->name }}</p>
                        <p class="product-type">Type: {{ $menu->type?->name }}</p>
                        <p class="product-status">Status: {{ $menu->status?'Active':'Inactive' }}</p>
                        <p class="product-created-at">Created At: {{ $menu->created_at->format('Y-M-j h:i a') }}</p>
                        <p class="product-updated-at">Updated At: {{ $menu->updated_at->format('Y-M-j h:i a') }}</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="product-details">
                        <h3 class="product-name">Ingredients</h3>
                        <ul class="list-group">
                            @foreach($menu->ingredients as $ingredient)

                                <li class="list-group
                                -item">{{ $ingredient->product->name }} ({{ $ingredient->quantity }} {{ $ingredient->unit->name }})</li>
                            @endforeach




                        </ul>
                    </div>
                </div>
                {{-- <div class="col-md-3">
                    <div class="product-details">
                        <h3 class="product-name">Ingredients</h3>
                        <ul class="list-group">
                            @foreach ($menu->ingredients as $ingredient)
                                <li class="list-group-item">{{ $ingredient->name }}</li>
                            @endforeach
                        </ul>
                    </div>
                </div> --}}
                <div class="col-md-3">
                    <div class="product-details">

                        {{--                        <h4>Activity Log</h4>--}}
                        {{--                        @foreach ($menu?->activities?->take(4) as $activity )--}}
                        {{--                            <p>{{ $activity->causer->first_name }} {{ Str::title($activity->description) }}--}}
                        {{--                                on {{ $activity->created_at->format('Y-M-j h:i a') }}</p>--}}
                        {{--                        @endforeach--}}
                        {{--                        @if ($menu->activities->count() > 4)--}}
                        {{--                            <a href="{{ route('subject-activity-logs', [class_basename($menu), $menu->id]) }}">View All--}}
                        {{--                                Log</a>--}}
                        {{--                        @endif--}}
                    </div>
                </div>
            </div>
        </div>

    </div>

@endsection
