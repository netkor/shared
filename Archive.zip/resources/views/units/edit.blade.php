@extends('layouts.admin')

@section('title', 'Update Unit')
@section('content-header', 'Update Unit')

@section('content')

    <div class="card">
        <div class="card-body">

            <form action="{{ route('units.update', $unit) }}" method="POST" enctype="multipart/form-data">
                @csrf
                @method('PUT')

                <div class="form-group">
                    <label for="name"> Unit Name</label>
                    <input type="text" name="name" class="form-control @error('name') is-invalid @enderror"
                           id="name" placeholder="Unit Name" value="{{ old('name', $unit->name) }}">
                    @error('name')
                    <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                </div>


                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="name">Parent Unit</label>
                            <select name="parent_id" class="form-control @error('parent_id') is-invalid @enderror"
                                    id="parent_id">
                                <option value="">Select Parent Unit</option>
                                @foreach ($units as $unit)
                                    <option value="{{ $unit->id }}">{{ $unit->name }}</option>
                                @endforeach
                            </select>
                            @error('parent_id')
                            <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>


                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="conversion_factor">Conversion Factor</label>
                            <input type="number" name="conversion_factor"
                                   class="form-control @error('conversion_factor') is-invalid @enderror"
                                   id="conversion_factor"
                                   placeholder="Conversion Factor"
                                   value="{{ old('conversion_factor',$unit->conversion_factor??'') }}">
                            @error('conversion_factor')
                            <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>
                </div>
                <button class="btn btn-primary" type="submit">Update</button>
            </form>
        </div>
    </div>
@endsection

@section('js')
    <script src="{{ asset('plugins/bs-custom-file-input/bs-custom-file-input.min.js') }}"></script>
    <script>
        $(document).ready(function () {
            bsCustomFileInput.init();
        });
    </script>
@endsection
