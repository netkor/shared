@extends('layouts.website.site')

@section('title', config('app.name'))

@section('content')
    <div id="index" data-website="{{ $website }}"></div>
@endsection
