@extends('layouts.admin')

@section('title', 'Activity List')
@section('content-header', 'Activities List')

@section('content')
    <div class="card">
        <div class="card-body">
            <table class="table">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Causer</th>
                    <th>Subject</th>
                    <th>Description</th>
                    <th>Created At</th>
                </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>{{$activity->id}}</td>
                        <td>{{$activity->causer?->first_name}}</td>
                        <td>{{$activity->subject?->name}}</td>
                        <td>{{$activity->description}}</td>
                        <td>{{$activity->created_at->format('Y-M-j h:i a')}}</td>
                    </tr>
                </tbody>
            </table>
        </div>
@endsection
