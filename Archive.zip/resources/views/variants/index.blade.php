@extends('layouts.admin')

@section('title', 'Variant List')

@section('content-header',   'Variant List of ' . $product->name)
@section('content-actions')
    <a href="{{ route('products.index', ) }}" class="btn btn-danger">Back</a>
    <a href="{{ route('variants.create', $product) }}" class="btn btn-primary">Add Variant</a>
@endsection
@section('css')
    <link rel="stylesheet" href="{{ asset('plugins/sweetalert2/sweetalert2.min.css') }}">
@endsection
@section('content')
    <div class="card">
        <div class="card-body">


            <table class="table">
                <thead>
                    <tr>
                        {{-- <th>ID</th> --}}
                        <th>Product</th>

                        <th>Variant Name</th>
                        <th>Contained Quantity</th>
                        <th>Unit</th>
                        <th>Created At</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($variants as $variant)
                        <tr>
                            {{-- <td>{{$variant->id}}</td> --}}
                            <td>{{ $variant->product->name }}</td>

                            <td>{{ $variant->name }}</td>
                            <td>{{ $variant->contained_quantity }}</td>
                            <td>{{ $variant->unit->name }}</td>
                            <td>{{ $variant->created_at->format('Y-M-j h:i a') }}</td>
                            <td>
                                <a href="{{ route('variants.edit', [$product, $variant]) }}" class="btn btn-primary"><i
                                        class="fas fa-edit"></i></a>
                                         <a href="{{ route('variants.destroy',  [$product, $variant]) }}" class="btn btn-danger"><i
                                        class="fas fa-trash"></i></a>

                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>

        </div>
    </div>
@endsection

@section('js')
    <script src="{{ asset('plugins/sweetalert2/sweetalert2.min.js') }}"></script>
    <script>
        $(document).ready(function() {
            $(document).on('click', '.btn-delete', function() {
                $this = $(this);
                const swalWithBootstrapButtons = Swal.mixin({
                    customClass: {
                        confirmButton: 'btn btn-success',
                        cancelButton: 'btn btn-danger'
                    },
                    buttonsStyling: false
                })

                swalWithBootstrapButtons.fire({
                    title: 'Are you sure?',
                    text: "Do you really want to delete this variant?",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, delete it!',
                    cancelButtonText: 'No',
                    reverseButtons: true
                }).then((result) => {
                    if (result.value) {
                        $.post($this.data('url'), {
                            _method: 'DELETE',
                            _token: '{{ csrf_token() }}'
                        }, function(res) {
                            $this.closest('tr').fadeOut(500, function() {
                                $(this).remove();
                            })
                        })
                    }
                })
            })
        })
    </script>
@endsection
