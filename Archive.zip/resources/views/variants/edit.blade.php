@extends('layouts.admin')

@section('title', ' Variant')
@section('content-header', ' Variant')

@section('content')

    <div class="card">
        <div class="card-body">

            <form
                action="{{ route('variants.update',[$product, $variant]) }}"
                method="POST"
                enctype="multipart/form-data">
                @csrf

                @method('PUT')

                @include('variants.fields')

                <button class="btn btn-primary" type="submit">Submit</button>
            </form>
        </div>
    </div>
@endsection

@section('js')
    <script src="{{ asset('plugins/bs-custom-file-input/bs-custom-file-input.min.js') }}"></script>
    <script>
        $(document).ready(function () {
            bsCustomFileInput.init();
        });
    </script>
@endsection
