@extends('layouts.admin')

@section('title', 'Create Variant')
@section('content-header', 'Create Variant')

@section('content')

    <div class="card">
        <div class="card-body">

            <form action="{{ route('variants.store',$product) }}" method="POST" enctype="multipart/form-data">
                @csrf

                @include('variants.fields')

                <button class="btn btn-primary" type="submit">Create</button>
            </form>
        </div>
    </div>
@endsection

@section('js')
    <script src="{{ asset('plugins/bs-custom-file-input/bs-custom-file-input.min.js') }}"></script>
    <script>
        $(document).ready(function () {
            bsCustomFileInput.init();
        });
    </script>
@endsection
