import React from 'react'

const Slider = ({website}) => {
        var data=JSON.parse(website);

  return (
    <>
    <div id="slides" className="cover-slides">
		<ul className="slides-container">
			<li className="text-center">
				<img src={window.location.origin + '/storage/' + data.slider1} alt="slider1"/>
				<div className="container">
					<div className="row">
						<div className="col-md-12">
							<h1 className="m-b-20">Welcome To  {data.title}</h1>
							<p className="m-b-40">{data.short_description}</p>

						</div>
					</div>
				</div>
			</li>
			<li className="text-center">
				<img src={window.location.origin + '/storage/' + data.slider2} alt="slider2"/>
				<div className="container">
					<div className="row">
						<div className="col-md-12">
							<h1 className="m-b-20">Welcome To  {data.title}</h1>
							<p className="m-b-40">{data.short_description}</p>
						</div>
					</div>
				</div>
			</li>
			<li className="text-center">
				<img src={window.location.origin + '/storage/' + data.slider3} alt="slider3"/>
				<div className="container">
					<div className="row">
						<div className="col-md-12">
							<h1 className="m-b-20">Welcome To  {data.title}</h1>
							<p className="m-b-40">{data.short_description}</p>
						</div>
					</div>
				</div>
			</li>
		</ul>
		<div className="slides-navigation">
			<a href="#" className="next"><i className="fa fa-angle-right" aria-hidden="true"></i></a>
			<a href="#" className="prev"><i className="fa fa-angle-left" aria-hidden="true"></i></a>
		</div>
	</div>
    </>
  )
}

export default Slider
