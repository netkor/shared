import React from 'react'

function Menus() {
  return (
    <><div className="menu-box">
		<div className="container">
			<div className="row">
				<div className="col-lg-12">
					<div className="heading-title text-center">
						<h2>Special Menu</h2>
					</div>
				</div>
			</div>
			<div className="row">
				<div className="col-lg-12">
					<div className="special-menu text-center">
						<div className="button-group filter-button-group">
							<button className="active" data-filter="*">All</button>
							<button data-filter=".drinks">Drinks</button>
							<button data-filter=".lunch">Fast Food</button>
							<button data-filter=".dinner">Dinner</button>
						</div>
					</div>
				</div>
			</div>

			<div className="row special-list">
				<div className="col-lg-4 col-md-6 special-grid drinks">
					<div className="gallery-single fix">
						<img src="images/coffee.jfif" className="img-fluid" alt="Image"/>
						<div className="why-text">
							<h4>Capichino</h4>
							<h5>Rs 120</h5>
						</div>
					</div>
				</div>

				<div className="col-lg-4 col-md-6 special-grid drinks">
					<div className="gallery-single fix">
						<img src="images/tea.jpg" className="img-fluid" alt="Image"/>
						<div className="why-text">
							<h4>Black Tea</h4>
							<h5> Rs 75</h5>
						</div>
					</div>
				</div>

				<div className="col-lg-4 col-md-6 special-grid drinks">
					<div className="gallery-single fix">
						<img src="images/beer.jpg" className="img-fluid" alt="Image"/>
						<div className="why-text">
							<h4>Beer</h4>
							<h5>Rs 250</h5>
						</div>
					</div>
				</div>

				<div className="col-lg-4 col-md-6 special-grid lunch">
					<div className="gallery-single fix">
						<img src="images/momo1.jpg" className="img-fluid" alt="Image"/>
						<div className="why-text">
							<h4>Chicken Momo</h4>
							<h5> Rs 120</h5>
						</div>
					</div>
				</div>

				<div className="col-lg-4 col-md-6 special-grid lunch">
					<div className="gallery-single fix">
						<img src="images/chow-mien-1200.jpg" className="img-fluid" alt="Image"/>
						<div className="why-text">
							<h4>Chicken Chowmien</h4>
							<h5> Rs 120</h5>
						</div>
					</div>
				</div>

				<div className="col-lg-4 col-md-6 special-grid lunch">
					<div className="gallery-single fix">
						<img src="images/burger-banner.jpg" className="img-fluid" alt="Image"/>
						<div className="why-text">
							<h4>Burger </h4>
							<h5>Rs 120</h5>
						</div>
					</div>
				</div>

				<div className="col-lg-4 col-md-6 special-grid dinner">
					<div className="gallery-single fix">
						<img src="images/thakali1.jpg" className="img-fluid" alt="Image"/>
						<div className="why-text">
							<h4>Thakali Khana Set</h4>
							<h5>Rs 300</h5>
						</div>
					</div>
				</div>

				<div className="col-lg-4 col-md-6 special-grid dinner">
					<div className="gallery-single fix">
						<img src="images/mutton-biryani.jpg" className="img-fluid" alt="Image"/>
						<div className="why-text">
							<h4>Mutton Biryani</h4>
							<h5>Rs 200</h5>
						</div>
					</div>
				</div>

				<div className="col-lg-4 col-md-6 special-grid dinner">
					<div className="gallery-single fix">
						<img src="images/roti-banner.jpg" className="img-fluid" alt="Image"/>
						<div className="why-text">
							<h4>Roti-Sabji</h4>
							<h5>Rs 120</h5>
						</div>
					</div>
				</div>

			</div>
		</div>
	</div></>
  )
}

export default Menus
