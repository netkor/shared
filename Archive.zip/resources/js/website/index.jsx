import { Component } from "react";
import ReactDOM from "react-dom";
import About from "./components/about";
import Contact from "./components/contact";
import Footer from "./components/footer";
import Menus from "./components/menus";
import Navbar from "./components/navbar";
import Slider from "./components/slider";


export default class Index extends Component {

constructor(props) {
        super(props);

        this.state = {
           website: props.website,
        };


    }

    render () {
        return (
            <>
            <Navbar website={this.state.website} />
           <Slider website={this.state.website}/>
           <About website={this.state.website}/>
           <Menus/>
           <Contact website={this.state.website}/>
           <Footer website={this.state.website}/>
           </>


        );
    }

}


if (document.getElementById("index")) {
    const element = document.getElementById("index");
    const props = Object.assign({}, element.dataset);
    ReactDOM.render(<Index {...props}/>, element);
}
