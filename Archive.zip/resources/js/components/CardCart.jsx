import React, { Component } from "react";
import ReactDOM from "react-dom";
import axios from "axios";
import Swal from "sweetalert2";
import { sum } from "lodash";

class Cart extends Component {
    constructor(props) {
        super(props);
        this.state = {
            cart: [],
            menus: [],
            customers: [],
            tables: [],
            accounts: [],
            account_id: "",
            group: "",
            search: "",
            customer_id: "",
            table_id: "",
            table_new_id: "",
            show_model: false,
            is_loading: true,
            recieved_amount: 0,
            discount_amount: 0,
            tender_amount: 0,
        };

        //this.loadCart = this.loadCart.bind(this);
        this.handleChangeQty = this.handleChangeQty.bind(this);
        this.handleEmptyCart = this.handleEmptyCart.bind(this);

        this.loadMenus = this.loadMenus.bind(this);
        this.handleChangeSearch = this.handleChangeSearch.bind(this);
        this.handleSearch = this.handleSearch.bind(this);
        this.setCustomerId = this.setCustomerId.bind(this);
        this.setTableId = this.setTableId.bind(this);
        this.setAccountId = this.setAccountId.bind(this);
        this.setTableNewId = this.setTableNewId.bind(this);
        this.handleClickSubmit = this.handleClickSubmit.bind(this);
        this.handelPayment = this.handelPayment.bind(this);
    }

    componentDidMount() {
        this.loadMenus();
        this.loadCustomers();
        this.loadTables();
        this.generateKOT();
    }

    loadCustomers() {
        axios.get(`/admin/customers`).then((res) => {
            const customers = res.data;
            this.setState({ customers });
        });
    }

    loadTables() {
        axios.get(`/admin/tables`).then((res) => {
            const tables = res.data;
            this.getAccount();
            this.setState({ tables });
        });
    }

    loadMenus(search = "") {
        const query = !!search ? `?search=${search}` : "";
        axios.get(`/admin/pos-menus${query}`).then((res) => {
            const menus = res.data.data;
            this.setState({ menus });
        });
    }

    loadCartByTableId(table_id) {
        this.setState({ is_loading: true });
        axios.get(`/admin/cart/${table_id}`).then((res) => {
            const cart = res.data;

            if (!this.state.group) {
                let group = "";
                if (
                    cart.length > 0 &&
                    cart[cart.length - 1].status !== "hold"
                ) {
                    group = cart[cart.length - 1].group;
                } else {
                    group = Math.random()
                        .toString(36)
                        .substring(2, 7)
                        .toUpperCase();
                }
                this.setState({ group });
            }

            this.setState({ cart });
            this.setState({ is_loading: false });
        });
    }

    handleChangeQty(menu_id, qty) {
        const cart = this.state.cart.map((c) => {
            if (c.menu_id === menu_id && c.group === this.state.group) {
                // if (c.menu_id === menu_id) {
                c.quantity = qty;
            }
            return c;
        });
        this.setState({ cart });

        axios
            .post("/admin/cart/change-qty", {
                menu_id,
                group: this.state.group,
                quantity: qty,
                table_id: this.state.table_id,
            })
            .catch((err) => {
                Swal.fire("Error!", err.response.data.message, "error");
            })
            .finally(() => {});
    }

    getTotal(cart) {
        const total = cart.map((c) => c.quantity * c.price);
        return sum(total).toFixed(2);
    }

    handleClickDelete(group, menu_id, table_id) {
        const cart = this.state.cart.filter((c) => c.menu_id !== menu_id);
        this.setState({ cart });

        axios
            .post("/admin/cart/delete", {
                group,
                menu_id,
                table_id,
                _method: "DELETE",
            })
            .then((res) => {
                console.log(res);
                this.loadTables();
            })
            .catch((err) => {
                Swal.fire("Error!", err.response.data.message, "error");
            })
            .finally(() => {
                this.loadCartByTableId(this.state.table_id);
            });
    }

    handleEmptyCart(table_id) {
        Swal.fire({
            title: "Are you sure?",
            text: "You won't be able to revert this!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yes, empty it!",
        }).then((result) => {
            if (result.isConfirmed) {
                axios
                    .post("/admin/cart/empty", {
                        table_id,
                        _method: "DELETE",
                    })
                    .then((res) => {
                        this.setState({ cart: [] });
                        this.loadTables();
                        Swal.fire(
                            "Empty!",
                            "Your cart has been empty.",
                            "success"
                        );
                    })
                    .catch((err) => {
                        Swal.fire("Error!", err.response.data.message, "error");
                    });
            }
        });
    }

    handleChangeSearch(event) {
        const search = event.target.value;
        this.setState({ search });
        this.loadMenus(search);
    }

    handleSearch(event) {
        if (event.keyCode === 13) {
            this.loadMenus(event.target.value);
        }
    }

    addProductToCart(menu_id) {
        let menu = this.state.menus.find((menu) => menu.id === menu_id);

        if (!!menu) {
            let cart = this.state.cart.find(
                (c) => c.menu_id === menu.id && c.group === this.state.group
            );

            if (!!cart) {
                this.handleChangeQty(menu.id, cart.quantity + 1);
            } else {
                menu = {
                    menu_id: menu.id,
                    name: menu.name,
                    price: menu.price,
                    group: this.state.group,
                    quantity: 1,
                };
                this.setState({ cart: [...this.state.cart, menu] });

                axios
                    .post("/admin/cart", {
                        menu_id,
                        table_id: this.state.table_id,
                        group: this.state.group,
                    })
                    .then((res) => {
                        this.loadTables();

                        console.log(res);
                    })
                    .catch((err) => {
                        Swal.fire("Error!", err.response.data.message, "error");
                    });
            }
        }
    }

    setCustomerId(event) {
        this.setState({ customer_id: event.target.value });
    }

    setTableId(event) {
        this.setState({ table_id: event.target.value });
        this.loadCartByTableId(event.target.value);
    }

    setTableNewId(event) {
        this.setState({ table_id: event.target.value });
    }

    setAccountId(event) {
        this.setState({ account_id: event.target.value });
    }

    handelPayment() {
        //if customer_id is empty
        if (!this.state.customer_id) {
            Swal.fire("Error!", "Please select customer", "error");
            return;
        }
        if (!this.state.account_id) {
            Swal.fire("Error!", "Please select account", "error");
            return;
        }

        Swal.fire({
            title: "Are you sure?Do you want to pay?",
            showCancelButton: true,
            confirmButtonText: "Send",
            showLoaderOnConfirm: true,
            preConfirm: () => {
                return axios
                    .post("/admin/orders", {
                        customer_id: this.state.customer_id,
                        total: this.getTotal(this.state.cart),
                        recieved_amount: this.state.recieved_amount,
                        discount_amount: this.state.discount_amount,
                        tender_amount:
                            parseFloat(this.state.recieved_amount) -
                            this.getTotal(this.state.cart) +
                            parseFloat(this.state.discount_amount),
                        table_id: this.state.table_id,
                        account_id: this.state.account_id,
                    })
                    .then((res) => {
                        this.setState({ cart: [] });
                        this.loadTables();

                        window.location.href = "/admin/cart";

                        return res.data;
                    })
                    .catch((err) => {
                        Swal.showValidationMessage(err.response.data.message);
                    });
            },
            allowOutsideClick: () => !Swal.isLoading(),
        }).then((result) => {
            if (result.value) {
                Swal.fire({
                    title: "Payment Successfull",
                    text: `Payment  has been successfully placed`,
                    type: "success",
                    confirmButtonText: "Ok",
                });
            }
        });
    }

    handleClickSubmit() {
        const cart = this.state.cart.filter((c) => c.status !== "hold");
        if (cart.length > 0) {
            Swal.fire(
                "Error!",
                "Please complete order with status hold",
                "error"
            );
            return;
        }
        this.setState({ show_model: true });
        this.setState({ recieved_amount: this.getTotal(this.state.cart) });
    }

    generateKOT() {}

    getAccount() {
        axios
            .get("/admin/accounts-list")
            .then((res) => {
                this.setState({ accounts: res.data });
            })
            .catch((err) => {
                Swal.fire("Error!", err.response.data.message, "error");
            });
    }

    // handleClickHold = () => {
    //     const cart = this.state.cart.filter((c) => c.status !== "served");
    //     if (cart.length === 0) {
    //         Swal.fire("Error!", "All items are already served", "error");
    //         return;
    //     }
    //     Swal.fire({
    //         title: "Are you sure?",
    //         text: "You want to hold this order!",
    //         type: "warning",
    //         showCancelButton: true,
    //         confirmButtonColor: "#3085d6",
    //         cancelButtonColor: "#d33",
    //         confirmButtonText: "Yes, hold it!",
    //     })
    //         .then((result) => {
    //             if (result.value) {
    //                 axios
    //                     .post("/admin/cart/hold-table", {
    //                         table_id: this.state.table_id,
    //                         _method: "PUT",
    //                     })
    //                     .then((res) => {
    //                         this.loadCartByTableId(this.state.table_id);
    //                         Swal.fire(
    //                             "Hold!",
    //                             "Order has been hold.",
    //                             "success"
    //                         );
    //                         let group = Math.random()
    //                             .toString(36)
    //                             .substring(2, 7)
    //                             .toUpperCase();

    //                         this.setState({group});

    //                         return res.data;
    //                     })
    //                     .catch((err) => {
    //                         Swal.fire(
    //                             "Error!",
    //                             err.response.data.message,
    //                             "error"
    //                         );
    //                     });
    //             }
    //         })
    //         .catch((err) => {
    //             Swal.showValidationMessage(err.response.data.message);
    //         });
    // };

    handleClickSwap = () => {
        Swal.fire({
            title: "Swap Table ",
            input: "select",
            inputOptions: this.state.tables.reduce((acc, table) => {
                acc[table.id] = table.name;
                return acc;
            }, {}),

            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yes,  it!",
        })
            .then((result) => {
                //if table has no hold item then cannot
                const cart = this.state.cart.filter(
                    (c) =>
                        c.status !== "hold" ||
                        c.status === "preparing" ||
                        c.status === "serving"
                );
                if (cart.length > 0) {
                    Swal.fire(
                        "Error!",
                        "Please complete order with status hold",
                        "error"
                    );
                    return;
                }
                console.log(result.value);
                if (result.value) {
                    axios
                        .post("/admin/cart/-table", {
                            table_id: this.state.table_id,
                            _method: "PUT",
                            new_table_id: result.value,
                        })
                        .then((res) => {
                            this.loadTables();
                            this.setTableId({
                                target: { value: result.value },
                            });
                            this.loadCartByTableId(result.value);
                            Swal.fire("Swap!", "Order has been .", "success");
                        })
                        .catch((err) => {
                            Swal.showValidationMessage(
                                err.response.data.message
                            );
                        });
                }
            })
            .catch((err) => {
                Swal.showValidationMessage(err.response.data.message);
            });
    };

    handelAddCustomer() {
        window.open("/admin/customers/create", "_blank");
    }

    render() {
        const { cart, menus, customers, tables, accounts } = this.state;
        return (
            <div className="container-fluid  text-bold">
                <div className="col mb-2">
                    <div className="row">
                        {tables.map((table) => (
                            <div
                                className="col-md-1 text-center"
                                key={table.id}
                            >
                                {table.status === "open"
                                    ? [
                                          <div
                                              className={` card bg-success ${
                                                  table.id ===
                                                  this.state.table_id
                                                      ? "bg-info"
                                                      : ""
                                              }`}
                                              style={{
                                                  height: "50%",
                                                  fontSize: 10,
                                              }}
                                              onClick={() =>
                                                  this.setTableId({
                                                      target: {
                                                          value: table.id,
                                                      },
                                                  })
                                              }
                                          >
                                              <div className="card-title">
                                                  <h6 className="card-title text-white">
                                                      {" "}
                                                      {table.name}
                                                  </h6>
                                              </div>
                                          </div>,
                                      ]
                                    : [
                                          <div
                                              className={`card bg-danger ${
                                                  table.id ===
                                                  this.state.table_id
                                                      ? "bg-dark"
                                                      : ""
                                              }`}
                                              style={{
                                                  height: "50%",
                                                  fontSize: 10,
                                              }}
                                              onClick={() =>
                                                  this.setTableId({
                                                      target: {
                                                          value: table.id,
                                                      },
                                                  })
                                              }
                                          >
                                              <div className="card-body">
                                                  <h6 className="card-title text-white text-small">
                                                      {" "}
                                                      {table.name}
                                                  </h6>
                                              </div>
                                          </div>,
                                      ]}
                            </div>
                        ))}
                    </div>
                    <div className="row" hidden={this.state.table_id}>
                        <h1>Select table first</h1>
                    </div>

                    <div className="row" hidden={!this.state.table_id}>
                        <div className="col-md-3 col-lg-6">
                            <div className="user-cart">
                                <div className="container">
                                    <table className="table table-striped">
                                        <thead>
                                            <tr>
                                                <th>Batch</th>
                                                <th>Menu</th>
                                                <th>Quantity</th>
                                                <th className="text-right">
                                                    Price
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {cart.map((c) => (
                                                <tr key={c.menu_id + c.group}>
                                                    <td>{c.group}</td>
                                                    <td>{c.name}</td>
                                                    <td
                                                        className="row"
                                                        disabled={
                                                            c.status ===
                                                                "hold" ||
                                                            c.status ===
                                                                "preparing" ||
                                                            c.status ===
                                                                "serving"
                                                        }
                                                    >
                                                        <div
                                                            className="btn-group mr-1"
                                                            role="group"
                                                        >
                                                            {/* <button
                                                                className="btn btn-sm btn-success mr-1"
                                                                disabled={
                                                                    c.status ===
                                                                        "hold" ||
                                                                    c.status ===
                                                                        "preparing" ||
                                                                    c.status ===
                                                                        "serving"
                                                                }
                                                                onClick={() =>
                                                                    this.handleChangeQty(
                                                                        c.menu_id,
                                                                        c.quantity +
                                                                            1
                                                                    )
                                                                }
                                                            >
                                                                +
                                                            </button> */}
                                                            <input
                                                                type="text"
                                                                className="form-control form-control-sm qty mr-1"
                                                                readOnly={
                                                                    c.status ===
                                                                        "hold" ||
                                                                    c.status ===
                                                                        "preparing" ||
                                                                    c.status ===
                                                                        "serving"
                                                                }
                                                                value={
                                                                    c.quantity
                                                                }
                                                                onChange={(
                                                                    event
                                                                ) =>
                                                                    this.handleChangeQty(
                                                                        c.menu_id,
                                                                        event
                                                                            .target
                                                                            .value
                                                                    )
                                                                }
                                                            />
                                                            {/* <button
                                                                className="btn btn-sm btn-warning mr-1"
                                                                disabled={
                                                                    c.status ===
                                                                        "hold" ||
                                                                    c.status ===
                                                                        "preparing" ||
                                                                    c.status ===
                                                                        "serving"
                                                                }
                                                                onClick={() =>
                                                                    this.handleChangeQty(
                                                                        c.menu_id,
                                                                        c.quantity -
                                                                            1
                                                                    )
                                                                }
                                                            >
                                                                -{" "}
                                                            </button> */}
                                                            <button
                                                                className="btn btn-sm btn-danger mr-1"
                                                                onClick={() =>
                                                                    this.handleClickDelete(
                                                                        c.group,
                                                                        c.menu_id,
                                                                        this
                                                                            .state
                                                                            .table_id
                                                                    )
                                                                }
                                                            >
                                                                <i className="fas fa-times"></i>
                                                            </button>
                                                        </div>
                                                    </td>
                                                    <td className="text-right">
                                                        {
                                                            window.APP
                                                                .currency_symbol
                                                        }{" "}
                                                        {(
                                                            c.price * c.quantity
                                                        ).toFixed(2)}
                                                    </td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            <div className="row text-bold">
                                <div className="col">Total:</div>
                                <div className="col text-right">
                                    {window.APP.currency_symbol}{" "}
                                    {this.getTotal(cart)}
                                </div>
                            </div>
                        </div>

                        <div className="col-md-6">
                            <div className="card">
                                <div className="card-header">
                                    <h2 className="card-title">
                                        Bill Of{" "}
                                        {this.state.tables.map((t) => {
                                            if (t.id == this.state.table_id) {
                                                return t.name;
                                            }
                                        })}{" "}
                                    </h2>
                                </div>
                                <div className="card-body">
                                    <div className="row">
                                        <div className="col-md-6">
                                            <div className="form-group">
                                                <label>Customer</label>
                                                <select
                                                    className="form-control"
                                                    onChange={
                                                        this.setCustomerId
                                                    }
                                                >
                                                    <option value="">
                                                        Select Customer
                                                    </option>
                                                    {customers.map((c) => (
                                                        <option
                                                            key={c.id}
                                                            value={c.id}
                                                        >
                                                            {c.name} ({c.phone})
                                                            points: [{c.points}]
                                                        </option>
                                                    ))}
                                                </select>
                                            </div>
                                        </div>
                                        <div className="col-md-6">
                                            <label>
                                                Click Refresh After Creating
                                                Customer
                                            </label>

                                            <div className="row">
                                                <div className="col-md-6">
                                                    <button
                                                        className="btn btn-primary"
                                                        onClick={
                                                            this
                                                                .handelAddCustomer
                                                        }
                                                    >
                                                        Add Customer
                                                    </button>
                                                </div>
                                                <div className="col-md-6">
                                                    <button
                                                        className="btn btn-success"
                                                        onClick={() =>
                                                            this.loadCustomers()
                                                        }
                                                    >
                                                        <i className="fa fa-refresh"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col-md-12">
                                            {/* radiobutton to select account */}
                                            <div className="form-group">
                                                <label>Account</label>
                                                <select
                                                    className="form-control"
                                                    onChange={this.setAccountId}

                                                >
                                                    <option value="">
                                                        Select Account
                                                    </option>
                                                    {accounts.map((a) => (

                                                        <option
                                                            key={a.id}
                                                            value={a.id}
                                                        >
                                                            {a.name}
                                                        </option>
                                                    ))}
                                                </select>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="row">
                                        {/* <div className="col">
                                        <button
                                            type="button"
                                            className="btn btn-danger btn-block"
                                            onClick={() =>
                                                this.handleEmptyCart(
                                                    this.state.table_id
                                                )
                                            }
                                            disabled={!cart.length}
                                        >
                                            Cancel
                                        </button>
                                    </div> */}
                                        <div className="col">
                                            <div className="card">
                                                <div className="card-header">
                                                    <h3 className="card-title">
                                                        Payment Amount
                                                    </h3>
                                                </div>
                                                <div className="card-body">
                                                    <div className="row">
                                                        <div className="col-md-4">
                                                            <label>
                                                                Recieved Amount{" "}
                                                            </label>
                                                            <input
                                                                type={"number"}
                                                                className="form-control"
                                                                defaultValue={this.getTotal(
                                                                    cart
                                                                )}
                                                                onChange={(
                                                                    event
                                                                ) =>
                                                                    this.setState(
                                                                        {
                                                                            recieved_amount:
                                                                                event
                                                                                    .target
                                                                                    .value,
                                                                        }
                                                                    )
                                                                }
                                                            />
                                                        </div>
                                                        <div className="col-md-4">
                                                            <label>
                                                                Tender Amount{" "}
                                                            </label>
                                                            <input
                                                                type={"number"}
                                                                className="form-control"
                                                                value={
                                                                    parseFloat(
                                                                        this
                                                                            .state
                                                                            .recieved_amount
                                                                    ) -
                                                                    this.getTotal(
                                                                        cart
                                                                    ) +
                                                                    parseFloat(
                                                                        this
                                                                            .state
                                                                            .discount_amount ??
                                                                            0
                                                                    )
                                                                }
                                                                readOnly
                                                            />
                                                        </div>
                                                        <div className="col-md-4">
                                                            <label>
                                                                Discount Amount{" "}
                                                            </label>
                                                            <input
                                                                type={"number"}
                                                                className="form-control"
                                                                defaultValue={0}
                                                                onChange={(
                                                                    event
                                                                ) =>
                                                                    this.setState(
                                                                        {
                                                                            discount_amount:
                                                                                event
                                                                                    .target
                                                                                    .value,
                                                                        }
                                                                    )
                                                                }
                                                            />
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <button
                                                type="button"
                                                className="btn btn-primary btn-block"
                                                disabled={!cart.length}
                                                onClick={this.handelPayment}
                                            >
                                                Proceed To Pay
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* right section search and product */}
                        {/* <div className="col-md-3 col-lg-6">
                                <div className="mb-2">
                                    <input
                                        type="text"
                                        className="form-control"
                                        placeholder="Search Menu..."
                                        onChange={this.handleChangeSearch}
                                        onKeyDown={this.handleSearch}
                                    />
                                </div>
                                <div className="order-product">
                                    {menus.map((p) => (
                                        <div
                                            onClick={() => {
                                                if (this.state.is_loading)
                                                    return;
                                                this.addProductToCart(p.id);
                                            }}
                                            key={p.id}
                                            className="item mouse-pointer"
                                        >
                                            <img src={p.image_url} alt=""/>
                                            <h5
                                                style={
                                                    window.APP
                                                        .warning_quantity >
                                                    p.quantity
                                                        ? {color: "red"}
                                                        : {}
                                                }
                                            >
                                                {p.name}({p.quantity})
                                            </h5>
                                        </div>
                                    ))}
                                </div>
                            </div> */}
                    </div>
                </div>
            </div>
        );
    }
}

export default Cart;

if (document.getElementById("cart")) {
    ReactDOM.render(<Cart />, document.getElementById("cart"));
}
