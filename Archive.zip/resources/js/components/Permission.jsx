import axios from "axios";
import {Component} from "react";
import ReactDOM from "react-dom";
import Swal from "sweetalert2";

export default class Permission extends Component {
    constructor(props) {
        super(props);

        this.state = {
            permissions: [],
            roles: [],
            permission: "",
            roleName: "",
            search: "",
        };

        this.loadPermissions = this.loadPermissions.bind(this);
        this.loadRoles = this.loadRoles.bind(this);
        this.handleSearch = this.handleSearch.bind(this);
    }

    componentDidMount() {
        this.loadPermissions();
        this.loadRoles();
    }

    loadPermissions(search = "") {
        const query = !!search ? `?search=${search}` : "";
        axios.get(`/admin/permissions${query}`).then((res) => {
            const permissions = res.data.data;
            this.setState({permissions});
        });
    }

    loadRoles() {
        axios.get("/admin/roles").then((response) => {
            const roles = response.data.data;
            this.setState({roles});
        });
    }

    handleChangeSearch(event) {
        const search = event.target.value;
        this.setState({search});
        this.loadMenus(search);
    }

    handleSearch(event) {
        if (event.keyCode === 13) {
            this.loadPermissions(event.target.value);
        }
    }

    addPermission() {
        axios
            .post("/admin/permissions", {
                name: this.state.permission,
            })
            .then((res) => {
                console.log(res);
                this.loadPermissions();
                this.setState({permissionName: ""});
                //show success message
                Swal.fire({
                    title: "Success!",
                    text: "Permission added successfully",
                    icon: "success",
                    confirmButtonText: "OK",
                });

                return res;
            });
    }


    deletePermission(id) {
        axios
            .delete(`/admin/permissions/${id}`)
            .then((res) => {
                console.log(res);
                this.loadPermissions();
                //show success message
                Swal.fire({
                    title: "Success!",
                    text: "Permission deleted successfully",
                    icon: "success",
                    confirmButtonText: "OK",
                });
                return res;
            })
            .catch((err) => {
                console.log(err);
                //show error message
                Swal.fire({
                    title: "Error!",
                    text: "Permission not deleted",

                    icon: "error",
                    confirmButtonText: "OK",
                });
            });
    }

    handlePermissionToRole(permission, role) {
        if (role.permissions.includes(permission.name)) {
            // role.permissions = role.permissions.filter((p) => p !== permission.name);
            this.setState({
                ...this.state,
                roles: this.state.roles.map((r) => {
                        if (r.id === role.id) {
                            r.permissions = r.permissions.filter((p) => p !== permission.name);
                        }
                        return r;
                    }
                ),
            });


            this.revokePermissionToRole(permission.name, role.id);
        } else {
            this.setState({
                ...this.state,
                roles: this.state.roles.map((r) => {
                        if (r.id === role.id) {
                            r.permissions.push(permission.name);
                        }
                        return r;
                    }
                ),
            });


            this.givePermissionToRole(permission.name, role.id);
        }


    }

    givePermissionToRole = (permission, roleId) => {
        axios
            .post(`/api/permissions/give-permission-to-role`, {
                permission: permission,
                roleId: roleId
            })
            .then((res) => {
                console.log(res);
                this.loadPermissions();
            });
    }

    revokePermissionToRole = (permission, roleId) => {
        axios
            .post(`/api/permissions/revoke-permission-to-role`, {
                permission: permission,
                roleId: roleId
            })
            .then((res) => {
                this.loadPermissions();
            });
    }


    render() {
        return (
            <>
                <div className="row">
                    <div className="col-md-3">
                        <div className="col">
                            {
                                <div className="col">
                                    <label htmlFor="permission_name">
                                        Permission Name
                                    </label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        onChange={(e) => {
                                            this.setState({
                                                permission: e.target.value,
                                            });
                                        }}
                                    />
                                    <div className="mb-2 mt-2">
                                        <button
                                            className="btn btn-primary"
                                            onClick={() => this.addPermission()}
                                        >
                                            {" "}
                                            Add Permission{" "}
                                        </button>
                                    </div>
                                </div>
                            }
                            {
                                <div className="col">
                                    <label htmlFor="role_name">Role Name</label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        onChange={(e) => {
                                            this.setState({
                                                roleName: e.target.value,
                                            });
                                        }}
                                    />
                                    <div className="mb-2 mt-2">
                                        <button
                                            className="btn btn-primary"
                                            onClick={() =>
                                                console.log(this.state)
                                            }
                                        >
                                            {" "}
                                            Add Role{" "}
                                        </button>
                                    </div>
                                </div>
                            }
                        </div>
                    </div>
                    <div className="col-md-9">
                        <div className="col">
                            <div className="row">
                                <div className="mb-8">
                                    <input
                                        type="text"
                                        className="form-control"
                                        placeholder="Search Permission..."
                                        onChange={this.handleChangeSearch}
                                        onKeyDown={this.handleSearch}
                                    />
                                </div>
                                <div className="col-md-4 mb-2-mt-2 ml-2">
                                    <button
                                        className="btn btn-primary"
                                        onClick={() => this.loadPermissions()}
                                    >
                                        {" "}
                                        Refresh{" "}
                                    </button>
                                </div>
                            </div>

                            <table className="table">
                                <thead>
                                <tr>
                                    <th>SN</th>
                                    <th>Permission</th>
                                    {this.state.roles.map((role) => (
                                        <th key={role.id}>{role.name}</th>
                                    ))}
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                {this.state.permissions.map(
                                    (permission, index) => (
                                        <tr key={permission.id}>
                                            <td> {index + 1}</td>
                                            <td>{permission.name}</td>
                                            {this.state.roles.map(
                                                (role) => (
                                                    <td key={role.id}>
                                                        <input
                                                            type="checkbox"
                                                            name="permission[]"
                                                            checked={role.permissions.includes(permission.name)}

                                                            onChange={() => this.handlePermissionToRole(permission, role)}
                                                        />
                                                    </td>
                                                )
                                            )}
                                            <td>
                                                <button
                                                    className="btn btn-danger"
                                                    onClick={() =>
                                                        this.deletePermission(
                                                            permission.id
                                                        )
                                                    }
                                                >
                                                    Delete
                                                </button>
                                            </td>
                                        </tr>
                                    )
                                )}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </>
        );
    }
}

if (document.getElementById("permission")) {
    const element = document.getElementById("permission");
    ReactDOM.render(<Permission/>, element);
}
