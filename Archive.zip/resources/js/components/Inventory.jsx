import React, {Component} from "react";
import ReactDOM from "react-dom";
import axios from "axios";
import Swal from "sweetalert2";

class Inventory extends Component {
    constructor(props) {
        super(props);
        const inventory = JSON.parse(props.inventory);
        const units = JSON.parse(props.units);
        const vendors = JSON.parse(props.vendors);

        this.state = {
            products: [],
            vendors: vendors,
            units: units,
            inventory_products: inventory.products,
            unit_id: "",
            barcode: "",
            search: "",
            vendor_id: inventory.vendor_id ?? null,
            bill_no: inventory.bill_no ?? "",
            billing_date: inventory.billing_date ?? null,
            vat: inventory.vat ?? 0,
            discount: inventory.discount ?? 0,
            extra_charge: inventory.extra_charge ?? 0,
            batch_no: inventory.batch_no,
            expiry_date: "",
            alert_quantity: "",
            inventory_id: inventory.id,
            inventory: inventory,
        };

        this.handleOnChangeBarcode = this.handleOnChangeBarcode.bind(this);
        this.handleScanBarcode = this.handleScanBarcode.bind(this);
        this.handleChangeSearch = this.handleChangeSearch.bind(this);
        this.handleSeach = this.handleSeach.bind(this);
    }

    componentDidMount() {
        this.loadProducts();
    }

    loadProducts(search = "") {
        const query = !!search ? `?search=${search}` : "";
        axios.get(`/admin/products${query}`).then((res) => {
            const products = res.data.data;
            this.setState({products});
        });
    }

    setVendorId(event) {
        this.setState({vendor_id: event.target.value});
    }

    handleOnChangeBarcode(event) {
        const barcode = event.target.value;
        console.log(barcode);
        this.setState({barcode});
    }

    handleScanBarcode(event) {
        event.preventDefault();
        const {barcode} = this.state;
        if (!!barcode) {
            axios
                .post("/admin/cart", {barcode})
                .then((res) => {
                    //this.loadCart();
                    this.setState({barcode: ""});
                })
                .catch((err) => {
                    Swal.fire("Error!", err.response.data.message, "error");
                });
        }
    }

    handleChangeSearch(event) {
        const search = event.target.value;
        this.setState({search});
    }

    handleSeach(event) {
        if (event.keyCode === 13) {
            this.loadProducts(event.target.value);
        }
    }

    addProductToList(product_id) {
        let product = this.state.products.find((p) => p.id === product_id);

        if (!!product) {
            // if product is already in inventory_product

            let inventory_products = this.state.inventory_products.find(
                (c) => c.id === product.id
            );

            if (!!inventory_products) {
                Swal.fire("Error!", "Product is already in inventory", "error");
            } else {
                this.setState({
                    inventory_products: [
                        ...this.state.inventory_products,
                        {
                            id: product.id,
                            name: product.name,
                            variants: product.variants,
                            variant_id: product.variants[0].id,
                            product_id: product.id,
                            unit_id: null,
                            quantity: 1,
                            vat: 0,
                            discount: 0,
                            cost_price: 0,
                            expiry_date: null,
                            alert_quantity: 1,
                        },
                    ],
                });
            }
        }
    }


    handelSubmitButton(
        inventory_id,
        vendor_id,
        bill_no,
        billing_date,
        vat,
        discount,
        extra_charge,
        inventory_products
    ) {
        axios
            .post(`/admin/inventory-products/${inventory_id}`, {
                _method: "PUT",
                inventory_id,
                vendor_id,
                bill_no,
                billing_date,
                vat,
                discount,
                extra_charge,

                products: inventory_products,
            })
            .then((res) => {
                Swal.fire("Success!", "Stocks Added", "success");

                window.location.href = "/admin/inventory";
            })
            .catch((err) => {
                Swal.fire("Error!", err.response.data.message, "error");
            });
    }

    render() {
        const {vendors, products, units, inventory_products, inventory} =
            this.state;

        function onDragEnd(result, inventory_products) {
            if (!result.destination) return;
            const items = Array.from(inventory_products);
            const [reorderedItem] = items.splice(result.source.index, 1);
            items.splice(result.destination.index, 0, reorderedItem);
            inventory_products = items;


        }

        return (

            <div className="col">
                <h4>Manage Inventory</h4>
                <div className="row">
                    <div className="col-lg-3 mb-4">
                        {
                            <div className="col">
                                <label htmlFor="vendor_id">Select Vendor</label>
                                <select
                                    className="form-control"
                                    onChange={
                                        (e) => this.setState({
                                            vendor_id: e.target.value
                                        })

                                    }
                                    //     value={this.state.vendor_id}


                                >
                                    <option selected>Select Vendor</option>
                                    {vendors.map((vendor) => (
                                        <option
                                            key={vendor.id}
                                            value={vendor.id}


                                            selected={this.state.vendor_id == vendor.id}


                                        >
                                            {vendor.name}
                                        </option>
                                    ))}
                                </select>
                            </div>
                        }
                    </div>
                    <div className="col-lg-3 mb-4">
                        {
                            <div className="col">
                                <label htmlFor="batch_no">Batch No.</label>
                                <input
                                    type="text"
                                    className="form-control"
                                    disabled
                                    value={this.state.batch_no}
                                />
                            </div>
                        }
                    </div>
                    <div className="col-lg-3 mb-4">
                        {
                            <div className="col">
                                <label htmlFor="vendor_id">Bill No.</label>
                                <input
                                    type="number"
                                    className="form-control"
                                    value={this.state.bill_no}
                                    onChange={() =>
                                        this.setState({
                                            bill_no: event.target.value,
                                        })
                                    }
                                />
                            </div>
                        }
                    </div>
                    <div className="col-lg-3 mb-4">
                        {
                            <div className="col">
                                <label htmlFor="vendor_id">Bill Date</label>
                                <input
                                    type="date"
                                    className="form-control"
                                    value={this.state.billing_date}

                                    onChange={() =>
                                        this.setState({
                                            billing_date: event.target.value,
                                        })
                                    }
                                />
                            </div>
                        }
                    </div>
                </div>
                <div className="row">
                    <div className="col-lg-3 mb-4">
                        {
                            <div className="col">
                                <label htmlFor="vendor_id">VAT Amount</label>
                                <input
                                    type="number"
                                    className="form-control"
                                    value={this.state.vat}
                                    onChange={() =>
                                        this.setState({
                                            vat: event.target.value,
                                        })
                                    }
                                />
                            </div>
                        }
                    </div>
                    <div className="col-lg-3 mb-4">
                        {
                            <div className="col">
                                <label htmlFor="vendor_id">Discount</label>
                                <input
                                    type="number"
                                    className="form-control"
                                    value={this.state.discount}
                                    onChange={() =>
                                        this.setState({
                                            discount: event.target.value,
                                        })
                                    }
                                />
                            </div>
                        }
                    </div>
                    <div className="col-lg-3 mb-4">
                        {
                            <div className="col">
                                <label htmlFor="vendor_id">
                                    Transport Charge
                                </label>
                                <input
                                    type="number"
                                    className="form-control"
                                    value={this.state.extra_charge}
                                    onChange={() =>
                                        this.setState({
                                            extra_charge:
                                            event.target.value,
                                        })
                                    }
                                />
                            </div>
                        }
                    </div>
                    <div className="col-lg-3 mt-4">
                        <button
                            className="btn btn-primary"
                            disabled={!inventory_products.length}
                            onClick={() =>
                                this.handelSubmitButton(
                                    this.state.inventory_id,
                                    this.state.vendor_id,
                                    this.state.bill_no,
                                    this.state.billing_date,
                                    this.state.vat,
                                    this.state.discount,
                                    this.state.extra_charge,
                                    inventory_products
                                )
                            }
                        >
                            {" "}
                            Add Product to inventory{" "}
                        </button>
                    </div>
                </div>


                <div className="row">
                    <div className="col-md-8 col-lg-8">

                        <div className="user-cart">
                            <div className="container">
                                <table className="table table-striped">
                                    <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Qty</th>
                                        <th>C. Price</th>
                                        <th>Variant</th>
                                        <th>VAT</th>
                                        <th>Discount</th>
                                        <th>Ex-Date</th>
                                        <th>Alert Qty</th>
                                        <th>Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    {inventory_products.map((product) => (
                                        <tr key={product.id}>
                                            <td>{product.name}</td>
                                            <td>
                                                <input
                                                    type="number"
                                                    className="form-control form-control-sm "
                                                    value={product.quantity}
                                                    onChange={() =>
                                                        this.setState(
                                                            (
                                                                prevState
                                                            ) => ({
                                                                inventory_products:
                                                                    prevState.inventory_products.map(
                                                                        (
                                                                            p
                                                                        ) =>
                                                                            p.id ===
                                                                            product.id
                                                                                ? {
                                                                                    ...p,
                                                                                    quantity:
                                                                                    event
                                                                                        .target
                                                                                        .value,
                                                                                }
                                                                                : p
                                                                    ),
                                                            })
                                                        )
                                                    }
                                                />
                                            </td>
                                            <td>
                                                <input
                                                    type="number"
                                                    className="form-control form-control-sm "
                                                    value={
                                                        product.cost_price
                                                    }
                                                    onChange={() =>
                                                        this.setState(
                                                            (
                                                                prevState
                                                            ) => ({
                                                                inventory_products:
                                                                    prevState.inventory_products.map(
                                                                        (
                                                                            p
                                                                        ) =>
                                                                            p.id ===
                                                                            product.id
                                                                                ? {
                                                                                    ...p,
                                                                                    cost_price:
                                                                                    event
                                                                                        .target
                                                                                        .value,
                                                                                }
                                                                                : p
                                                                    ),
                                                            })
                                                        )
                                                    }
                                                />
                                            </td>

                                            <td>
                                                <select
                                                    className="form-control form-control-sm mr-5"
                                                    defaultValue={product.variant_id}
                                                    onChange={() =>
                                                        this.setState((prevState) => ({
                                                                inventory_products: prevState.inventory_products
                                                                    .map(
                                                                        (p) => p.id === product.id
                                                                            ? {...p, variant_id: event.target.value,}
                                                                            : p
                                                                    ),
                                                            })
                                                        )}

                                                >
                                                    <option>
                                                        Select Variant
                                                    </option>
                                                    {product.variants.map((variant) => (
                                                        <option
                                                            key={variant.id}
                                                            value={variant.id}
                                                        >
                                                            {variant.name}
                                                        </option>
                                                    ))}
                                                </select>
                                            </td>

                                            <td>
                                                <input
                                                    type="number"
                                                    className="form-control form-control-sm "
                                                    value={product.vat}
                                                    onChange={() =>
                                                        this.setState(
                                                            (
                                                                prevState
                                                            ) => ({
                                                                inventory_products:
                                                                    prevState.inventory_products.map(
                                                                        (
                                                                            p
                                                                        ) =>
                                                                            p.id ===
                                                                            product.id
                                                                                ? {
                                                                                    ...p,
                                                                                    vat: event
                                                                                        .target
                                                                                        .value,
                                                                                }
                                                                                : p
                                                                    ),
                                                            })
                                                        )
                                                    }
                                                />
                                            </td>
                                            <td>
                                                <input
                                                    type="number"
                                                    className="form-control form-control-sm "
                                                    value={product.discount}
                                                    onChange={() =>
                                                        this.setState(
                                                            (
                                                                prevState
                                                            ) => ({
                                                                inventory_products:
                                                                    prevState.inventory_products.map(
                                                                        (
                                                                            p
                                                                        ) =>
                                                                            p.id ===
                                                                            product.id
                                                                                ? {
                                                                                    ...p,
                                                                                    discount:
                                                                                    event
                                                                                        .target
                                                                                        .value,
                                                                                }
                                                                                : p
                                                                    ),
                                                            })
                                                        )
                                                    }
                                                />
                                            </td>
                                            <td>
                                                <input
                                                    type="date"
                                                    className="form-control form-control-sm "
                                                    value={
                                                        product.expiry_date
                                                    }
                                                    onChange={() =>
                                                        this.setState(
                                                            (
                                                                prevState
                                                            ) => ({
                                                                inventory_products:
                                                                    prevState.inventory_products.map(
                                                                        (
                                                                            p
                                                                        ) =>
                                                                            p.id ===
                                                                            product.id
                                                                                ? {
                                                                                    ...p,
                                                                                    expiry_date:
                                                                                    event
                                                                                        .target
                                                                                        .value,
                                                                                }
                                                                                : p
                                                                    ),
                                                            })
                                                        )
                                                    }
                                                />
                                            </td>
                                            <td>
                                                <input
                                                    type="number"
                                                    className="form-control form-control-sm "
                                                    value={
                                                        product.alert_quantity
                                                    }
                                                    onChange={() =>
                                                        this.setState(
                                                            (
                                                                prevState
                                                            ) => ({
                                                                inventory_products:
                                                                    prevState.inventory_products.map(
                                                                        (
                                                                            p
                                                                        ) =>
                                                                            p.id ===
                                                                            product.id
                                                                                ? {
                                                                                    ...p,
                                                                                    alert_quantity:
                                                                                    event
                                                                                        .target
                                                                                        .value,
                                                                                }
                                                                                : p
                                                                    ),
                                                            })
                                                        )
                                                    }
                                                />
                                            </td>
                                            <td>
                                                <button className="btn btn-danger btn-sm"
                                                        onClick={() => this.setState((prevState) => ({
                                                            inventory_products: prevState.inventory_products.filter((p) => p.id !== product.id)
                                                        }))}
                                                >
                                                    <i className="fas fa-times"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4 col-lg-4">
                        <div className="row mb-2">
                            <div className="col">
                                <form onSubmit={this.handleScanBarcode}>
                                    <input
                                        type="text"
                                        className="form-control"
                                        placeholder="Search Product..."
                                        onChange={this.handleChangeSearch}
                                        onKeyDown={this.handleSeach}
                                    />
                                </form>
                            </div>
                            <div className="row">
                                <div className="col">
                                    <button
                                        className="btn btn-primary btn-md"
                                        //launch route new route admin/products/create in next tab

                                        onClick={() => window.open('/admin/products/create', '_blank')}
                                    >
                                        <i className="fas fa-plus"></i>

                                    </button>
                                </div>
                                <div className="col">
                                    <button
                                        className="btn btn-primary btn-md"
                                        //loadProduct on click
                                        onClick={() =>

                                            this.loadProducts()
                                        }
                                    >
                                        <i className="fa-solid fa-arrows-rotate"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div className="row mb-2 ml-1">
                            <div className="order-product">
                                {products.map((p) => (
                                    <div
                                        onClick={() =>
                                            this.addProductToList(p.id)
                                        }
                                        key={p.id}
                                        className="item"
                                    >
                                        {/*<img*/}
                                        {/*    src={p.image}*/}
                                        {/*    alt={p.name}*/}
                                        {/*    style={{*/}
                                        {/*        width: "120px",*/}
                                        {/*        height: "120px",*/}
                                        {/*        borderRadius: "5px",*/}
                                        {/*        padding: "5px"*/}
                                        {/*    }}*/}

                                        {/*/>*/}
                                        <button className="btn btn-primary bg-blue">

                                            {p.name}
                                        </button>
                                    </div>
                                ))}
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        );
    }
}

export default Inventory;

if (document.getElementById("inventory")) {
    const element = document.getElementById("inventory");
    const props = Object.assign({}, element.dataset);
    ReactDOM.render(<Inventory {...props} />, element);
}
