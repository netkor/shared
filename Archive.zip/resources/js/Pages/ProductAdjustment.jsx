import React, {Component} from "react";
import ReactDOM from "react-dom";

export default class ProductAdjustment extends Component {

    constructor(props) {
        super(props);
        this.state = {
            product: JSON.parse(props.product),
            units: JSON.parse(props.units),
        };
    }

    render() {
        return (
            <>
                <div className="bg-white pl-4 rounded-lg shadow-md">
                    <div className="mt-2 grid grid-cols-12 border-t">
                        <div className="col-span-8">
                            <h3 className="text-md mb-8 mt-4 px-2 font-semibold text-[#1f384c]">
                                Product Adjust {this.state.product.name}
                            </h3>
                        </div>
                        <div>


                        </div>
                    </div>
                </div>
            </>
        )
    }
}


if (document.getElementById("product-adjustment")) {
    const element = document.getElementById("product-adjustment");
    const props = Object.assign({}, element.dataset);
    ReactDOM.render(<ProductAdjustment {...props} />, element);
}
