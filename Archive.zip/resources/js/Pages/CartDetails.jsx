import React, {Component} from "react";
import ReactDOM from "react-dom";
import ItemList from "../components/Partials/ItemList";
import TableRow from "../components/Partials/TableRow";
import {Table, TableBody, TableCell, TableContainer, TableHeader, TableRow as Row} from "@windmill/react-ui";

export default class CartDetails extends Component {
    constructor(props) {
        super(props);

        this.state = {
            carts: JSON.parse(props.carts),
            activeRow: null
        };

        this.setActiveRow = this.setActiveRow.bind(this);

    }

    componentDidMount() {
        this.setActiveRow(this.state.carts[0].group)
        console.log(this.state.activeRow);

        Echo
            .channel('cart')
            .listen('MessageSent', (e) => {
                console.log('ddd')
            });
    }

    setActiveRow = (group) => {
        this.setState({
            activeRow: group,
            carts: this.state.carts.map((cart) => {
                if (cart.group === group) {
                    cart.unread = false;
                }
                return cart;
            })
        });
    }

    render() {
        return (
            <div className="mt-2 grid grid-cols-12 border-t">
                <div className="bg-white rounded-bl-lg rounded-tl-lg col-span-8">
                    <TableContainer className={"bg-white"}>
                        <Table>
                            <TableHeader>
                                <Row>
                                    <TableCell>Order No</TableCell>
                                    <TableCell>Table No</TableCell>
                                    <TableCell>Type</TableCell>
                                    <TableCell>Price</TableCell>
                                    <TableCell>Progress</TableCell>
                                    <TableCell>Status</TableCell>
                                </Row>
                            </TableHeader>
                            <TableBody>
                                {this.state.carts.map((cart, index) => (
                                    <TableRow cart={cart} key={index}
                                              setActiveRow={this.setActiveRow}
                                              active={this.state.activeRow === cart.group}
                                    />

                                ))}
                            </TableBody>
                        </Table>
                    </TableContainer>
                </div>
                {this.state.activeRow ? <ItemList group={this.state.activeRow}></ItemList> : null}
            </div>
        )
    }
}


if (document.getElementById("cart-details")) {
    const element = document.getElementById("cart-details");
    const props = Object.assign({}, element.dataset);
    ReactDOM.render(<CartDetails {...props} />, element);
}
