<?php

use App\Models\Cart;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        $carts = Cart::with('menu')
            ->withTrashed()
            ->get();

        Schema::table('carts', function (Blueprint $table) {
            $table->decimal('price', 14, 4)->after('menu_id');

        });

        foreach ($carts as $cart) {
            DB::table('carts')
                ->where('id', $cart->id)
                ->update([
                    'price' => $cart->menu->price
                ]);
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('carts', function (Blueprint $table) {
            //
        });
    }
};
