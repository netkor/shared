<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('branches', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('name');
            $table->string('address');
            $table->string('email');
            $table->string('phone');
            $table->string('logo');
            $table->string('pan_no');
            $table->string('vat_no');
            $table->string('status');
            $table->foreignUuid('user_id');
            $table->softDeletes();
            // tyo branch ko contact person
            $table->timestamps();
            $table->foreign('user_id')->references('id')->on('users');
        });
        Schema::create('user_branch', function (Blueprint $table) {
            $table->foreignUuid('user_id');
            $table->foreignUuid('branch_id');
             $table->foreign('user_id')->references('id')->on('users');
             $table->foreign('branch_id')->references('id')->on('branches');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('branches');
    }
};
