<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('stocks', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignUuid('inventory_id')->constrained();
            $table->foreignUuid('variant_id')->constrained();
            $table->foreignUuid('product_id')->constrained();
            $table->float('quantity');
            $table->date('expiry_date')->nullable();
            $table->unsignedMediumInteger('remaining_quantity')->default(1);
            $table->unsignedMediumInteger('alert_quantity')->default(1);
            $table->double('vat')->default(0);
            $table->double('discount')->default(0);
            $table->float('cost_price');
            $table->boolean('status')->default(true);
            $table->string('notes')->nullable();
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('stocks');
    }
};
