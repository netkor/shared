<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {

    public function up(): void
    {
        Schema::table('carts', function (Blueprint $table) {
            $table->foreignUuid('card_id')->nullable()->after('menu_id')->constrained('cards');
        });
    }

    public function down(): void
    {
        Schema::table('cart', function (Blueprint $table) {
            $table->dropColumn('card_id');
        });
    }
};
