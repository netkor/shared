<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('websites', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('title');
            $table->string('short_description');
            $table->string('long_description');
            $table->string('image');
            $table->string('logo');
            $table->string('address');
            $table->string('phone');
            $table->string('email');

            $table->string('slider1');
            $table->string('slider2');
            $table->string('slider3');

            $table->string('close_time');
            $table->string('open_time');
            $table->softDeletes();


            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('websites');
    }
};
