<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('item_transactions', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->nullableUuidMorphs('item');
            $table->string('ref_no')->nullable();
            $table->double('quantity', 30, 8)->nullable();
            $table->foreignUuid('unit_id')->nullable()->constrained('units');
            $table->string('source')->nullable();
            $table->string('status')->nullable();
            $table->text('note')->nullable();
            $table->double('stock', 30, 8)->nullable();
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('item_transactions');
    }
};
