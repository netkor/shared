<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('units', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('name');
            $table->string('symbol');
            $table->foreignUuid('parent_id')->nullable();
            $table->decimal('conversion_factor', 30, 8)->default(1);
            $table->decimal('conversion_ratio', 30, 8)->default(1);
            $table->unsignedSmallInteger('hierarchy')->default(0);
            $table->string('physical_quantity');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('units');
    }
};
