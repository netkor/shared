<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('ingredients', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignUuid('menu_id')->constrained();
            $table->foreignUuid('product_id')->constrained();
            $table->double('quantity', 20, 8)->default(0);
            $table->foreignUuid('unit_id')->constrained();
            $table->boolean('should_be_in_stock')->default(true);
            $table->boolean('should_reduce_stock')->default(true);
            $table->string('notes')->nullable();
            $table->timestamps();
        });


    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('ingredients');
    }
};
