<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class UnitSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('units')->insert([
            [
                'id' => "768ed271-de6b-4b02-9572-81afafd413d0",
                'name' => 'mg',
                'parent_id' => null,
                'conversion_factor' => null,
                'created_at' => '2021-09-27 21:42:00',
                'updated_at' => '2021-09-27 21:42:00',
            ],

            [
                'id' => "e44a2fad-8430-4414-a7bb-2e50c76218cb",
                'name' => 'g',
                'parent_id' => "768ed271-de6b-4b02-9572-81afafd413d0",
                'conversion_factor' => 1000,
                'created_at' => '2021-09-27 21:42:00',
                'updated_at' => '2021-09-27 21:42:00',
            ],
            [
                'id' => "b9a7a2a4-7fb5-4ce1-9465-a853d877ed42",
                'name' => 'kg',
                'parent_id' => "e44a2fad-8430-4414-a7bb-2e50c76218cb",
                'conversion_factor' => 1000,
                'created_at' => '2021-09-27 21:42:00',
                'updated_at' => '2021-09-27 21:42:00',
            ],
            [
                'id' => "8072a0cf-3416-4288-8f6a-8b3883b31a68",
                'name' => 'ml',
                'parent_id' => null,
                'conversion_factor' => null,
                'created_at' => '2021-09-27 21:42:00',
                'updated_at' => '2021-09-27 21:42:00',
            ],

            [
                'id' => "831b5d93-4c0c-418a-b152-977c0c313ca5",
                'name' => 'l',
                'parent_id' => "8072a0cf-3416-4288-8f6a-8b3883b31a68",
                'conversion_factor' => 1000,
                'created_at' => '2021-09-27 21:42:00',
                'updated_at' => '2021-09-27 21:42:00',
            ],

            [
                'id' => "5742687f-925c-447f-bec1-a9f2f278cc6b",
                'name' => 'piece',
                'parent_id' => null,
                'conversion_factor' => null,
                'created_at' => '2021-09-27 21:42:00',
                'updated_at' => '2021-09-27 21:42:00',
            ],
            [
                'id' => "eab5de91-e2d0-452f-bb2d-2d591aaf5022",
                'name' => 'dozen',
                'parent_id' => "5742687f-925c-447f-bec1-a9f2f278cc6b",
                'conversion_factor' => 12,
                'created_at' => '2021-09-27 21:42:00',
                'updated_at' => '2021-09-27 21:42:00',
            ],
            [
                'id' => "e2a1e1fa-a024-48a9-930f-56bc18513feb",
                'name' => 'bunch',
                'parent_id' => "5742687f-925c-447f-bec1-a9f2f278cc6b",
                'conversion_factor' => 12,
                'created_at' => '2021-09-27 21:42:00',
                'updated_at' => '2021-09-27 21:42:00',
            ],
            [
                'id' => "5d2fec7a-a461-4e9f-8616-5baf8a6c3a61",
                'name' => 'sack',
                'parent_id' => null,
                'conversion_factor' => null,
                'created_at' => '2021-09-27 21:42:00',
                'updated_at' => '2021-09-27 21:42:00',
            ],
            [
                'id' => "30a9abd0-5b52-4b87-b4b3-2044c641f13d",
                'name' => 'carte',
                'parent_id' => null,
                'conversion_factor' => null,
                'created_at' => '2021-09-27 21:42:00',
                'updated_at' => '2021-09-27 21:42:00',

            ],
            [
                'id' => "47547c36-f24e-46c3-92e7-f2efa9d90a1b",
                'name' => 'carton',
                'parent_id' => null,
                'conversion_factor' => null,
                'created_at' => '2021-09-27 21:42:00',
                'updated_at' => '2021-09-27 21:42:00',
            ]
        ]);
    }
}
