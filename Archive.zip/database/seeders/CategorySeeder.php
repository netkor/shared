<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('categories')->insert([
            [
                'id' => "7e6f4ea8-8f14-4e5d-b3f1-db5999f0834c",
                'name' => 'Beverages',
                'description' => 'Soft drinks, coffees, teas, beers, and ales',
                'created_at' => '2021-09-27 21:42:00',
                'updated_at' => '2021-09-27 21:42:00',
            ],

            [
                'id' => "5335c8fd-3fd3-4b46-a2aa-be21d3184491",
                'name' => 'Cuisine',
                'description' => 'Sweet and savory sauces, relishes, spreads, and seasonings',
                'created_at' => '2021-09-27 21:42:00',
                'updated_at' => '2021-09-27 21:42:00',
            ],

            [
                'id' => "7bd84839-309a-4689-b548-3186326c9cbf",
                'name' => 'Confections',
                'description' => 'Desserts, candies, and sweet breads',
                'created_at' => '2021-09-27 21:42:00',
                'updated_at' => '2021-09-27 21:42:00',
            ],


            [
                'id' => "81640bdd-b192-4564-a905-07d3715eedcb",
                'name' => 'Dairy Products',
                'description' => 'Cheeses',
                'created_at' => '2021-09-27 21:42:00',
                'updated_at' => '2021-09-27 21:42:00',
            ],
        ]);
    }
}
