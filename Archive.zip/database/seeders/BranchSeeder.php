<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class BranchSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('branches')->insert([
            [
                'id' => "e60d3643-8d21-4060-9db4-518ab57a300b",
                'name' => 'Urlabari Branch',
                'address' => 'School Dadha',
                'email' => 'urltheburgerhouse@gmail.com',
                'phone' => '9841414141',
                'logo' => 'logo.png',
                'pan_no' => '123456789',
                'vat_no' => '123456789',
                'status' => 'active',
                'user_id' => "502dee5c-393e-4fd8-ab8d-8122f6d5d380",
                'created_at' => now(),
                'updated_at' => now(),

            ]
            ]);
        DB::table('user_branch')->insert([
            [
                'branch_id' => "e60d3643-8d21-4060-9db4-518ab57a300b",
                'user_id' => "502dee5c-393e-4fd8-ab8d-8122f6d5d380",
            ]
        ]);
    }
}
