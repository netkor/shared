<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class ApplicationBootstrapSeeder extends Seeder
{

    public function run()
    {
        // Application Settings
        DB::table('settings')->insert([
            [
                'id' => '649b88e6-b3b0-4ec3-b9bb-56fe6477b67f',
                'key' => 'app_name',
                'value' => 'ATS-POS',
                'created_at' => '2022-11-05 10:25:55',
                'updated_at' => '2022-11-05 10:25:55',
            ],
            [
                'id' => '18e9cb7a-09ac-4e41-a4a7-770210ae6b2b',
                'key' => 'currency_symbol',
                'value' => 'Rs',
                'created_at' => "2022-11-05 10:25:55",
                'updated_at' => "2022-11-05 10:25:55",
            ],
            [
                'id' => '979fe5e3-038f-4125-8c72-a1b96a6ab9e2',
                'key' => 'points',
                'value' => '100',
                'created_at' => "2022-11-05 10:25:55",
                'updated_at' => "2022-11-05 10:25:55",
            ]
        ]);

        // Create users
        DB::table('users')->insert([
            [
                'id' => $users_admin = "2127c06d-cf57-44dd-a8f9-92da236c3bf9",
                'first_name' => 'Admin',
                'last_name' => 'Admin',
                'email' => 'admin@gmail.com',
                'phone' => '1234577890',
                'address' => 'Admin Address',
                'password' => Hash::make('12345678'),
                'api_token' => '7QtA6wAM9zfcu1hN6QkekoGyYpP19rJMMzLSNwElnBuPacybJN9WWND85CjZ',
                'email_verified_at' => "2022-11-05 10:25:55",
                'created_at' => "2022-11-05 10:25:55",
                'updated_at' => "2022-11-05 10:25:55",
            ],

            [
                'id' => $users_manager = "e3a2f951-5fc8-4098-a1fe-a4be7cba084a",
                'first_name' => 'Manager',
                'last_name' => 'Manager',
                'email' => 'manager1@gmail.com',
                'phone' => '12312313',
                'address' => 'Urlabari',
                'password' => Hash::make('12345678'),
                'api_token' => '7QtA6wAM9zfcu1hN6QkekoGyYpP19rJMMzLSNwElnBuPacybJN9WWND87CjZ',
                'email_verified_at' => "2022-11-05 10:25:55",
                'created_at' => "2022-11-05 10:25:55",
                'updated_at' => "2022-11-05 10:25:55",
            ],
            [
                'id' => $users_cashier = "5bd6dd27-71e0-4347-9ea6-51f422e99bfc",
                'first_name' => 'Cashier',
                'last_name' => 'Cashier',
                'email' => 'cashier@gmail.com',
                'phone' => '1234567990',
                'address' => 'Cashier Address',
                'password' => Hash::make('12345678'),
                'api_token' => '7QtA6wAM9zfcu1hN6QkekoGyYpP19rJMMzLSNwElnBuPacybJN9WWND81CjZ',
                'email_verified_at' => "2022-11-05 10:25:55",
                'created_at' => "2022-11-05 10:25:55",
                'updated_at' => "2022-11-05 10:25:55",
            ],
            [
                'id' => $users_waiter = "5bfa032b-bae9-482c-9eef-179f675e4190",
                'first_name' => 'Waiter',
                'last_name' => 'Waiter',
                'email' => 'waiter@gmail.com',
                'phone' => '1234561890',
                'address' => 'Waiter Address',
                'password' => Hash::make('12345678'),
                'api_token'=> '7QtA6wAM9zfcu1hN6QkekoGyYpP19rJMMzLSNwElnBuPacybJN9WWND84CjZ',
                'email_verified_at' => "2022-11-05 10:25:55",
                'created_at' => "2022-11-05 10:25:55",
                'updated_at' => "2022-11-05 10:25:55",
            ]
        ]);

        // Create Branches
        DB::table('branches')->insert([
            [
                'id' => $branches_urlabari = "7a7f0030-7d56-4ccd-ab4e-9630431c7dc3",
                'name' => 'Urlabari Branch',
                'address' => 'School Dadha',
                'email' => 'urltheburgerhouse@gmail.com',
                'phone' => '9841414141',
                'logo' => 'logo.png',
                'pan_no' => '123456789',
                'vat_no' => '123456789',
                'status' => 'active',
                'user_id' => $users_manager,
                'created_at' => "2022-11-05 10:25:55",
                'updated_at' => "2022-11-05 10:25:55",
            ],

        ]);

        // Create user_branch
        DB::table('user_branch')->insert([
            [
                'branch_id' => $branches_urlabari,
                'user_id' => $users_manager,
            ],
            [
                'branch_id' => $branches_urlabari,
                'user_id' => $users_cashier,
            ],
            [
                'branch_id' => $branches_urlabari,
                'user_id' => $users_waiter,
            ],

        ]);

        // Create Units
        DB::table('units')->insert([

            [
                'id' => "e44a2fad-8430-4414-a7bb-2e50c76218cb",
                'name' => 'Gram',
                'symbol' => 'g',
                'parent_id' => null,
                'conversion_factor' => 1,
                'conversion_ratio' => 1,
                'hierarchy' => 0,
                'physical_quantity' => 'mass',
                'created_at' => "2022-11-05 10:25:55",
                'updated_at' => "2022-11-05 10:25:55",
            ],
            [
                'id' => "b9a7a2a4-7fb5-4ce1-9465-a853d877ed42",
                'name' => 'Kilogram',
                'symbol' => 'kg',
                'parent_id' => "e44a2fad-8430-4414-a7bb-2e50c76218cb",
                'conversion_factor' => 1000,
                'conversion_ratio' => 1000 ,
                'hierarchy' => 2,
                'physical_quantity' => 'mass',
                'created_at' => "2022-11-05 10:25:55",
                'updated_at' => "2022-11-05 10:25:55",
            ],
            [
                'id' => "8072a0cf-3416-4288-8f6a-8b3883b31a68",
                'name' => 'Milliliter',
                'symbol' => 'ml',
                'parent_id' => null,
                'conversion_factor' => 1,
                'conversion_ratio' => 1,
                'hierarchy' => 0,
                'physical_quantity' => 'volume',
                'created_at' => "2022-11-05 10:25:55",
                'updated_at' => "2022-11-05 10:25:55",
            ],
            [
                'id' => "831b5d93-4c0c-418a-b152-977c0c313ca5",
                'name' => 'Liter',
                'symbol' => 'l',
                'parent_id' => "8072a0cf-3416-4288-8f6a-8b3883b31a68",
                'conversion_factor' => 1000,
                'conversion_ratio' => 1000,
                'hierarchy' => 1,
                'physical_quantity' => 'volume',
                'created_at' => "2022-11-05 10:25:55",
                'updated_at' => "2022-11-05 10:25:55",
            ],
            [
                'id' => "75d1195f-27c4-479d-b599-7111c91edb09",
                'name' => 'Gallon',
                'symbol' => 'gal',
                'parent_id' => "831b5d93-4c0c-418a-b152-977c0c313ca5",
                'conversion_factor' => 1000,
                'conversion_ratio' => 1000 * 3.785,
                'hierarchy' => 1,
                'physical_quantity' => 'volume',
                'created_at' => "2022-11-05 10:25:55",
                'updated_at' => "2022-11-05 10:25:55",
            ],
            [
                'id' => "5742687f-925c-447f-bec1-a9f2f278cc6b",
                'name' => 'Piece',
                'symbol' => 'pc',
                'parent_id' => null,
                'conversion_factor' => 1,
                'conversion_ratio' => 1,
                'hierarchy' => 0,
                'physical_quantity' => 'piece',
                'created_at' => "2022-11-05 10:25:55",
                'updated_at' => "2022-11-05 10:25:55",
            ]
        ]);

        // create rows
        DB::table('roles')->insert([
            [
                'id' => $super_admin = "8da8c130-afeb-4352-8ca8-2aa7fde85b98",
                'name' => 'super-admin',
                'guard_name' => 'web',
                'level' => 0,
                'created_at' => "2022-11-05 10:25:55",
                'updated_at' => "2022-11-05 10:25:55",
            ],
            [
                'id' => $admin = "dd965bc2-f6aa-4541-98da-676d4d87b5b8",
                'name' => 'admin',
                'guard_name' => 'web',
                'level' => 1,
                'created_at' => "2022-11-05 10:25:55",
                'updated_at' => "2022-11-05 10:25:55",
            ],
            [
                'id' => $manager = "da57b11d-eccd-41cc-9c58-807d07ad4712",
                'name' => 'manager',
                'guard_name' => 'web',
                'level' => 2,
                'created_at' => "2022-11-05 10:25:55",
                'updated_at' => "2022-11-05 10:25:55",
            ],
            [
                'id' => $cashier = "59eff46e-305b-405f-8566-93e36ca14310",
                'name' => 'cashier',
                'guard_name' => 'web',
                'level' => 3,
                'created_at' => "2022-11-05 10:25:55",
                'updated_at' => "2022-11-05 10:25:55",
            ],
            [
                'id' => $waiter = "ee028fba-f75c-4c24-a694-8cca2a55b6db",
                'name' => 'waiter',
                'guard_name' => 'web',
                'level' => 4,
                'created_at' => "2022-11-05 10:25:55",
                'updated_at' => "2022-11-05 10:25:55",
            ],
            [
                'id' => $kitchen = "cbae7230-d8ad-47bd-bc0c-cd7c835383c5",
                'name' => 'kitchen',
                'guard_name' => 'web',
                'level' => 4,
                'created_at' => "2022-11-05 10:25:55",
                'updated_at' => "2022-11-05 10:25:55",
            ],
            [
                'id' => $bar = "ca3f7d26-7604-4c70-a4b1-52868f9c8e34",
                'name' => 'bar',
                'guard_name' => 'web',
                'level' => 4,
                'created_at' => "2022-11-05 10:25:55",
                'updated_at' => "2022-11-05 10:25:55",
            ],

        ]);

        // Create Permissions
        DB::table('permissions')->insert([
            ['id' => $accounts_any = 'f224fa1f-674a-4a78-b640-542039c77453', 'name' => 'accounts.*', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $accounts_create = 'ad6f63eb-3b9d-4f56-8134-dd0abba43934', 'name' => 'accounts.create', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $accounts_delete = 'ef18ff94-45cd-41aa-b53f-00cb062b2e9f', 'name' => 'accounts.destroy', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $accounts_edit = 'e0d480fa-e581-44ee-9f5f-b89c859401c0', 'name' => 'accounts.edit', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $accounts_index = '3ca21f05-da2f-42c8-a952-09066ad25c3c', 'name' => 'accounts.index', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $accounts_show = '309cba71-db3d-4cdf-a0dd-ed267402aade', 'name' => 'accounts.show', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $accounts_update = '7afa28c6-3362-4709-9e95-cd9923650009', 'name' => 'accounts.update', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $branches_any = '88f62543-598f-446b-b684-9ebcb9f617a0', 'name' => 'branches.*', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $branches_create = '78380ad7-4230-4bd6-80bc-3d41c3aa2709', 'name' => 'branches.create', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $branches_delete = 'e0c89d5b-1a7a-45ff-8389-f9d94fa6ca30', 'name' => 'branches.destroy', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $branches_edit = 'e3c281ae-61cd-4ae3-9e9f-79a8fc5b8721', 'name' => 'branches.edit', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $branches_index = '76eaa46c-71a9-48ba-83ca-289ff90cbe0d', 'name' => 'branches.index', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $branches_show = 'c2f5949d-306e-4113-91e7-ec3d5ce5351e', 'name' => 'branches.show', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $branches_update = 'a0da9ea3-63e7-4a3a-a079-c08c5a7202c6', 'name' => 'branches.update', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $cards_any = '6ad54619-b17b-43e2-be1f-7b0f2c9f1ee9', 'name' => 'cards.*', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $cards_create = '7be1b625-e20c-4bee-928a-bb35663cf9bf', 'name' => 'cards.create', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $cards_delete = 'eda3ecd7-983a-4813-8d8c-3e3212c17754', 'name' => 'cards.destroy', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $cards_edit = '16cf4bd0-1f4e-4164-b78a-f425dc41b02e', 'name' => 'cards.edit', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $cards_index = 'e66fc4b8-a6ca-4810-92e1-d780d0f208a7', 'name' => 'cards.index', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $cards_show = 'f8d8109e-0f3e-4093-b653-1a12d556ce8e', 'name' => 'cards.show', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $cards_update = '769d9b7d-4cb3-4674-8d5b-f767176b594d', 'name' => 'cards.update', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $categories_any = '596a3a41-51b1-4def-947a-c8fe268a7b1e', 'name' => 'categories.*', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $categories_create = 'b4715744-e684-49da-a593-5aba79470e60', 'name' => 'categories.create', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $categories_delete = '3f3f9ff8-4963-4179-9c12-d33e05756946', 'name' => 'categories.destroy', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $categories_edit = '0161b465-4875-40b9-afd3-ce2f85f78470', 'name' => 'categories.edit', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $categories_index = '8b068976-7f39-4b2c-a274-8c13ed951ccf', 'name' => 'categories.index', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $categories_show = '5f72df52-296d-429c-89c5-5da1e4d1f437', 'name' => 'categories.show', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $categories_update = '9485a511-45f9-44e5-9941-9896aae1a78d', 'name' => 'categories.update', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $dashboard_any = '70ec7bb9-87bb-4e9e-988d-9f3a6b1eb449', 'name' => 'dashboard.*', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $dashboard_create = '2ab1e9cf-4dd8-4126-bc48-7121dacb3c5b', 'name' => 'dashboard.create', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $dashboard_delete = 'bab4b06c-629d-4c51-8cf0-5a31a25df82c', 'name' => 'dashboard.destroy', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $dashboard_edit = 'f29aaf5e-bbf2-4ecc-ab75-a02d34cc8bb7', 'name' => 'dashboard.edit', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $dashboard_index = '60d026f3-d98a-4e2d-8d06-fdc064af66b7', 'name' => 'dashboard.index', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $dashboard_show = 'ca108cca-186c-4e71-8624-5b6bace879a0', 'name' => 'dashboard.show', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $dashboard_update = '91afd484-82da-4352-bf31-69b3a71f722f', 'name' => 'dashboard.update', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $inventories_any = 'a028a38e-3340-419d-8a73-a50fbd7f26bd', 'name' => 'inventories.*', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $inventories_create = '97962abb-5243-4eaf-afd8-9550a17315f1', 'name' => 'inventories.create', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $inventories_delete = 'a9966de7-04e6-4662-9c63-21e4ff0cbccf', 'name' => 'inventories.destroy', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $inventories_edit = '8f49d593-f5d9-4d4b-b0e2-2bce58f68537', 'name' => 'inventories.edit', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $inventories_index = 'd100d334-15e2-43eb-8d04-63a6098dc70d', 'name' => 'inventories.index', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $inventories_show = 'a6c63ef6-fa03-4cc2-aec4-ec52fc98337a', 'name' => 'inventories.show', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $inventories_update = '594773ad-594e-431d-9cef-d013e861410e', 'name' => 'inventories.update', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $menus_any = '95cd3bcd-067d-4892-b949-b9114e7252bd', 'name' => 'menus.*', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $menus_create = '88d4a748-5447-4011-a1e2-a9bc370bf26a', 'name' => 'menus.create', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $menus_delete = '80d65f58-13c3-4728-bcf6-ff2682682d4a', 'name' => 'menus.destroy', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $menus_edit = 'c29f30ae-c861-4d91-a071-832417da6db3', 'name' => 'menus.edit', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $menus_index = 'ff185796-2a2b-4165-974e-4c263921804d', 'name' => 'menus.index', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $menus_show = '780528b8-cde4-4fc0-82e9-b0d2d787ad95', 'name' => 'menus.show', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $menus_update = '265ae7ff-9317-4626-807d-77cd29553b56', 'name' => 'menus.update', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $orders_any = '315c35ef-eb3d-4d55-a285-58fa43661037', 'name' => 'orders.*', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $orders_create = '271f10b3-7db2-4365-9c49-1c5c1bc7cd05', 'name' => 'orders.create', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $orders_delete = 'f02cfacf-44db-4591-a4c8-71e258bb6478', 'name' => 'orders.destroy', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $orders_edit = 'ab53cfdf-d75d-400f-8514-434c64b1ede3', 'name' => 'orders.edit', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $orders_index = '42dffc0b-f73a-4c60-8151-4052b92d83b7', 'name' => 'orders.index', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $orders_show = '018e0788-9e59-4710-9557-945c5a122d2d', 'name' => 'orders.show', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $orders_update = '92a71aa9-7c78-4295-bc7b-a15d8c0fd0e2', 'name' => 'orders.update', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $permissions_any = '9b19c8c5-990a-4719-be83-03ddd685771d', 'name' => 'permissions.*', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $permissions_create = '602accb1-8afa-435d-b467-8892963fb750', 'name' => 'permissions.create', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $permissions_delete = '3de0dc50-a0c7-4228-9d30-94207373b54d', 'name' => 'permissions.destroy', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $permissions_edit = '49b6d9c7-a442-44ae-8fee-ef5d96b8b08e', 'name' => 'permissions.edit', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $permissions_index = '2ecf8507-b650-434e-a209-1a5a2d0d3d2c', 'name' => 'permissions.index', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $permissions_show = 'd21a5b99-b876-4d45-8247-7b539fbf7f58', 'name' => 'permissions.show', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $permissions_update = '1272ffa4-4251-4e30-98da-ae849a7d7f04', 'name' => 'permissions.update', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $products_any = 'be111669-5c6d-4fda-966b-88a751700ec3', 'name' => 'products.*', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $products_create = 'badf1aee-889b-44ff-bd18-cf6e38aad718', 'name' => 'products.create', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $products_delete = 'f57b1523-b31c-4376-af01-81a178ec79ec', 'name' => 'products.destroy', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $products_edit = '9be63ec6-fb10-442e-a894-4f8691b1eb83', 'name' => 'products.edit', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $products_index = 'ed5ea28d-03ac-4285-a739-6b48a866b32a', 'name' => 'products.index', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $products_show = 'c990bd55-cde8-4d42-9991-dd230f4ff96c', 'name' => 'products.show', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $products_update = '463b101a-8322-4a19-8939-d2cb8493c48e', 'name' => 'products.update', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $reports_any = '43c87221-be76-4730-958b-30e8c941b00b', 'name' => 'reports.*', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $reports_create = 'b1e78f16-f566-4bb3-b31d-a785c08310c6', 'name' => 'reports.create', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $reports_delete = '0f44b2be-cde8-4c2e-8cfe-4f9e4e2756a7', 'name' => 'reports.destroy', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $reports_edit = '7f6b7914-d2c3-4ea9-b930-3d40d40cbeaa', 'name' => 'reports.edit', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $reports_index = '12186328-cf76-4141-b21f-ac89a481b054', 'name' => 'reports.index', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $reports_sales_any = '38fdcc8b-2871-4777-a7bf-c527127ccae4', 'name' => 'reports.sales.*', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $reports_sales_create = 'a2263c16-7796-483f-9af0-61ce55d6ca19', 'name' => 'reports.sales.create', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $reports_sales_delete = '795bcb97-b442-4281-bc2b-69fc236308c0', 'name' => 'reports.sales.destroy', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $reports_sales_edit = 'f11b7b09-988c-4b39-bef7-0a4b0312e12f', 'name' => 'reports.sales.edit', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $reports_sales_index = '939fb923-ac6a-4403-8be9-f63558f1520a', 'name' => 'reports.sales.index', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $reports_sales_show = 'd03105eb-8929-4cbc-9f85-8e5bfe33db78', 'name' => 'reports.sales.show', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $reports_sales_update = '2988929d-9ef7-4859-9978-ee02a9741461', 'name' => 'reports.sales.update', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $reports_show = 'b42275bf-8ca7-4005-a68b-73b161d7e8fe', 'name' => 'reports.show', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $reports_update = '3912a5eb-905a-499c-ae35-b542413fe185', 'name' => 'reports.update', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $roles_any = '532355f4-355b-4bc6-91b3-e7dc46c64f36', 'name' => 'roles.*', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $roles_create = '50ff350a-1861-4f6d-9322-864fb1e37fb7', 'name' => 'roles.create', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $roles_delete = 'bcb72526-de56-4af3-b419-28c964209a6e', 'name' => 'roles.destroy', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $roles_edit = '92c6d6c5-f1ab-4ddf-8d95-6b158149a619', 'name' => 'roles.edit', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $roles_index = '5f3e101a-125c-4614-b043-9024f95ac998', 'name' => 'roles.index', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $roles_show = '477704c0-cce5-4688-bb2b-ed60899bf46a', 'name' => 'roles.show', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $roles_update = '0ab04884-1b9d-4916-b34b-e09fa633745a', 'name' => 'roles.update', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $settings_any = 'fb22c933-05da-4e53-a4d9-4df3cbdee9ba', 'name' => 'settings.*', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $settings_create = 'ec1d9d59-38ef-47ed-a610-15e91d7f75c3', 'name' => 'settings.create', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $settings_delete = '806a2148-2a52-4278-85b4-8e82af6b8bc4', 'name' => 'settings.destroy', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $settings_edit = '8101a9f7-800e-4cba-9483-b1f219eaa3f2', 'name' => 'settings.edit', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $settings_index = '516707d6-0526-40c6-a0dd-c3370beae9a7', 'name' => 'settings.index', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $settings_show = '3f024398-1c1e-4821-8829-a4a0d985813b', 'name' => 'settings.show', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $settings_update = '628ec445-852a-4858-b841-96a259edd89a', 'name' => 'settings.update', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $staffs_any = '4651c6f7-aba3-4b61-8d21-39c6672e3dbc', 'name' => 'staffs.*', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $staffs_create = 'd630688b-35e6-47ea-9aae-e0a8a3519d26', 'name' => 'staffs.create', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $staffs_delete = 'aa14f3d9-3f3e-4df3-91ca-e6ce31b4d33b', 'name' => 'staffs.destroy', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $staffs_edit = '588c59f4-b9b7-44da-8170-50e98dd73a3a', 'name' => 'staffs.edit', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $staffs_index = 'e7a5e3d4-1e00-4823-ae03-01e3f0f3cab7', 'name' => 'staffs.index', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $staffs_show = 'e27c2d1c-4473-4680-84e0-7270f844a783', 'name' => 'staffs.show', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $staffs_update = 'aa932812-9b86-452f-8cfb-56b4961829a4', 'name' => 'staffs.update', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $tables_any = '14525dc1-11f0-4184-af49-cfbe2c934068', 'name' => 'tables.*', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $tables_create = 'b8ae2671-4212-4e0a-a9ea-cb1a48fe9100', 'name' => 'tables.create', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $tables_delete = '241181e8-a06e-4875-8b65-811b3e6f4a0c', 'name' => 'tables.destroy', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $tables_edit = '2cf65b75-0c91-437f-a7d5-efdbc9668639', 'name' => 'tables.edit', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $tables_index = '2db44abd-80ee-4f9c-9b12-e72bce0aa183', 'name' => 'tables.index', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $tables_show = 'afc323c4-fa34-4144-8f42-80bb82ffc2f0', 'name' => 'tables.show', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $tables_update = '513b3886-0d4e-4d92-9253-70978fa12851', 'name' => 'tables.update', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $transactions_any = 'cf7bbc44-c09b-4751-9a59-53b3db332572', 'name' => 'transactions.*', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $transactions_create = '5f585c7e-7b58-4d24-8fe4-ae01e6b07658', 'name' => 'transactions.create', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $transactions_delete = 'e0dc4589-f5da-4d70-803a-e84eeb5921e4', 'name' => 'transactions.destroy', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $transactions_edit = '1dc38c06-4205-4ae8-93f0-f9b214b422b1', 'name' => 'transactions.edit', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $transactions_index = 'e736c151-2218-4b76-96c6-5119cfc57f31', 'name' => 'transactions.index', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $transactions_show = '6a11064c-e4ec-49a7-93f5-c6707b467e97', 'name' => 'transactions.show', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $transactions_update = 'f2344b1b-d381-4e43-a6ca-c488173bec4d', 'name' => 'transactions.update', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $types_any = 'c34cd909-a1c9-439f-af00-22bb5c8a4aee', 'name' => 'types.*', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $types_create = '3d4309dc-3d89-4528-8ebb-d67dfa64bf76', 'name' => 'types.create', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $types_delete = '35b1871b-ae9f-491c-a40f-b21c1a624a27', 'name' => 'types.destroy', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $types_edit = '6ec1c876-e0fe-4731-91a6-4de527f52a50', 'name' => 'types.edit', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $types_index = '21e94745-cf47-48c6-bf4b-ecbc006269cb', 'name' => 'types.index', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $types_show = '6cc03e0c-5a86-4b42-8d62-8809e1b4235b', 'name' => 'types.show', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $types_update = 'a3b49534-9568-4fd0-a14b-bb836b695db9', 'name' => 'types.update', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $units_any = 'acb07343-e3d7-45aa-97be-9e258c3dccec', 'name' => 'units.*', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $units_create = '77f2dd35-9f01-46c0-bb6c-63bf1430222b', 'name' => 'units.create', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $units_delete = '8d3be21b-954e-42ed-9b58-43e46758658f', 'name' => 'units.destroy', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $units_edit = '4fa120ab-6657-4053-b521-2e1cc0fd0528', 'name' => 'units.edit', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $units_index = 'ae0333d1-870b-4d4f-b087-96fad96ab20d', 'name' => 'units.index', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $units_show = '66bc1cb9-da51-4e70-abfe-331c0528bd2f', 'name' => 'units.show', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $units_update = '7f4133fa-187e-4f42-a020-73c7c28b43b4', 'name' => 'units.update', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $users_any = '29b894e2-1026-49d7-b7fb-afa4c88a78be', 'name' => 'users.*', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $users_create = 'aa71a429-9c3a-4ce8-bebb-caf7accdf082', 'name' => 'users.create', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $users_delete = '393d8c03-4a62-492d-8220-4eba4fb1362f', 'name' => 'users.destroy', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $users_edit = '715cd350-92bd-42d0-a1bb-1595c0fe4913', 'name' => 'users.edit', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $users_index = '81c06af3-7600-482c-9311-81149d43e33d', 'name' => 'users.index', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $users_show = 'fc992e28-a082-4131-bb9f-169570dddc62', 'name' => 'users.show', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $users_update = 'd3c2eaca-ef8b-4b71-9d92-dfd11495f485', 'name' => 'users.update', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $vendors_any = '52e0228f-987f-4d7d-b95a-d77f6729afed', 'name' => 'vendors.*', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $vendors_create = '39461c54-4f13-406d-8a74-fbffd5292a06', 'name' => 'vendors.create', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $vendors_delete = 'ba6d2c1c-1f33-4b13-9281-2d3b9aa529dc', 'name' => 'vendors.destroy', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $vendors_edit = '94ac04cc-8f4b-43cf-917c-320b1e8d6d9d', 'name' => 'vendors.edit', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $vendors_index = '06c0b109-077a-4ac3-ae65-12ea9df7c4c1', 'name' => 'vendors.index', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $vendors_show = '535f1c17-0ced-4751-abd7-179f426807e8', 'name' => 'vendors.show', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $vendors_update = '379c5221-049c-468b-be89-4c96b1e7bce4', 'name' => 'vendors.update', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $websites_any = '17c7e111-fd91-4f66-b2ae-e33d7c758cb9', 'name' => 'websites.*', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $websites_create = '896a1766-f0dd-495e-bfcb-10fac677a206', 'name' => 'websites.create', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $websites_delete = '0ce855d8-5eb0-4eb3-aa82-808f28ae1dd8', 'name' => 'websites.destroy', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $websites_edit = 'deedcac0-d181-4ff7-a9a3-5542b4578700', 'name' => 'websites.edit', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $websites_index = '8124a670-d63f-43e2-bdf5-dbebc5d8fc6f', 'name' => 'websites.index', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $websites_show = 'c7e8c011-8b50-4ec6-8a80-41827add5aee', 'name' => 'websites.show', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
            ['id' => $websites_update = 'baf4c50b-0f4d-4ab6-aa9a-f1dd50d908cf', 'name' => 'websites.update', 'guard_name' => 'web', 'created_at' => '2021-09-27 21:42:00', 'updated_at' => '2021-09-27 21:42:00',],
        ]);

        // Create all role for users
        DB::table('model_has_roles')->insert([
            [
                'role_id' => $super_admin,
                'model_type' => 'user',
                'model_id' => $users_admin,
            ],
            [
                'role_id' => $admin,
                'model_type' => 'user',
                'model_id' => $users_admin,
            ],
            [
                'role_id' => $waiter,
                'model_type' => 'user',
                'model_id' => $users_manager,
            ],
            [
                'role_id' => $cashier,
                'model_type' => 'user',
                'model_id' => $users_cashier,
            ]
        ]);

        // Create all permission for users
        DB::table('role_has_permissions')->insert([
            // create all permission for super admin
            [
                'permission_id' => $users_index,
                'role_id' => $super_admin,
            ],
            [
                'permission_id' => $users_create,
                'role_id' => $super_admin,
            ],
            [
                'permission_id' => $users_edit,
                'role_id' => $super_admin,
            ],
            [
                'permission_id' => $users_delete,
                'role_id' => $super_admin,
            ],
            [
                'permission_id' => $users_show,
                'role_id' => $super_admin,
            ],
            [
                'permission_id' => $users_update,
                'role_id' => $super_admin,
            ],
            [
                'permission_id' => $roles_index,
                'role_id' => $super_admin,
            ],
            [
                'permission_id' => $roles_create,
                'role_id' => $super_admin,
            ],
            [
                'permission_id' => $roles_edit,
                'role_id' => $super_admin,
            ],
            [
                'permission_id' => $roles_delete,
                'role_id' => $super_admin,
            ],
            [
                'permission_id' => $roles_show,
                'role_id' => $super_admin,
            ],
            [
                'permission_id' => $roles_update,
                'role_id' => $super_admin,
            ],
            [
                'permission_id' => $permissions_index,
                'role_id' => $super_admin,
            ],
            [
                'permission_id' => $permissions_create,
                'role_id' => $super_admin,
            ],
            [
                'permission_id' => $permissions_edit,
                'role_id' => $super_admin,
            ],
            [
                'permission_id' => $permissions_delete,
                'role_id' => $super_admin,
            ],
            [
                'permission_id' => $permissions_show,
                'role_id' => $super_admin,
            ],
            [
                'permission_id' => $permissions_update,
                'role_id' => $super_admin,
            ],
            // create all permission for admin
            [
                'permission_id' => $users_index,
                'role_id' => $admin,
            ],
            [
                'permission_id' => $users_create,
                'role_id' => $admin,
            ],
            [
                'permission_id' => $users_edit,
                'role_id' => $admin,
            ],
            [
                'permission_id' => $users_delete,
                'role_id' => $admin,
            ],
            [
                'permission_id' => $users_show,
                'role_id' => $admin,
            ],
            [
                'permission_id' => $users_update,
                'role_id' => $admin,
            ],
            [
                'permission_id' => $roles_index,
                'role_id' => $admin,
            ],
            [
                'permission_id' => $roles_create,
                'role_id' => $admin,
            ],
            [
                'permission_id' => $roles_edit,
                'role_id' => $admin,
            ],
            [
                'permission_id' => $roles_delete,
                'role_id' => $admin,
            ],
            [
                'permission_id' => $roles_show,
                'role_id' => $admin,
            ],
            [
                'permission_id' => $roles_update,
                'role_id' => $admin,
            ],
            [
                'permission_id' => $permissions_index,
                'role_id' => $admin,
            ],
            [
                'permission_id' => $permissions_create,
                'role_id' => $admin,
            ],
            [
                'permission_id' => $permissions_edit,
                'role_id' => $admin,
            ],
            [
                'permission_id' => $permissions_delete,
                'role_id' => $admin,
            ],
            [
                'permission_id' => $permissions_show,
                'role_id' => $admin,
            ],
            [
                'permission_id' => $permissions_update,
                'role_id' => $admin,
            ],
            // create all permission for manager
            [
                'permission_id' => $users_index,
                'role_id' => $manager,
            ],
            [
                'permission_id' => $users_create,
                'role_id' => $manager,
            ],
            [
                'permission_id' => $users_edit,
                'role_id' => $manager,
            ],
            [
                'permission_id' => $users_delete,
                'role_id' => $manager,
            ],
            [
                'permission_id' => $users_show,
                'role_id' => $manager,
            ],
            [
                'permission_id' => $users_update,
                'role_id' => $manager,
            ],
            [
                'permission_id' => $roles_index,
                'role_id' => $manager,
            ],
            [
                'permission_id' => $roles_create,
                'role_id' => $manager,
            ],
            [
                'permission_id' => $roles_edit,
                'role_id' => $manager,
            ],
            [
                'permission_id' => $roles_delete,
                'role_id' => $manager,
            ],
            [
                'permission_id' => $roles_show,
                'role_id' => $manager,
            ],
            [
                'permission_id' => $roles_update,
                'role_id' => $manager,
            ],
            [
                'permission_id' => $permissions_index,
                'role_id' => $manager,
            ],
            [
                'permission_id' => $permissions_create,
                'role_id' => $manager,
            ],
            [
                'permission_id' => $permissions_edit,
                'role_id' => $manager,
            ],
            [
                'permission_id' => $permissions_delete,
                'role_id' => $manager,
            ],
            [
                'permission_id' => $permissions_show,
                'role_id' => $manager,
            ],
            [
                'permission_id' => $permissions_update,
                'role_id' => $manager,
            ],
//            [
//                'permission_id' => $pos,
//                'role_id' => $manager,
//            ],
//            [
//                'permission_id' => $pos_create,
//                'role_id' => $manager,
//            ],
//            [
//                'permission_id' => $pos_edit,
//                'role_id' => $manager,
//            ],
//            [
//                'permission_id' => $pos_delete,
//                'role_id' => $manager,
//            ],
//            [
//                'permission_id' => $pos_show,
//                'role_id' => $manager,
//            ],
//            [
//                'permission_id' => $pos_update,
//                'role_id' => $manager,
//            ],
//            [
//                'permission_id' => $pos_index,
//                'role_id' => $manager,
//            ],
//            [
//                'permission_id' => $pos_print,
//                'role_id' => $manager,
//            ],
//            [
//                'permission_id' => $pos_print_invoice,
//                'role_id' => $manager,
//            ],
//            [
//                'permission_id' => $pos,
//                'role_id' => $waiter,
//            ],
//            [
//                'permission_id' => $pos_print_receipt,
//                'role_id' => $waiter,
//            ],
        ]);

        DB::table('tables')->insert([
            [
                'id' => "831b5d93-4c0c-418a-b152-977c0c313ca5",
                'name' => 'Table 1',
                'description' => 'Table 1',
                'status' => 1,
            ],
            [
                'id' => "831b5d93-4c0c-418a-b152-977c0c313ca2",

                'name' => 'Table 2',
                'description' => 'Table 2',
                'status' => 1,
            ],

        ]);
        DB::table('categories')->insert([
            [
                'id' => "831b5d93-4c0c-418a-b152-977c0c313ca5",
                'name' => 'Appetizer',
                'slug' => 'appetizer'
            ],
            [
                'id' => "831b5d93-4c0c-418a-b152-977c0c313ca8",
                'name' => 'Beverage ',
                'slug' => 'beverage'
            ],

        ]);

        DB::table('types')->insert([
            [
                'id' => "831b5d93-4c0c-418a-b152-977c0c313ca2",
                'name' => 'Bar',
                'slug' => 'bar',
            ],
            [
                'id' => "831b5d93-4c0c-418a-b152-977c0c313ca0",
                'name' => 'Kitchen',
                'slug' => 'kitchen',

            ],

        ]);


    }
}
