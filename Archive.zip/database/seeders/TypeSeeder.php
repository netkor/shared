<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class TypeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('types')->insert([
            [
                'id' => "68be7148-5c65-4ee8-8c54-ac9099921944",
                'name' => 'Kitchen',
                'created_at' => '2021-09-27 21:42:00',
                'updated_at' => '2021-09-27 21:42:00',
            ],

            [
                'id' => "6911252c-feaa-4fce-b6b6-6ea33819d27c",
                'name' => 'Bar',
                'created_at' => '2021-09-27 21:42:00',
                'updated_at' => '2021-09-27 21:42:00',
            ],

            [
                'id' => "f163e4d3-2697-41b3-970a-7c13ada3858d",
                'name' => 'Store',
                'created_at' => '2021-09-27 21:42:00',
                'updated_at' => '2021-09-27 21:42:00',
            ]
        ]);
    }
}
