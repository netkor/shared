<?php

namespace Database\Seeders;

use App\Models\Setting;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class SettingsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

        DB::table('settings')->insert([
                [
                    'id' => "59b07707-6a63-4786-aa94-cd94724f8007",
                    'key' => 'app_name',
                    'value' => 'ATS-POS'
                ],
                [
                    'id' => "7ba9b3e4-aecc-45ee-bc38-2813f1c3ce99",
                    'key' => 'currency_symbol',
                    'value' => 'Rs'
                ],
                [
                    'id' => "7ba9b3e4-aecc-45ee-bc38-2813f1c3ce99",
                    'key' => 'point_ratio',
                    'value' => '0.1'
                ],
            ]
        );


    }
}
