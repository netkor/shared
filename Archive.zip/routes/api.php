<?php

use App\Http\Controllers\AccountController;
use App\Http\Controllers\Api\AccountsAPIController;
use App\Http\Controllers\Api\CardAPIController;
use App\Http\Controllers\Api\CardsAPIController;
use App\Http\Controllers\Api\CartAPIController;
use App\Http\Controllers\Api\CartDetailsAPIController;
use App\Http\Controllers\Api\ItemAPIController;
use App\Http\Controllers\Api\MenuAPIController;
use App\Http\Controllers\Api\SettingsAPIController;
use App\Http\Controllers\Api\TableAPIController;
use App\Http\Controllers\Api\UserAPIController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\PermissionController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/


Route::post('login', [UserAPIController::class, 'login']);
//get settings
Route::get('settings', [SettingsAPIController::class, '__invoke']);

Route::middleware('auth:api')->group(function () {
    Route::get('profile', [UserAPIController::class, 'profile']);
    Route::get('/cards', [CardsAPIController::class, '__invoke']);
    Route::post('/cards', [CardsAPIController::class, 'store']);
    Route::get('/accounts', [AccountsAPIController::class, '__invoke']);
    Route::post('/card/{card:number}', [AccountController::class, 'balance']);

    Route::post('update-device-token', [UserAPIController::class, 'updateDeviceToken']);
    Route::get('/menus', MenuAPIController::class)->name('api.menus.index');
    Route::get('/tables', TableAPIController::class)->name('api.tables.index');
    Route::get('/items', ItemAPIController::class)->name('api.items.index');

    Route::get('/card', CardAPIController::class)->name('api.card.index');

    Route::get('/carts', [CartAPIController::class, 'index'])->name('api.carts.index');
    Route::post('/cart', [CartController::class, 'store'])->name('api.cart.store');
    Route::delete('/carts', [CartAPIController::class, 'empty'])->name('api.carts.empty');
    Route::delete('/carts-item', [CartAPIController::class, 'delete'])->name('api.carts.delete');
    Route::post('/cart/change-qty', [CartController::class, 'changeQty']);


//cart hold
    Route::post('/carts-hold', [CartAPIController::class, 'holdItems'])->name('api.carts.holdItems');
    Route::get('/carts-swap', [CartAPIController::class, 'swap'])->name('api.carts.swap');
    Route::get('/order-details', [CartAPIController::class, 'viewOrders'])->name('api.cart.viewOrders');
    Route::get('/user', function (Request $request) {
        return $request->user();
    });
    Route::get('/cart-details/{group}', CartDetailsAPIController::class)->name('api.cart-details.index');
    Route::get('/cart-details', [CartDetailsAPIController::class, 'allOrder'])->name('api.cart-details.allOrder');
    Route::post('/cart-status', [CartDetailsAPIController::class, 'changeStatus'])->name('api.cart-details.changeStatus');


});

Route::prefix('/permissions')->group(function () {
    Route::post('/give-permission-to-role', [PermissionController::class, 'givePermissionToRole']);
    Route::post('/revoke-permission-to-role', [PermissionController::class, 'revokePermissionToRole']);
});

//
//Route::group(['middleware' => ['permission:permissions.index']], function () {
//    Route::get('permissions/role-has-permission', 'PermissionController@roleHasPermission');
//    Route::get('permissions/refresh-permissions', 'PermissionController@refreshPermissions');
//});


