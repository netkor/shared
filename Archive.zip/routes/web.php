<?php

use App\Http\Controllers\AccountController;
use App\Http\Controllers\ActivityController;
use App\Http\Controllers\BranchController;
use App\Http\Controllers\CardController;
use App\Http\Controllers\CardTransactionController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\CartDetailsController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\ImageResizeController;
use App\Http\Controllers\IngredientController;
use App\Http\Controllers\InventoryController;
use App\Http\Controllers\MenuController;
use App\Http\Controllers\MenuIngredientController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\PDFController;
use App\Http\Controllers\PermissionController;
use App\Http\Controllers\PrintController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\SattleAmountController;
use App\Http\Controllers\SettingController;
use App\Http\Controllers\StoreController;
use App\Http\Controllers\TableController;
use App\Http\Controllers\TransactionController;
use App\Http\Controllers\TypeController;
use App\Http\Controllers\UnitController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\VariantController;
use App\Http\Controllers\VendorController;
use App\Http\Controllers\WebsiteController;
use App\Models\User;
use App\Notifications\NewOrderCreatedNotification;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;


//Route::get('/', [PrintController::class, 'print']);


Route::get('/', function () {


    // http
//    $http = Http::withHeaders(['Authorization' => 'key=AAAATiG9N9c:APA91bECsYaddrkQE9eArQFxUDFpZ8q-RcujrqK_Ut1FHcEgeoOwGVYydOXnzgv8m8xmcF3SJIjC-cDY3T19jzynFHYjDo1jW4X--dEzOr-_-5H63QVDqUpOS8f02LJpf34JDe3RXdod'])
//        ->post('https://fcm.googleapis.com/fcm/send',
//            [
//                "registration_ids" => ["f-rQWHAmR3OGXfhjNLoU9u:APA91bEXvKMjRtIMSD-8sk0hsw1haTGl6mAOTbK1ifIQOriRz9xFptJaAyByP7WhJb38dPN3L86UzdQU6cMnQ11fCefGqrQuRBJSwod0REGvNBkShi0ijHyWUrJlc5T6rADuupSEgsMf"],
//                "notification" => [
//                    "body" => "Hii",
//                    "title" => "Hello From Laravel",
//                    "android_channel_id" => "pos",
//                    "image" =>
//                        "https://cdn2.vectorstock.com/i/1000x1000/23/91/small-size-emoticon-vector-9852391.jpg",
//                    "sound" => true
//                ]
//            ]
//        );
//    dd($http->body());


    $user = User::first();
    $user->notify(new NewOrderCreatedNotification());
    return $user;


//    $from = Unit::where('name', 'kilogram')->first();
//    $to = Unit::where('name', 'miligram')->first();
//
//    $converter = new UnitConverter(fromUnit: $from, toUnit: $to);
//
//    $result = $converter->convert(1);
//    dd($result);


//
//    broadcast(new MessageSent(User::first()->toArray()));
//
////
////    // list all the printer connected in device
////    $printer = new PrintController();
////
////
//////    $anonymous = new UnitConversionDTO(Unit::find('b9a7a2a4-7fb5-4ce1-9465-a853d877ed43'));
//////
//////    $unit2 = app()->make(Pipeline::class)->send($anonymous)->through([
//////        TraverseChildPipeline::class,
//////        TraverseParentPipeline::class
//////    ])->thenReturn();
//////
//////
//////    dd($unit2);
////
////    return redirect('/admin');
});

Auth::routes();

Route::get('image/{model}/{id}/{width}/{height}', ImageResizeController::class)->name('image.resize');


//Route::get('/', [WebsiteController::class, 'show'])->name('website.show');
Route::get('/', [HomeController::class, 'index'])->name('home');

Route::prefix('admin')->middleware('auth')->group(function () {
    Route::get('/', [HomeController::class, 'index'])->name('home');
    Route::get('/settings', [SettingController::class, 'index'])->name('settings.index');
    Route::post('/settings', [SettingController::class, 'store'])->name('settings.store');

    Route::get('/website', [WebsiteController::class, 'index'])->name('website.index');
    Route::get('/website-create', [WebsiteController::class, 'create'])->name('website.create');
    Route::get('/website-edit/{id}', [WebsiteController::class, 'edit'])->name('website.edit');
    Route::put('/website-update/{id}', [WebsiteController::class, 'update'])->name('website.update');
    Route::post('/website-store', [WebsiteController::class, 'store'])->name('website.store');


    Route::resource('categories', CategoryController::class);
    Route::resource('types', TypeController::class);
    Route::resource('units', UnitController::class);
    Route::resource('users', UserController::class);
    Route::resource('branches', BranchController::class);
    Route::resource('customers', CustomerController::class);
    Route::resource('vendors', VendorController::class);
    Route::resource('menus', MenuController::class);
    Route::resource('ingredients', IngredientController::class);
    Route::resource('accounts', AccountController::class);
    Route::resource('transactions', TransactionController::class);
    Route::get('permissions', [PermissionController::class, 'index'])->name('permissions.index');
    Route::post('permissions', [PermissionController::class, 'store'])->name('permissions.store');

    //route for daily sales report
    Route::get('dailysalesreport', [OrderController::class, 'dailysalesreport'])->name('dailysalesreport.index');


    Route::get('/pos-menus', [MenuController::class, 'posMenu'])->name('posMenus.index');
    Route::get('/warningsExpire', [InventoryController::class, 'getExpireProduct'])->name('warnings.product-expire');
    Route::get('/warningsAboutToExpire', [InventoryController::class, 'getAboutToExpireProduct'])->name('warnings.about-to-expire');
    Route::get('/warningsProduct', [InventoryController::class, 'getAlertProduct'])->name('warnings.productWarning');
    Route::get('/roles', [PermissionController::class, 'getRoles'])->name('permissions.getR');


    Route::middleware('tenant')->group(function () {
        Route::resource('inventory', InventoryController::class);
        Route::resource('tables', TableController::class);
        Route::resource('cards', CardController::class);
        Route::post('/cards/{card}/transactions', CardTransactionController::class)->name('cards.transactions.store');

        Route::get('{product}/variants', [VariantController::class, 'index'])->name('variants.index');
        Route::get('{product}/variants/create', [VariantController::class, 'create'])->name('variants.create');
        Route::post('{product}/variants', [VariantController::class, 'store'])->name('variants.store');
        Route::get('{product}/variants/{variant}', [VariantController::class, 'show'])->name('variants.show');
        Route::get('{product}/variants/{variant}/edit', [VariantController::class, 'edit'])->name('variants.edit');
        Route::put('{product}/variants/{variant}', [VariantController::class, 'update'])->name('variants.update');
        Route::delete('{product}/variants/{variant}', [VariantController::class, 'destroy'])->name('variants.destroy');

//        Route::resource('variants', VariantController::class);


        Route::resource('products', ProductController::class);
        Route::get('/products/{product}/adjustments', [ProductController::class, 'adjustments'])->name('products.adjustments');

        Route::post('product/price/{product}', [ProductController::class, 'updatePrice'])->name('product.price.update');
        Route::resource('inventories', InventoryController::class);

    });

    Route::resource('activity-logs', ActivityController::class);
    Route::get('subject-activity-logs/{subject}/{id}', [ActivityController::class, 'subjectActivity'])->name('subject-activity-logs');


    Route::resource('orders', OrderController::class);
    Route::get('print-receipt/{order}', [OrderController::class, 'printReceipt'])->name('orders.print-receipt');
    Route::get('cart-details', CartDetailsController::class)->name('cart.details');
    Route::post('sattle-amount', SattleAmountController::class)->name('sattle-amount');


    Route::get('/store', [StoreController::class, 'index'])->name('store.index');
    Route::get('/store/{inventory}/create', [StoreController::class, 'create'])->name('store.create');
    Route::get('/cart', [CartController::class, 'index'])->name('cart.index');
    Route::post('/cart', [CartController::class, 'store'])->name('cart.store');
    Route::get('/checkBalance', [CardController::class, 'checkBalance'])->name('cards.checkBalance');


    Route::get('/cart/{id}', [CartController::class, 'show'])->name('cart.show');
    Route::get('inventory/create', [InventoryController::class, 'create'])->name('inventory.create');
    Route::get('inventories/{inventory}/approve', [InventoryController::class, 'verify'])->name('inventories.approve');
    Route::put('/inventory-products/{id}', [InventoryController::class, 'update'])->name('inventory.update');
    Route::post('/store-product', [StoreController::class, 'store'])->name('store.store');


    Route::put('/cart/swap-table', [CartController::class, 'swap']);
    Route::put('/cart/hold-table', [CartController::class, 'hold']);
    Route::post('/cart/change-qty', [CartController::class, 'changeQty']);
    Route::delete('/cart/delete', [CartController::class, 'delete']);
    Route::delete('/cart/empty', [CartController::class, 'empty']);

    Route::get('/menu/{menu}/ingredients', [MenuIngredientController::class, 'index'])->name('reciepeIngredient.index');
    Route::post('/menu/{menu}/ingredients', [MenuIngredientController::class, 'store'])->name('reciepeIngredient.store');

});
Route::get('/printPDF', [PDFController::class, 'generatePDF']);
Route::get('/print', [PrintController::class, 'test']);
