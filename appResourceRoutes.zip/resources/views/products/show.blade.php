@php use App\Models\Unit; @endphp
@extends('layouts.admin')

@section('title', 'Product Details')
@section('content-header', 'Product Details')

@section('css')
    <link rel="stylesheet" href="{{ asset('plugins/sweetalert2/sweetalert2.min.css') }}">
@endsection
@section('content')
    {{-- product details page --}}
    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-md-3">
{{--                    <div class="product-img">--}}
{{--                        <img src="{{ $product->image }}" height="50%" width="100%" alt="">--}}
{{--                    </div>--}}

                </div>
                <div class="col-md-3">
                    <div class="product-details">
                        <h3 class="product-name">Name: {{ $product->name }}</h3>
                        <p class="product-description">Description: {{ $product->description }}</p>

                        <p class="product-status">Status: {{ $product->status?'Active':'Inactive' }}</p>
                        <p class="product-created-at">Created At: {{ $product->created_at->format('Y-M-j h:i a') }}</p>
                        <p class="product-updated-at">Updated At: {{ $product->updated_at->format('Y-M-j h:i a') }}</p>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="product-details">
                        <h4>Standard Units: {{ $product->keepingUnit?->name }}</h4>
                         <h5>Remaining Stock: {{ $product->remaining_stock }} {{ $product->keepingUnit?->name }}</h5>

                        @foreach ($product->variants as $variant )
                            <ul>
                                <span> Variant: {{ $variant->name }} ► {{ $variant->contained_quantity }} ►{{ $variant->unit->name }}</span>
                            </ul>

                        @endforeach


                    </div>
                </div>

                <div class="col-md-3">
                    <div class="product-details">
                        <h4>Activity Log</h4>
                        @foreach ($product->activities->take(4) as $activity )
                            <p> {{ Str::title($activity->description) }}
                                on {{ $activity->created_at->format('Y-M-j h:i a') }}</p>
                        @endforeach
                        @if ($product->activities->count() > 4)
                            <a href="{{ route('subject-activity-logs', [class_basename($product), $product->id]) }}">View
                                All Log</a>
                        @endif
                    </div>
                </div>
            </div>
        </div>

    </div>
    <div class="modal fade" id="price-adjustment-modal" tabindex="-1" role="dialog"
         aria-labelledby="price-adjustment-modal-label" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="price-adjustment-modal-label">Adjust Price</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="{{ route('product.price.update',$product) }}" method="POST">
                        @csrf
                        <div class="form-group">
                            <label for="price">Price</label>
                            <input type="number" name="price" id="price" class="form-control" placeholder="Enter Price"
                                   aria-describedby="helpId">
                            <small id="helpId" class="text-muted">Enter Price</small>
                        </div>
                        <div class="form-group">
                            <label for="reason">Reason</label>
                            <textarea class="form-control" name="reason" id="reason" rows="3"></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Adjust Price</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

@endsection
