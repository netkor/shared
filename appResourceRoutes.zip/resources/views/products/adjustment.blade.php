@extends('layouts.admin')

@section('title', 'Product Stock Adjustment')
@section('content-header', 'Stock Details')

@section('content')
    <div id="product-adjustment" data-units="{{ $units }}" data-product="{{ $product  }}">
    </div>
@endsection
