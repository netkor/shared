@extends('layouts.admin')

@section('title', 'Assign Inventory Product  to Stores')
@section('content-header', 'Assign Inventory Product  to Stores')

@section('content')

    <div class="card">
        <div class="card-body">
            <div id="store" data-columns="{{ $columns }}"></div>
        </div>
    </div>
@endsection
