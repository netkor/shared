@extends('layouts.admin')

@section('title', 'Permission')

@section('content')
    <div id="permission"  ></div>
@endsection
