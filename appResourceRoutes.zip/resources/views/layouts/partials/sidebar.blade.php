{{--<!-- Main Sidebar Container -->--}}
{{--<aside class="main-sidebar sidebar-light-danger elevation-4">--}}
{{--    <!-- Brand Logo -->--}}
{{--    <a href="{{ url('dashboard') }}" class="brand-link  bg-white">--}}
{{--        <img src="{{ asset('images/logo.png') }}" alt="app" class="brand-image">--}}
{{--        <span class="brand-text font-weight-light">{{ config('app.name') }}</span>--}}
{{--    </a>--}}

{{--    <!-- Sidebar -->--}}
{{--    <div class="sidebar">--}}
{{--        <!-- Sidebar Menu -->--}}
{{--        <nav class="mt-2">--}}
{{--            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">--}}
{{--                @include('layouts.partials.menu',['icons'=>true])--}}
{{--            </ul>--}}
{{--        </nav>--}}
{{--        <!-- /.sidebar-menu -->--}}
{{--    </div>--}}
{{--    <!-- /.sidebar -->--}}
{{--</aside>--}}


<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-light-red elevation-3">
    <!-- Brand Logo -->
    <a href="{{route('home')}}" class="brand-link">
        <img src="{{ asset('images/logo.png') }}" alt="AdminLTE Logo" class="brand-image img-circle elevation-1"
             style="opacity: .8">
        <span class="brand-text font-weight-light">{{ config('app.name') }}</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                <!-- Sidebar user (optional) -->
                <ul class="user-panel my-3 px-2 pb-3 flex justify-content-center align-items-center">
                    <div>
                        <img src="{{ auth()->user()->getAvatar() }}" class="h-16 w-16 rounded-full elevation-1"
                             alt="User Image">
                    </div>
                    <div class="flex flex-column ml-2 flex-1 items-center justify-content-center">
                        <a href="/profile" class="d-block text-bold">{{ auth()->user()->full_name }}</a>
                        <span
                            class="text-md text-gray-400">{{ auth()->user()->roles()->pluck('name')->implode(', ') }} </span>
                        <span class="text-xs text-muted">{{ auth()->user()->email }}</span>
                        <span class="text-xs text-muted">{{ auth()->user()->currentBranch()?->name }}</span>
                    </div>
                </ul>

                @include('layouts.partials.menu',['icons'=>true])
            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside>
