@extends('errors::minimal')

@section('title', __('Forbidden'))

<section class="flex items-center h-full p-16 dark:bg-gray-900 dark:text-gray-100">
    <div class="container flex flex-col items-center justify-center px-5 mx-auto my-8">
        <div class="max-w-md text-center">
            <h2 class="mb-8 font-extrabold text-9xl dark:text-gray-600">
                <span class="sr-only">Forbidden</span>403
            </h2>
            <p class="text-2xl font-semibold md:text-3xl">{{ $exception->getMessage() ?: 'Forbidden' }}</p>
            <p class="mt-4 mb-8 dark:text-gray-400">

            </p>
            <a rel="noopener noreferrer" href="{{ url()->previous() }}"
               class="inline-flex items-center justify-center px-4 py-2 text-sm font-medium leading-5 text-white transition duration-150 ease-in-out bg-gray-600 border border-transparent rounded-md hover:bg-gray-500 focus:outline-none focus:border-gray-700 focus:shadow-outline-gray active:bg-gray-700">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                     stroke="currentColor" class="w-6 h-6 mr-2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M6.75 15.75L3 12m0 0l3.75-3.75M3 12h18"/>
                </svg>

                <span>Go Back</span></a>
        </div>
    </div>
</section>

