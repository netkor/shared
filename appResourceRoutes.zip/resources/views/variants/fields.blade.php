<div class="form-group">
    <label for="name">Variant Name</label>
    <input type="text" name="name" class="form-control @error('name') is-invalid @enderror"
           id="name" placeholder="Variant Name" value="{{ old('name', $variant->name) }}">
    @error('name')
    <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
    @enderror
</div>

<div class="form-group">
    <label for="contained_quantity">Contained Unit</label>
    <input type="number" name="contained_quantity"
           class="form-control @error('contained_quantity') is-invalid @enderror" id="contained_quantity"
           placeholder="Contained Quantity" value="{{ old('contained_quantity', $variant->contained_quantity) }}">
    @error('contained_quantity')
    <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
    @enderror
</div>

<div class="col-md-3">
    <div class="form-group">
        <label for="unit_id">Unit </label>
        <select class="form-control form-select" aria-label="Default select example" name="unit_id">
            <option selected>Open this select menu</option>
            @foreach ($units as $key => $unit)
                <option value="{{ $key }}" @if ($selectedUnit == $key) selected @endif>
                    {{ $unit }}</option>
            @endforeach
        </select>
        @error('unit_id')
        <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
        @enderror
    </div>
</div>

