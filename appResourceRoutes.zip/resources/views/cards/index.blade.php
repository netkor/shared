@extends('layouts.admin')

@section('title', 'Card List')
@section('content-header', 'Card List')
@section('content-actions')
    <a href="{{ route('cards.create') }}" class="btn btn-primary">Add Card</a>
@endsection
@section('css')
    <link rel="stylesheet" href="{{ asset('plugins/sweetalert2/sweetalert2.min.css') }}">
@endsection
@section('content')
    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-md-7">
                    <form action="{{ route('cards.index') }}">

                        <div class="row">
                            <div class="col-md-5">
                                <label for="from">Search By Card Address</label>
                                <input type="text" placeholder="Enter Card Name" name="search" class="form-control"
                                       value="{{ request()->name }} ">
                            </div>

                            <div class="col-md-2">
                                <label for="from">Filter</label>
                                <button class="btn btn-outline-primary" type="submit">Search</button>
                            </div>
                        </div>
                    </form>
                </div>

            </div>

            <table class="table">
                <thead>
                <tr>
                    <th>Card Name</th>
                    <th>Card Address</th>
                    <th>Card QR</th>
                    @can('view.balance')
                        <th>Balance</th>
                    @endcan
                    <th>Created At</th>
                    <th>Actions</th>
                </tr>
                </thead>
                <tbody>
                @foreach ($cards as $card)
                    <tr>
                        <td>{{ $card->name }}</td>
                        <td>{{ $card->address }}</td>
                        <td>
                            <div class="visible-print text-center">
                                {!! QrCode::size(100)->style('round')->generate($card->name) !!}
                            </div>
                        </td>
                        @can('view.balance')
                            <td>{{ $card->balance() }}</td>
                        @endcan
                        <td>{{ $card->created_at->format('Y-M-j h:i a') }}</td>
                        <td>
                            <button data-toggle="modal" data-target="#cardloadWithdraw{{ $card->id }}"
                                    class="btn  btn-primary">
                                <i class="fa-solid fa-money-bill-1-wave"></i>
                            </button>

                            <a href="{{ route('cards.show', $card) }}" class="btn btn-success"><i
                                    class="fas fa-eye"></i></a>
                            <a href="{{ route('cards.edit', $card) }}" class="btn btn-primary"><i
                                    class="fas fa-edit"></i></a>
                            <button class="btn btn-danger btn-delete" data-url="{{ route('cards.destroy', $card) }}"><i
                                    class="fas fa-trash"></i></button>
                        </td>
                    </tr>

                    <div class="modal fade" id="cardloadWithdraw{{ $card->id }}" tabindex="-1" role="dialog"
                         aria-labelledby="cardloadWithdrawModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="cardloadWithdrawModalLabel">
                                        For Card : {{ $card->name }}
                                    </h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>

                                <div class="modal-body">

                                    <form action="{{ route('cards.transactions.store', $card) }}" method="POST">
                                        @csrf
                                        <div
                                            class="form-group {{ $errors->has('amount') ? 'has-error' : '' }}">
                                            <label for="amount">Amount</label>
                                            <input type="number" name="amount" id="amount" class="form-control"
                                                   placeholder="Enter Amount" value="{{ old('amount') }}">
                                            {!! $errors->first('amount', '<span class="help-block">:message</span>') !!}
                                        </div>
                                        <div class="form-group">
                                            {{ $errors->has('notes') ? 'has-error' : '' }}
                                            <label for="notes">Notes</label>
                                            <input type="text" name="notes" id="notes" class="form-control"
                                                   placeholder="Enter Notes" value="{{ old('notes') }}">
                                            {!! $errors->first('notes', '<span class="help-block">:message</span>') !!}
                                        </div>
                                        <div class="form-group">
                                            <label for="source">Type</label>
                                            <select name="source" id="source"
                                                    class="form-control @error('source') is-invalid @enderror">
                                                <option value="">Select Type</option>
                                                <option value="deposit">Deposit</option>
                                                <option value="withdraw">Withdraw</option>
                                            </select>
                                            @error('source')
                                            <span class="invalid-feedback" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                            @enderror
                                        </div>
                                        <button type="submit" class="btn btn-primary">Submit</button>
                                    </form>
                                </div>


                            </div>
                        </div>
                    </div>
                @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection

@section('js')
    <script src="{{ asset('plugins/sweetalert2/sweetalert2.min.js') }}"></script>
    <script>
        $(document).ready(function () {
            $(document).on('click', '.btn-delete', function () {
                $this = $(this);
                const swalWithBootstrapButtons = Swal.mixin({
                    customClass: {
                        confirmButton: 'btn btn-success',
                        cancelButton: 'btn btn-danger'
                    },
                    buttonsStyling: false
                })

                swalWithBootstrapButtons.fire({
                    title: 'Are you sure?',
                    text: "Do you really want to delete this card?",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, delete it!',
                    cancelButtonText: 'No',
                    reverseButtons: true
                }).then((result) => {
                    if (result.value) {
                        $.post($this.data('url'), {
                            _method: 'DELETE',
                            _token: '{{ csrf_token() }}'
                        }, function (res) {
                            $this.closest('tr').fadeOut(500, function () {
                                $(this).remove();
                            })
                        })
                    }
                })
            })
        })
    </script>
@endsection
