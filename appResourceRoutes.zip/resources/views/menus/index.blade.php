{{--@extends('layouts.admin')--}}

{{--@section('title', 'Menu List')--}}
{{--@section('content-header', 'Order Details')--}}

{{--@section('content')--}}
{{--    <div id="menu-list" data-menus="{{ $menus }}">--}}
{{--    </div>--}}
{{--@endsection--}}


@extends('layouts.admin')

@section('title', ' Menu')
@section('content-header', 'Menu List')
@section('content-actions')
    <a href="#" class="btn btn-primary">Add Menu</a>
@endsection
@section('css')
    <link rel="stylesheet" href="{{ asset('plugins/sweetalert2/sweetalert2.min.css') }}">
@endsection
@section('content')

    <div class="content">
        <div class="clearfix"></div>
        <div class="card">
            <div class="card-header">
                <ul class="nav nav-tabs align-items-end card-header-tabs w-100">
                    <li class="nav-item">
                        <a class="nav-link active" href="{!! url()->current() !!}"><i
                                class="fa fa-list mr-2"></i>Menus List</a>
                    </li>

                    @can('menus.create')
                        <li class="nav-item">
                            <a class="nav-link" href="{!! route('menus.create') !!}"><i
                                    class="fa fa-plus mr-2"></i>Create Menu</a>
                        </li>
                    @endcan

                    @include('layouts.right_toolbar', compact('dataTable'))
                </ul>
            </div>
            <div class="card-body">
                @include('menus.table')
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
@endsection

