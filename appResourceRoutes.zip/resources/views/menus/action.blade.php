<div class='btn-group btn-group-sm'>
    <a data-toggle="tooltip" data-placement="bottom" title="ingridents"
       href="{{ route('reciepeIngredient.index', $id) }}" class='btn btn-link'>

        <i class="fa fa-flask"></i>
    </a>
    {{-- @can('provinces.show')--}}
    <a data-toggle="tooltip" data-placement="bottom" title="show"
       href="{{ route('menus.show', $id) }}" class='btn btn-link'>
        <i class="fa fa-eye"></i>
    </a>
    {{-- @endcan--}}

    {{-- @can('menus.edit') --}}
    <a data-toggle="tooltip" data-placement="bottom" title="edit"
       href="{{ route('menus.edit', $id) }}" class='btn btn-link'>
        <i class="fa fa-edit"></i>
    </a>
    {{-- @endcan --}}

    {{-- @can('menus.delete') --}}
    {!! Form::open(['route' => ['menus.destroy', $id], 'method' => 'delete']) !!}
    {!! Form::button('<i class="fa fa-trash"></i>', [
    'type' => 'submit',
    'class' => 'btn btn-link text-danger',
    'onclick' => "return confirm('Are you sure?')"
    ]) !!}
    {!! Form::close() !!}
    {{-- @endcan --}}
</div>
