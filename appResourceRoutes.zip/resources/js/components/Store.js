import React, {Component} from "react";

import ReactDOM from "react-dom";
import Swal from "sweetalert2";
import {DragDropContext, Draggable, Droppable} from "react-beautiful-dnd";

class Store extends Component {

    constructor(props) {

        super(props);

        this.state = {
            columns: JSON.parse(props.columns),
            pickupQuantity: 4,
        };
    }


    render() {
        const {columns} = this.state;
        return (
            <div className="col">
                <div className="row">
                    {/* set pick up quantity */}
                    <div className="col-md-3">
                        <div className="form-group">
                            <label htmlFor="pickupQuantity">Pick up quantity</label>
                            <input type="number" className="form-control" id="pickupQuantity"
                                   name="pickupQuantity"
                                   value={this.state.pickupQuantity}
                                   onChange={() =>
                                       this.setState({
                                           pickupQuantity: event.target.value,
                                       })
                                   }
                            />
                        </div>
                    </div>

                    {/* Send all items to store  */}
                    <div className="col-md-3">
                        <div className="form-group">
                            <label htmlFor="pickupQuantity">Send all items to store</label>
                            <button type="button" className="btn btn-primary" onClick={() => this.sendAllToStore()}>
                                Send all
                            </button>
                        </div>
                    </div>
                </div>


                <div style={{
                    display: "flex",
                    justifyContent: "center",
                    height: "100%",
                }}
                >
                    <DragDropContext
                        onDragEnd={(result) => this.onDragEnd(result, columns)}
                    >
                        {columns.map((column, i) => {
                                return (
                                    <div
                                        style={{
                                            display: "flex",
                                            flexDirection: "column",
                                            alignItems: "center",
                                        }}
                                        key={column.id}
                                    >
                                        <h2>{column.name}</h2>
                                        <div style={{margin: 8}}>
                                            <Droppable
                                                droppableId={column.id}
                                                key={column.id}
                                            >
                                                {(provided, snapshot) => {
                                                    return (
                                                        <div
                                                            {...provided.droppableProps}
                                                            ref={
                                                                provided.innerRef
                                                            }
                                                            style={{
                                                                background:
                                                                    snapshot.isDraggingOver
                                                                        ? "lightblue"
                                                                        : "lightgrey",
                                                                padding: 2,
                                                                width: 250,
                                                                minHeight: 500,
                                                            }}
                                                        >
                                                            {column.items.map(
                                                                (
                                                                    item,
                                                                    j
                                                                ) => {
                                                                    return (
                                                                        <Draggable
                                                                            // set draggable false
                                                                            isDragDisabled={!item.editable}

                                                                            key={
                                                                                item.identifier
                                                                            }
                                                                            draggableId={
                                                                                item.identifier
                                                                            }
                                                                            index={
                                                                                j
                                                                            }
                                                                        >
                                                                            {(
                                                                                provided,
                                                                                snapshot
                                                                            ) => {
                                                                                return (
                                                                                    <div
                                                                                        ref={
                                                                                            provided.innerRef
                                                                                        }
                                                                                        {...provided.draggableProps}
                                                                                        {...provided.dragHandleProps}
                                                                                        style={{
                                                                                            userSelect:
                                                                                                "none",
                                                                                            padding: 16,
                                                                                            margin: "0 0 8px 0",
                                                                                            minHeight:
                                                                                                "50px",
                                                                                            backgroundColor:
                                                                                                snapshot.isDragging
                                                                                                    ? "#263B4A"
                                                                                                    : "#456C86",
                                                                                            color: "white",
                                                                                            ...provided
                                                                                                .draggableProps
                                                                                                .style,
                                                                                        }}
                                                                                    > {item.name}{"  "}({item.stock}){item.unit_name}


                                                                                        {/*check if column is editable */}
                                                                                        {column.editable && item.editable ? (
                                                                                            <input
                                                                                                type="number"
                                                                                                placeholder="Selling Price"
                                                                                                className="form-control"
                                                                                                required={true}
                                                                                                value={this.state.columns[i].items[j].price}

                                                                                                onChange={() => {
                                                                                                    this.setState({
                                                                                                        columns: this.state.columns.map((column, index) => {
                                                                                                                if (index === i) {
                                                                                                                    column.items[j].price = event.target.value
                                                                                                                }
                                                                                                                return column
                                                                                                            }
                                                                                                        )
                                                                                                    })
                                                                                                }}


                                                                                            />
                                                                                        ) : ("")}

                                                                                    </div>
                                                                                );
                                                                            }}
                                                                        </Draggable>
                                                                    );
                                                                }
                                                            )}
                                                            {
                                                                provided.placeholder
                                                            }
                                                        </div>
                                                    );
                                                }}
                                            </Droppable>
                                        </div>
                                    </div>
                                );
                            }
                        )}
                    </DragDropContext>{" "}
                </div>
                <button
                    className="btn btn-success"
                    onClick={() => this.handelSubmitButton(this.state.columns)}
                >
                    Add to Store
                </button>
            </div>
        );
    }

    onDragEnd(result, columns) {
        if (!result.destination) return;

        const {source, destination} = result;

        if (source.droppableId !== destination.droppableId) {

            const sourceColumn = columns.filter(element => element.id === source.droppableId)[0];
            const destColumn = columns.filter(element => element.id === destination.droppableId)[0];

            const sourceItems = [...sourceColumn.items];
            const destItems = [...destColumn.items];

            const removed = sourceItems.splice(source.index, 1)[0];
            const toDestination = {...removed};
            const toSource = {...removed};

            if (toSource.stock < this.state.pickupQuantity) {

                Swal.fire({
                    icon: 'error',
                    title: 'Oops...',
                    text: 'Quantity is smaller than pickup quantity!',
                })

                return;
            }

            toDestination.identifier = toDestination.id + "|" + destColumn.id;

            const alreadyInDestination = destItems.filter(element => element.identifier === toDestination.identifier)[0];


            if (alreadyInDestination) {
                alreadyInDestination.quantity = parseInt(alreadyInDestination.quantity) + parseInt(this.state.pickupQuantity);
            } else {
                toDestination.quantity = parseInt(this.state.pickupQuantity);
                destItems.splice(destination.index, 0, toDestination);
            }

            toSource.stock = toSource.stock - this.state.pickupQuantity;
            sourceItems.splice(source.index, 0, toSource);

            if (sourceItems[source.index].quantity <= 0) {
                sourceItems.splice(source.index, 1);
            }

            this.state.columns.map((column, index) => {
                if (column.id === source.droppableId) {
                    column.items = sourceItems;
                } else if (column.id === destination.droppableId) {
                    column.items = destItems;
                }
            });

        } else {
            const column = columns.filter(element => element.id === source.droppableId)[0];
            const copiedItems = [...column.items];
            const [removed] = copiedItems.splice(source.index, 1);
            copiedItems.splice(destination.index, 0, removed);
            column.items = copiedItems;
        }
    }

    handelSubmitButton() {
        console.log(this.state.columns);
        Swal.fire({
            title: "Are you sure?",
            text: "You won't be able to revert this!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yes, save it!",
        }).then((result) => {
            if (result.isConfirmed) {
                axios
                    .post(`/admin/store-product`, {
                        data: this.state.columns,
                    })
                    .then((res) => {
                        Swal.fire(
                            "Success!",
                            "Store Products Added",
                            "success",
                        );
                        window.location.href = "/admin/store";
                    })
                    .catch((err) => {
                        Swal.fire("Error!", err.response.data.message, "error");
                    });
            }
        });
    }

    sendAllToStore() {
        this.state.columns.map((column) => {
            column.items.map((item) => {
                item.quantity = item.inventoryQuantity;
            });

        });

        // this.handelSubmitButton();
    }

}

export default Store;

if (document.getElementById("store")) {
    const element = document.getElementById("store");
    const props = Object.assign({}, element.dataset);
    ReactDOM.render(<Store {...props} />, element);
}
