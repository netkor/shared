import React, {Component} from "react";


export default class TableRow extends Component {

    constructor(props) {
        super(props);

        this.state = {
            cart: props.cart,
            active: props.active,
            setActiveRow: props.setActiveRow,
        };

        console.log(this.state.cart);
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        if (prevProps.active !== this.props.active) {
            this.setState({
                active: this.props.active
            });
        }
    }


    render() {
        return (
            <tr className={this.state.active ? "bg-[#f4f7f9] overflow-hidden rounded-lg cursor-pointer" : "overflow-hidden rounded-lg cursor-pointer"}
                onClick={
                    () => {
                        this.state.setActiveRow(this.state.cart.group);
                    }
                }>
                <td className="rounded-bl-xl rounded-tl-xl py-4 px-2 font-semibold">

                    <div className="flex relative w-fit">
                        #{this.state.cart.group}
                        <div
                            className={this.state.cart.unread ?? true ? "absolute -top-1 -right-2  h-2 w-2 bg-rose-600 rounded-full" : "hidden"}></div>
                    </div>


                </td>
                <td className="py-4 px-2">{this.state.cart.table}</td>
                <td className="py-4 px-2">
                    <div className="flex">
                        {this.state.cart.types.map((type, index) => (
                            <div key={index}
                                 className="w-fit text-center  flex items-center justify-center rounded-full bg-gray-500/20 py-1 px-2 text-xs font-medium text-gray-500 mx-2">
                                {type === "Kitchen"
                                    ?
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                         strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 mr-1">
                                        <path strokeLinecap="round" strokeLinejoin="round"
                                              d="M15.362 5.214A8.252 8.252 0 0112 21 8.25 8.25 0 016.038 7.048 8.287 8.287 0 009 9.6a8.983 8.983 0 013.361-6.867 8.21 8.21 0 003 2.48z"/>
                                        <path strokeLinecap="round" strokeLinejoin="round"
                                              d="M12 18a3.75 3.75 0 00.495-7.467 5.99 5.99 0 00-1.925 3.546 5.974 5.974 0 01-2.133-1A3.75 3.75 0 0012 18z"/>
                                    </svg>
                                    : <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                           strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 mr-1">
                                        <path strokeLinecap="round" strokeLinejoin="round"
                                              d="M9.75 3.104v5.714a2.25 2.25 0 01-.659 1.591L5 14.5M9.75 3.104c-.251.023-.501.05-.75.082m.75-.082a24.301 24.301 0 014.5 0m0 0v5.714c0 .597.237 1.17.659 1.591L19.8 15.3M14.25 3.104c.251.023.501.05.75.082M19.8 15.3l-1.57.393A9.065 9.065 0 0112 15a9.065 9.065 0 00-6.23-.693L5 14.5m14.8.8l1.402 1.402c1.232 1.232.65 3.318-1.067 3.611A48.309 48.309 0 0112 21c-2.773 0-5.491-.235-8.135-.687-1.718-.293-2.3-2.379-1.067-3.61L5 14.5"/>
                                    </svg>
                                }
                                <span> {type}</span>
                            </div>
                        ))}


                    </div>
                </td>
                <td className="py-4 px-2">Rs {this.state.cart.total} /-</td>
                <td className="py-4 px-2">
                    <div className="relative rounded-full w-32 h-[0.55rem] bg-gray-200">
                        <div
                            className={this.state.cart.progress < 20
                                ? "absolute rounded-full h-full bg-gradient-to-r from-red-500 to-orange-500"
                                : this.state.cart.progress < 40
                                    ? "absolute rounded-full h-full bg-gradient-to-r from-orange-500 to-amber-500"
                                    : this.state.cart.progress < 80
                                        ? "absolute rounded-full h-full bg-gradient-to-r from-amber-500 to-yellow-500"
                                        : this.state.cart.progress < 80
                                            ? "absolute rounded-full h-full bg-gradient-to-r from-yellow-500 to-lime-500 "
                                            : "absolute rounded-full h-full bg-gradient-to-r from-lime-500 to-green-500"
                            }
                            style={{width: this.state.cart.progress + '%'}}>
                        </div>
                    </div>
                </td>

                <td className="py-4 px-2">
                    <div
                        className="w-24 text-center  rounded-full bg-purple-500/20 py-1 px-2 text-xs font-medium text-purple-500">{this.state.cart.status}</div>
                </td>
            </tr>
        );
    }
}
