import React, {Component} from "react";
import ItemView from "./ItemView";

export default class ItemList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            group: props.group,
            items: [],
            loading: false
        };
        this.componentDidMount = this.componentDidMount.bind(this);
        this.componentDidUpdate = this.componentDidUpdate.bind(this);
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        if (prevProps.group !== this.props.group || prevState.items.length !== this.state.items.length) {
            this.setState({
                group: this.props.group
            });
            this.fetchItems(this.props.group);
        }
    }

    componentDidMount() {
        this.fetchItems(this.state.group);
    }


    fetchItems = (group) => {
        this.setState({
            loading: true
        });
        axios.get(`/api/cart-details/${group}`)
            .then(response => {
                this.setState({
                    items: response.data
                });
            })
            .finally(() => {
                this.setState({
                    loading: false
                });
            });
    }


    render() {
        return (
            <div className="col-span-4 bg-[#f4f7f9] p-6 rounded-br-lg rounded-tr-lg overflow-hidden">
                <h3 className="text-md mb-8 font-semibold text-[#1f384c]">Detail of Order #{this.state.group}</h3>
                <div className="my-6 flex items-center justify-between border-b">
                    <div className="border-b-2 border-cyan-600 pb-3 text-sm font-semibold">Items</div>
                    <div className="pb-3 text-sm font-normal">Progress</div>
                    <div className="pb-3 text-sm font-normal">Review</div>
                </div>
                {this.state.loading
                    ? <div className="text-center">Loading...</div>
                    : <div className="flex flex-col"> {this.state.items.map((item, index) => {
                        return <ItemView key={index} item={item}/>
                    })} </div>
                }

            </div>
        );
    }
}
