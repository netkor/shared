import React, {Component} from "react";
import ReactDOM from "react-dom";

export default class MenuList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            menus: JSON.parse(props.menus),
        };
    }

    render() {
        return (
            <div className="bg-white pl-4">
                <div className="mt-2 grid grid-cols-12 border-t">
                    <div className="col-span-8">
                        <h3 className="text-md mb-8 mt-4 px-2 font-semibold text-[#1f384c]">Cart Orders List</h3>

                        <div className="w-full mb-8 overflow-hidden rounded-lg shadow-xs">
                            <div className="w-full overflow-x-auto">
                                <table className="w-full whitespace-no-wrap">
                                    <thead>
                                    <tr
                                        className="text-xs font-semibold tracking-wide text-left text-gray-500 uppercase border-b dark:border-gray-700 bg-gray-50 dark:text-gray-400 dark:bg-gray-800"
                                    >
                                        <th className="px-4 py-3">Client</th>
                                        <th className="px-4 py-3">Amount</th>
                                        <th className="px-4 py-3">Status</th>
                                        <th className="px-4 py-3">Date</th>
                                    </tr>
                                    </thead>
                                    <tbody
                                        className="bg-white divide-y dark:divide-gray-700 dark:bg-gray-800"
                                    >
                                    <tr className="text-gray-700 dark:text-gray-400">
                                        <td className="px-4 py-3">
                                            <div className="flex items-center text-sm">
                                                <div
                                                    className="relative hidden w-8 h-8 mr-3 rounded-full md:block"
                                                >
                                                    <img
                                                        className="object-cover w-full h-full rounded-full"
                                                        src="https://images.unsplash.com/flagged/photo-1570612861542-284f4c12e75f?ixlib=rb-1.2.1&q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=200&fit=max&ixid=eyJhcHBfaWQiOjE3Nzg0fQ"
                                                        alt=""
                                                        loading="lazy"
                                                    />
                                                    <div
                                                        className="absolute inset-0 rounded-full shadow-inner"
                                                        aria-hidden="true"
                                                    ></div>
                                                </div>
                                                <div>
                                                    <p className="font-semibold">Hans Burger</p>
                                                    <p className="text-xs text-gray-600 dark:text-gray-400">
                                                        10x Developer
                                                    </p>
                                                </div>
                                            </div>
                                        </td>
                                        <td className="px-4 py-3 text-sm">
                                            $ 863.45
                                        </td>
                                        <td className="px-4 py-3 text-xs">
                        <span
                            className="px-2 py-1 font-semibold leading-tight text-green-700 bg-green-100 rounded-full dark:bg-green-700 dark:text-green-100"
                        >
                          Approved
                        </span>
                                        </td>
                                        <td className="px-4 py-3 text-sm">
                                            6/10/2020
                                        </td>
                                    </tr>

                                    </tbody>


                                </table>
                            </div>
                        </div>

                        <table className="w-full">
                            <thead className="mt-8 border-b-[0.15rem] border-[#f4f7f9]">
                            <tr className="text-sm">
                                <th className="p-2 text-left font-semibold">Order No</th>
                                <th className="p-2 text-left font-semibold">Table No</th>
                                <th className="p-2 text-left font-semibold">Type</th>
                                <th className="p-2 text-left font-semibold">Price</th>
                                <th className="p-2 text-left font-semibold">Progress</th>
                                <th className="p-2 text-left font-semibold ">Status</th>
                            </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        );
    }
}


if (document.getElementById("menu-list")) {
    const element = document.getElementById("menu-list");
    const props = Object.assign({}, element.dataset);
    ReactDOM.render(<MenuList {...props} />, element);
}

