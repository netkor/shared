import { Component } from "react";
import Html5QrcodePlugin from "../components/Html5QrcodePlugin";
import ReactDOM from 'react-dom'
import React from 'react'


export default class QrScanner extends Component {
    constructor(props) {
        super(props);

        // This binding is necessary to make `this` work in the callback.
        this.onNewScanResult = this.onNewScanResult.bind(this);
    }

    render () {
        return (
            <div>
                <h1>Scan your Qr</h1>
                <Html5QrcodePlugin
                    fps={10}
                    qrbox={250}
                    disableFlip={false}
                    qrCodeSuccessCallback={this.onNewScanResult}
                />
            </div>
        );
    }
    onNewScanResult(decodedText, decodedResult) {
            console.log(`Scan result: ${decodedText}`, decodedResult);
    }
}


if (document.getElementById("qr-scanner")) {
    const element = document.getElementById("qr-scanner");
    //const props = Object.assign({}, element.dataset);
    ReactDOM.render(<QrScanner />, element);
}
