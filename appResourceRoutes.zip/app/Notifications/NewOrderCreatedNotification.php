<?php

namespace App\Notifications;

use Benwilkins\FCM\FcmMessage;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;


class NewOrderCreatedNotification extends Notification
{
    use Queueable;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param mixed $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['fcm'];
    }


    public function toFcm($notifiable)
    {
        $message = new FcmMessage();
        $message->content([
            'title' => 'Pankaj Sir K gardai hunuxa',
            'body' => 'Next Message',
            'sound' => 'true', // Optional
            'icon' => 'https://www.freepnglogos.com/uploads/whatsapp-logo-light-green-png-0.png', // Optional
            'image' => 'https://www.freepnglogos.com/uploads/whatsapp-logo-light-green-png-0.png', // Optional
            'click_action' => 'FLUTTER_NOTIFICATION_CLICK' // Optional
        ])->data([
            'param1' => 'baz' // Optional
        ])->priority(FcmMessage::PRIORITY_HIGH); // Optional - Default is 'normal'.

        return $message;
    }


}
