<?php

namespace App\DataTables\Scopes;

use Illuminate\Database\Eloquent\Builder;
use Yajra\DataTables\Contracts\DataTableScope;

class RoleActivities implements DataTableScope
{
    /**
     * Apply a query scope.
     *
     * @param \Illuminate\Database\Query\Builder|Builder $query
     * @return mixed
     */
    public function apply($query)
    {
        if (auth()->user()->hasRole('super-admin')) {
            return $query;
        }

        $branch = auth()->user()->currentBranch();

        if ($branch) {
            $users = $branch->users->pluck('id');
            return $query->whereIn('causer_id', $users);
        }

        return $query->where('causer_id', auth()->id());

    }
}
