<?php

namespace App\DataTables;

use App\Models\Menu;
use Illuminate\Database\Eloquent\Builder as QueryBuilder;
use Yajra\DataTables\DataTableAbstract;
use Yajra\DataTables\EloquentDataTable;
use Yajra\DataTables\Html\Builder;
use Yajra\DataTables\Html\Column;
use Yajra\DataTables\Services\DataTable;

class MenuDataTable extends DataTable
{
    /**
     * Build DataTable class.
     *
     * @param mixed $query Results from query() method.
     * @return DataTableAbstract
     */
    public function dataTable($query)
    {
        $dataTable = new EloquentDataTable($query);
        $columns = array_column($this->getColumns(), 'data');
        $dataTable = $dataTable
            ->addColumn('action', 'menus.action')
            ->rawColumns(array_merge($columns, ['action']));

        return $dataTable
            ->editColumn('created_at', function ($menu) {
                return $menu->created_at->format('jS F Y');
            })
            ->editColumn('updated_at', function ($menu) {
                return $menu->updated_at->format('jS F Y');
            })
            ->editColumn('status', function ($menu) {
                return $menu->status ? '<span class="badge badge-success">Active</span>' : '<span class="badge badge-danger">Inactive</span>';

            })

            //show image
            ->editColumn('image', function ($menu) {
                return '<img src="' . $menu->getFirstMediaUrl('menus', 'preview') . '" height="50px" width="50px" loading="lazy">';
            })

            ->rawColumns(['action', 'image', 'status']);

    }

    /**
     * Get columns.
     *
     * @return array
     */
    protected function getColumns(): array
    {
        return [
            Column::make('id'),
            Column::make('name'),
            Column::make('image'),
//            Column::make('category.name'),
//            Column::make('type.name'),
            Column::make('price'),
            Column::make('status'),
            Column::make('created_at'),
            Column::make('updated_at'),
        ];
    }

    /**
     * Get query source of dataTable.
     *
     * @param Menu $model
     * @return QueryBuilder
     */
    public function query(Menu $model): QueryBuilder
    {
        return $model->with(['category', 'type'])->orderBy('created_at', 'desc')->newQuery();
    }

    /**
     * Optional method if you want to use html builder.
     *
     * @return Builder
     */
    public function html()
    {
        return $this->builder()
            ->columns($this->getColumns())
            ->minifiedAjax()
            ->addAction(['width' => '80px', 'printable' => false, 'responsivePriority' => '100'])
            ->parameters(array_merge(
                config('datatables-buttons.parameters'),
                [
                    'language' => json_decode(
                        file_get_contents(
                            base_path('resources/lang/' . app()->getLocale() . '/datatable.json')
                        ),
                        true
                    ),
                ]
            ));
    }

    /**
     * Get filename for export.
     *
     * @return string
     */
    protected function filename(): string
    {
        return 'Menu_' . date('YmdHis');
    }
}
