<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreWebsiteRequest;
use App\Http\Requests\UpdateWebsiteRequest;
use App\Models\Website;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class WebsiteController extends Controller
{

    public function index()
    {
        $website = Website::first();
        if($website){
            return view('website.index', compact('website'));
        }
        return redirect()->route('website.create');


    }

    public function show(Website $website)
    {
        $website = Website::first();
    return view('website.show', compact('website'));
    }

    public function create()
    {
        return view('website.create');
    }



    public function store(StoreWebsiteRequest $request)
    {

        $image = '';
        $logo = '';
        $slider1 = '';
        $slider2 = '';
        $slider3 = '';


        if ($request->hasFile('image')) {
            $image = $request->file('image')->store('website', 'public');
        }
        if ($request->hasFile('logo')) {
            $logo = $request->file('logo')->store('website', 'public');
        }
        if ($request->hasFile('slider1')) {
            $slider1 = $request->file('slider1')->store('website', 'public');
        }
        if ($request->hasFile('slider2')) {
            $slider2 = $request->file('slider2')->store('website', 'public');
        }
        if ($request->hasFile('slider3')) {
            $slider3 = $request->file('slider3')->store('website', 'public');
        }



        $website = Website::query()->create([
            'title' => $request->title,
            'short_description' => $request->short_description,
            'long_description' => $request->long_description,
            'image' => $image,
            'logo' => $logo,
            'address' => $request->address,
            'phone' => $request->phone,
            'email' => $request->email,
            'facebook' => $request->facebook,
            'slider1' => $slider1,
            'slider2' => $slider2,
            'slider3' => $slider3,
            'close_time' => $request->close_time,
            'open_time' => $request->open_time,

        ]);

        if ($website) {
            return redirect()->route('website.index')->with('success', 'Website created successfully.');
        }
        return back()->withInput()->with('errors', 'Error creating new website');
    }

    public function edit(Request $request)
    {
        $website = Website::first();

        return view('website.edit', compact('website'));
    }

    public function update(UpdateWebsiteRequest $request, Website $website)
    {


        $website->title = $request->title;
        $website->short_description = $request->short_description;
        $website->long_description = $request->long_description;
        $website->address = $request->address;
        $website->phone = $request->phone;
        $website->email = $request->email;
        $website->close_time = $request->close_time;
        $website->open_time = $request->open_time;





        if ($request->hasFile('image')) {
            if($website->image){
                Storage::delete($website->image);
            }

            $image = $request->file('image')->store('website', 'public');
            $website->image = $image;
        }
        if ($request->hasFile('logo')) {
            if ($website->logo) {
                Storage::delete($website->logo);
            }

            $logo = $request->file('logo')->store('website', 'public');
            $website->logo = $logo;
        }
        if ($request->hasFile('slider1')) {
            if ($website->slider1) {
                Storage::delete($website->slider1);
            }

            $slider1 = $request->file('slider1')->store('website', 'public');
            $website->slider1 = $slider1;
        }
        if ($request->hasFile('slider2')) {
            if ($website->slider2) {
                Storage::delete($website->slider2);
            }

            $slider2 = $request->file('slider2')->store('website', 'public');
            $website->slider2 = $slider2;
        }
        if ($request->hasFile('slider3')) {
            if ($website->slider3) {
                Storage::delete($website->slider3);
            }
            $slider3 = $request->file('slider3')->store('website', 'public');
            $website->slider3 = $slider3;
        }


        if (!$website->save()) {
            return redirect()->route('website.index')->with('success', 'Website updated successfully');
        }
        return back()->withInput();
    }


}
