<?php

namespace App\Http\Controllers;

use App\Enums\TransactionStatus;
use App\Http\Requests\StoreInventoryRequest;
use App\Http\Requests\UpdateInventoryRequest;
use App\Http\Resources\VariantResource;
use App\Models\Inventory;
use App\Models\Product;
use App\Models\Stock;
use App\Models\Unit;
use App\Models\Vendor;
use App\Services\UnitConverter;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\View\Factory;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Response;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class InventoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
        $inventories = Inventory::query()->with('stocks.product')->get();

        return view('inventory.index', [
            'inventories' => $inventories,
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param StoreInventoryRequest $request
     * @return Response
     */
    public function store(StoreInventoryRequest $request)
    {
        return redirect()->route('inventory.index')->with('success', 'Inventory created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param Inventory $inventory
     * @return Application|Factory|View
     */
    public function show(Inventory $inventory)
    {
        return view('inventory.show', [
            'inventory' => $inventory
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param Inventory $inventory
     * @return Application|Factory|View
     */
    public function edit(Inventory $inventory)
    {
        $inventory = $inventory->load(['stocks.product.variants', 'stocks.variant', 'stocks', 'vendor']);

        $inventory = collect([
            'id' => $inventory->id,
            'vendor' => $inventory->vendor,
            'vendor_id' => $inventory->vendor_id,
            'batch_no' => $inventory->batch_no,
            'vat' => $inventory->vat,
            'bill_no' => $inventory->bill_no,
            'billing_date' => $inventory->billing_date ?? now(),
            'discount' => $inventory->discount,
            'extra_charge' => $inventory->extra_charge,
            'status' => (bool)$inventory->status,
            'products' => $inventory->stocks->map(
                function ($stock) {
                    return [
                        'id' => $stock->product->id,
                        'name' => $stock->product->name,
                        'quantity' => $stock->quantity,
                        'cost_price' => $stock->cost_price,
                        'stock' => $stock->remaining_quantity,
                        'variant_id' => $stock->variant->id,
                        'variants' => VariantResource::collection($stock->product->variants),
                        'expiry_date' => $stock->expiry_date,
                        'vat' => $stock->vat,
                        'discount' => $stock->discount,
                        'alert_quantity' => $stock->alert_quantity,
                    ];
                }
            ),

        ]);

        $units = Unit::all();
        $vendors = Vendor::all();


        return view('inventory.edit', [
            'inventory' => $inventory,
            'units' => $units,
            'vendors' => $vendors
        ]);
    }

    public function verify(Inventory $inventory): RedirectResponse
    {

        if ($inventory->isApproved()) {
            return redirect()->back()->with('error', 'Inventory already verified.');
        }

        DB::beginTransaction();

        $inventory->update([
            'approved_at' => now(),
            'received_at' => now(),
        ]);

        $this->updateStock($inventory->stocks);

        DB::commit();

        return redirect()->route('inventory.index')->with('success', 'Inventory verified successfully.');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param UpdateInventoryRequest $request
     * @param Inventory $inventory
     * @return RedirectResponse
     */
    public function update(UpdateInventoryRequest $request, $id): RedirectResponse
    {

        $inventory = Inventory::find($id);

        DB::beginTransaction();

        $inventory->update([
            'vendor_id' => $request->get('vendor_id'),
            'vat' => $request->get('vat', 0),
            'discount' => $request->get('discount', 0),
            'bill_no' => $request->get('bill_no'),
            'billing_date' => $request->get('billing_date', now()),
            'extra_charge' => $request->get('extra_charge', 0),
        ]);

        $stocks = collect($request->get(key: 'products'))->map(callback: function ($stock, $key) use ($inventory) {
            return
                [
                    'id' => array_key_exists('id', $stock) ? $stock['id'] : Str::uuid(),
                    'inventory_id' => $inventory->id,
                    'product_id' => $stock['id'],
                    'variant_id' => $stock['variant_id'],
                    'quantity' => $stock['quantity'],
                    'cost_price' => $stock['cost_price'],
                    'remaining_quantity' => $stock['quantity'],
                    'expiry_date' => $stock['expiry_date'],
                    'vat' => $stock['vat'],
                    'discount' => $stock['discount'],
                    'alert_quantity' => $stock['alert_quantity'],
                ];
        });

        Stock::query()->upsert($stocks->toArray(), ['product_id', 'inventory_id']);

//        $this->updateStock($stocks);

        DB::commit();

        return redirect()->route('inventory.index')->with('success', 'Inventory updated successfully.');

    }

    /**
     * @param Collection $stocks
     * @return void
     */
    protected function updateStock(Collection $stocks): void
    {
        $products = Product::query()
            ->with(['keepingUnit', 'variants.unit'])
            ->whereIn('id', $stocks->pluck('product_id'))
            ->get();

        $stocks->each(function ($stock) use ($products) {

            $product = $products->where('id', $stock['product_id'])->first();

            $variant = $product->variants->where('id', $stock['variant_id'])->first();

            if ($product->keepingUnit->hierarchy > $variant->unit->hierarchy) {
                $fromUnit = $variant->unit;
                $toUnit = $product->keepingUnit;
            } else {
                $fromUnit = $product->keepingUnit;
                $toUnit = $variant->unit;
            }

            $converter = new UnitConverter(fromUnit: $fromUnit, toUnit: $toUnit);

            $volume = $converter->convert($variant->contained_quantity * (float)$stock['quantity'] ?? 1);

            $note = "{$product->name} stock adjusted by {$volume} {$toUnit->name}.";

            $this->productTransaction(
                product: $product,
                volume: $volume,
                type: 'Stock In',
                note: $note
            );

            $product->remaining_stock = $product->remaining_stock + $volume;

            $product->save();
        });
    }

    protected function productTransaction(Product $product, $volume, $type, $note)
    {
        $product->itemTransactions()->create([
            'ref_no' => "INV-{$product->id}-" . Str::random(5),
            'note' => $note,
//            'note' => "{$product->name} stock adjusted by {$volume}",
            'source' => $type,
            'status' => TransactionStatus::COMPLETED,
            'quantity' => $volume,
            'stock' => $product->stock() + $volume
        ]);

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return RedirectResponse
     */
    public function create(): RedirectResponse
    {

        $inventory = Inventory::query()
            ->create([
                'batch_no' => Str::upper(Str::random(5)),
            ]);

        return redirect()->route('inventory.edit', $inventory);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param Inventory $inventory
     * @return Response
     */
    public function destroy(Inventory $inventory)
    {
        $inventory->delete();

        return redirect()->route('inventory.index')->with('success', 'Inventory deleted successfully.');
    }

    public function getExpireProduct()
    {
        $inventories = Inventory::with('expiredProduct')->get();
        $products = collect($inventories->map(function ($inventory) {
            return $inventory->expiredProduct;
        })->flatten());

        return view('warnings.productWarning', [
            'products' => $products,
            'title' => 'Expired Products'
        ]);
    }

    public function getAboutToExpireProduct()
    {
        $inventories = Inventory::with('expireWarningProduct')->get();
        $products = collect($inventories->map(function ($inventory) {
            return $inventory->expireWarningProduct;
        })->flatten());


        return view('warnings.productWarning', [
            'products' => $products,
            'title' => 'About to Expire'
        ]);
    }

    public function getAlertProduct()
    {
        $inventories = Inventory::with('products')->get();
        $products = collect();
        foreach ($inventories as $inventory) {
            $products = $products->merge($inventory->products->filter(function ($product) {

                return $product->pivot->stock <= $product->alert_quantity;

            }));
        }

        return view('warnings.productWarning', [
            'products' => $products,
            'title' => 'Stock on low'
        ]);
    }

    protected function adjustStock()
    {

    }

}
