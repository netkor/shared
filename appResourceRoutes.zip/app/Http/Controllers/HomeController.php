<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use App\Models\Menu;
use App\Models\Order;
use App\Models\Product;
use App\Models\Stock;
use App\Models\Transaction;
use Illuminate\Contracts\Support\Renderable;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return Renderable
     */
    public function index()
    {
        $orders = Order::with(['order_items.menu', 'payments'])->get();

        $pos_menus = Menu::query()->with(['ingredients.product']);

        $pos_menus = $pos_menus->get();

        $menus = collect();

        foreach ($pos_menus as $pos_menu) {
            $menus->push($this->accept($pos_menu));
        }

        $menus = $menus->reject(function ($menu) {
            return $menu->count() == 0;
        });


        return view('home', [
            'orders_count' => $orders->count(),

            'income' => $orders->map(function ($i) {
                if ($i->receivedAmount() > $i->total()) {
                    return $i->total();
                }
                return $i->receivedAmount();
            })->sum(),

            'income_today' => $orders->where('created_at', '>=', date('Y-m-d') . ' 00:00:00')->map(function ($i) {
                if ($i->receivedAmount() > $i->total()) {
                    return $i->total();
                }
                return $i->receivedAmount();
            })->sum(),
            'customers_count' => Customer::query()->count(),

            'current_balance' => Transaction:: query()->latest()->first()->balance ?? 0,


            'count_about_to_expire_products' => Stock::query()->where('expiry_date', '<=', date('Y-m-d', strtotime('+3 days')))->count(),
            'count_expired_products' => Stock::query()->where('expiry_date', '<=', date('Y-m-d'))->count(),
            'count_low_stock_products' => Product::query()->where('remaining_stock', '<=', 'alert_quantity')->count(),
            'about_to_expire_products' => Stock::query()->where('expiry_date', '<=', date('Y-m-d', strtotime('+3 days')))->get(),
            'expired_products' => Stock::query()->where('expiry_date', '<=', date('Y-m-d'))->get(),
            'low_stock_products' => Stock::query()->where('remaining_quantity', '<=', 'alert_quantity')->get(),
            'count_inactive_menus' => $pos_menus->count() - $menus->count(),
        ]);


    }

    private function accept($menu)
    {
        if (!$menu->ingredients->count() > 0) {
            return collect();
        }

        foreach ($menu->ingredients as $ingredient) {
//            @dd($ingredient);
            if ($ingredient->quantity >= $ingredient->product->remaining_stock) {
                return collect();
            }
        }

        return $menu;

    }

}
