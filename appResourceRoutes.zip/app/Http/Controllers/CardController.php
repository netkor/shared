<?php

namespace App\Http\Controllers;

use App\Models\Card;
use Illuminate\Http\Request;

class CardController extends Controller
{
    public function checkBalance()
    {

        return view('cards.checkBalance');
    }

    public function index(Request $request)
    {
        $cards = new Card();


        if ($request->search) {
            $cards = $cards->where('address', 'LIKE', "%{$request->search}%");
            $cards = $cards->orWhere('name', 'LIKE', "%{$request->search}%");
        }

        $cards = $cards->latest()->paginate(10);

        return view('cards.index', compact('cards'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'address' => 'required',
        ]);

        Card::create($request->all());

        return redirect()->route('cards.index')
            ->with('success', 'Card created successfully.');
    }

    public function create()
    {
        return view('cards.create');
    }

    public function show(Card $card)
    {
        return view('cards.show', compact('card'));
    }

    public function edit(Card $card)
    {
        return view('cards.edit', compact('card'));
    }

    public function update(Request $request, Card $card)
    {
        $request->validate([
            'card_name' => 'required',
            'card_address' => 'required',
        ]);

        $card->update($request->all());

        return redirect()->route('cards.index')
            ->with('success', 'Card updated successfully');
    }

    public function destroy(Card $card)
    {
        $card->delete();

        return redirect()->route('cards.index')
            ->with('success', 'Card deleted successfully');
    }


}
