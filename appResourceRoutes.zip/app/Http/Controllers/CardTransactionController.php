<?php

namespace App\Http\Controllers;

use App\Models\Card;
use Illuminate\Http\Request;

class CardTransactionController extends Controller
{
    public function __invoke(Request $request, Card $card)
    {
        $request->validate([
            'amount' => 'required|numeric|gt:0',
            'source' => 'required|in:deposit,withdraw',
            'note' => 'nullable|string',
        ]);

        $input = $request->all();

        $input['note'] = $input['note'] ?? "Amount {$request->get('amount')} {$request->get('source')}";

        match ($request->get('source')) {
            'deposit' => $card->deposit($input['amount'], $input['note']),
            'withdraw' => $card->withdraw($input['amount'], $input['note']),
        };

        return redirect()
            ->route('cards.show', $card)
            ->with('success', "Card {$input['source']} successfully.");

    }

}
