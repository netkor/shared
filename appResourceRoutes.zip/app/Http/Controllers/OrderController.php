<?php

namespace App\Http\Controllers;

use App\DataTables\DailySalesDataTable;
use App\Events\OrderConfirmedEvent;
use App\Http\Requests\OrderStoreRequest;
use App\Models\Cart;
use App\Models\Order;
use App\Models\OrderItem;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class OrderController extends Controller
{
    public function index(Request $request)
    {
        $orders = new Order();
        if ($request->get('start_date')) {
            $orders = $orders->where('created_at', '>=', $request->start_date);
        }
        if ($request->get('end_date')) {
            $orders = $orders->where('created_at', '<=', $request->end_date . ' 23:59:59');
        }

        if ($request->get('ref_no')) {
            $orders = $orders->where('ref_no', 'like', '%' . $request->ref_no . '%');
        }
        if ($request->get('name')) {
            $orders = $orders->whereHas('customer', function ($query) use ($request) {
                $query->where('name', 'like', '%' . $request->name . '%');
            });
        }



        $orders = $orders->with(['order_items', 'payments', 'customer', 'table',])->orderBy('created_at', 'desc')->get();

        $total = $orders->map(function ($i) {
            return $i->total();
        })->sum();
        $receivedAmount = $orders->map(function ($i) {
            return $i->receivedAmount();
        })->sum();
        $discountAmount = $orders->map(function ($i) {
            return $i->discountAmount();
        })->sum();
        $returnAmount = $orders->map(function ($i) {
            return $i->refundAmount();
        })->sum();
        $waiter = auth()->user()->first_name;

        return view('orders.index', compact('orders', 'total', 'receivedAmount', 'waiter', 'discountAmount', 'returnAmount'));
    }

    public function store(OrderStoreRequest $request)
    {

        DB::beginTransaction();

        // Get Cart Items
        $carts = Cart::query()
            ->where('table_id', $request->get('table_id'))
            ->where('status', 'hold')
            ->get();

        // Create Order
        $order = Order::query()->create([
            'ref_no' => Order::generateRefNo(),
            'customer_id' => $request->get('customer_id'),
            'table_id' => $request->get('table_id'),
        ]);

        // Create Order Items
        $order->order_items()->createMany($carts->map(function ($i) {
            return [
                'menu_id' => $i->menu_id,
                'quantity' => $i->quantity,
            ];
        })->toArray());

        // Delete Cart Items
        $carts->each->update(['status' => 'served']);
        $carts->each->delete();


        // Make payment
        $order->payments()->create([
            'order_id' => $order->id,
            'amount' => $request->get('total'),
            'received_amount' => $request->get('recieved_amount'),
            'discount_amount' => $request->get('discount_amount'),
            'return_amount' => $request->get('tender_amount'),
        ]);

        // get leatest order from order table
        $order = Order::where('id', $order->id)->with(['order_items', 'payments', 'customer', 'table',])->first();

        $previousBalance = auth()->user()->currentBranch()->balance();

        $newBalance = $previousBalance + ($order->total() > $order->receivedAmount() ? $order->receivedAmount() : $order->total());

        auth()->user()->currentBranch()->transactions()->create([
            'ref_code' => $order->ref_no,
            'note' => "Payment for order {$order->ref_no}",
            'source' => "Cash",
            'status' => $request->get('status'),
            'amount' => ($order->total() > $order->receivedAmount() ? $order->receivedAmount() : $order->total()),
            'parent_id' => $request->get('parent_id'),
            'balance' => $newBalance ?? 0,

        ]);

        //add points to customer
        $order->customer->points += $order->total() / config('settings.points', 1);
        $order->customer->save();


        $table = $order->table;
        $table->status = 'open';
        $table->save();

        DB::commit();

        $order->load(['order_items', 'payments', 'customer', 'table',]);

        event(new OrderConfirmedEvent($this->makeReceiptReadyForPrint($order, 'billing')));


        return 'success';
    }

    protected function makeReceiptReadyForPrint($order, $key): array
    {

        $printed_date = date('M d, Y h:i:s');
        return [
            'order_no' => $order->ref_no,
            'title' => config('app.name'),
            'event' => str($key)->lower()->append("-event"),
            'table' => $order->table->name,
            'printed_date' => $printed_date,
            'type' => 'receipt',
            'customer_name' => $order->customer->name,
            'invoice_time' => $order->created_at->format('M d, Y h:i:s'),
            'total' => $order->formattedTotal(),
            'received_amount' => $order->formattedReceivedAmount(),
            'change_amount' => $order->formattedChangeAmount(),
            'discount_amount' => $order->formattedDiscountAmount(),
            'on_service_waiter' => auth()->user()->first_name,
            'items' => $order->order_items->map(function ($item) {
                return [
                    'name' => $item->menu->name,
                    'qty' => $item->quantity,
                    'price' => $item->menu->price,
                    'total' => $item->menu->price * $item->quantity
                ];
            })
        ];
    }

    public function printReceipt($order)
    {
        $order = Order::query()->with(['order_items', 'payments', 'customer', 'table',])->find($order);

        event(new OrderConfirmedEvent($this->makeReceiptReadyForPrint($order, 'billing')));

        return redirect()->back()->with('success', 'Receipt printed successfully');
    }


    public function dailysalesreport(Request $request)
    {
        $ordersItem = new OrderItem();

        if ($request->get('start_date') && $request->get('end_date')) {
            $ordersItem = $ordersItem->whereBetween('created_at', [$request->get('start_date'), $request->get('end_date')]);
        }

        if ($request->get('menu')) {
            $ordersItem = $ordersItem->whereHas('menu', function ($q) use ($request) {
                return $q->where('name', 'like', '%' . $request->menu . '%');
            });
        }







        $ordersItem = $ordersItem->with( 'menu')->orderBy('created_at', 'desc')->get();

        $totalQuantity = $ordersItem->map(function ($i) {
            return $i->quantity;
        })->sum();

        $totalAmount = $ordersItem->map(function ($i) {
            return $i->menu->price * $i->quantity;
        })->sum();






        return view('dailysalesreport.index', compact('ordersItem', 'totalQuantity', 'totalAmount', ));



       // return $dailySalesDataTable->render('dailysalesreport.index' , compact('orders', 'totalQuantity', 'totalAmount'));

    }
}
