<?php

namespace App\Http\Controllers;

use App\Models\Branch;
use App\Http\Requests\StoreBranchRequest;
use App\Http\Requests\UpdateBranchRequest;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class BranchController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $branches = Branch::all();

        return view('branches.index', compact('branches'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $users = User::select('id', 'first_name','last_name')->get()->mapWithKeys(function ($user) {
            return [$user->id => $user->first_name. " ".$user->last_name];
        });

        $selectedUser = null;

        return view('branches.create' ,compact('users','selectedUser'));

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoreBranchRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreBranchRequest $request)
    {
        $branch_logo = '';

        if ($request->hasFile('logo')) {
            $branch_logo = $request->file('logo')->store('branch', 'public');
        }

        $branch = Branch::create([
            'name'=> $request->name,
            'address'=> $request->address,
            'phone'=> $request->phone,
            'email'=> $request->email,
            'pan_no'=> $request->pan_no,
            'vat_no'=> $request->vat_no,
            'user_id'=> $request->user_id,
            'status'=> $request->status??'1',
            'logo'=> $branch_logo
        ]);

        $branch->users()->attach($request->user_id);


        if(!$branch) {
            return redirect()->back()->with('error', 'Branch could not be created');
        }

        return redirect()->route('branches.index')->with('success', 'Branch created successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Branch  $branch
     * @return \Illuminate\Http\Response
     */
    public function show(Branch $branch)
    {
       // return view('branches.show', compact('branch'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Branch  $branch
     * @return \Illuminate\Http\Response
     */
    public function edit(Branch $branch)
    {
        $users = User::select('id', 'first_name','last_name')->get()->mapWithKeys(function ($user) {
            return [$user->id => $user->first_name. " ".$user->last_name];
        });
        $selectedUser = $branch->user_id;

        return view('branches.edit', compact('branch', 'users', 'selectedUser'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdateBranchRequest  $request
     * @param  \App\Models\Branch  $branch
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateBranchRequest $request, Branch $branch)
    {

           $branch->name= $request->name;
           $branch->address= $request->address;
           $branch->phone= $request->phone;
           $branch->email= $request->email;
           $branch->pan_no= $request->pan_no;
           $branch->vat_no= $request->vat_no;
           $branch->user_id= $request->user_id;


        if ($request->hasFile('logo')) {
            // Delete old avatar
            if ($branch->logo) {
                Storage::delete($branch->logo);
            }
            // Store logo
            $branch_logo = $request->file('logo')->store('branch', 'public');
            // Save to Database
            $branch->logo = $branch_logo;
        }
        if(!$branch->save()) {
            return redirect()->back()->with('error', 'Branch could not be updated');
        }
        return redirect()->route('branches.index')->with('success', 'Branch updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Branch  $branch
     * @return \Illuminate\Http\Response
     */
    public function destroy(Branch $branch)
    {
        //soft delete the branch
        $branch->delete();
        return redirect()->route('branches.index')->with('success', 'Branch deleted successfully');
    }


}
