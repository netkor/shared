<?php

namespace App\Http\Controllers;


use Image;

class ImageResizeController extends Controller
{
    public function __invoke($model, $id, $width, $height)
    {
        $model = 'App\\Models\\' . ucfirst($model);
        $model = new $model;
        $model = $model->find($id);
        $image = $model->image;
        $path = storage_path('app/public/' . $image);
        $image = Image::make($path)->resize($width, $height);
        $image->resize($width, $height);
        return $image->response();

    }
}
