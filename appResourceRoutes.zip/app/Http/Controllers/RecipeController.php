<?php
//
//namespace App\Http\Controllers;
//
//use App\DataTables\MenuDataTable;
//use App\Http\Requests\StoreRecipeRequest;
//use App\Http\Requests\UpdateRecipeRequest;
//use App\Http\Resources\RecipeResource;
//use App\Models\Category;
//use App\Models\Product;
//use App\Models\Recipe;
//use App\Models\Type;
//use Illuminate\Http\Request;
//use Illuminate\Http\Response;
//use Illuminate\Support\Facades\DB;
//use Illuminate\Support\Facades\Storage;
//use Illuminate\Support\Str;
//
//class RecipeController extends Controller
//{
//    /**
//     * Display a listing of the resource.
//     *
//     * @return Response
//     */
//    public function index(MenuDataTable $dataTable, Request $request)
//    {
//        return $dataTable->render('menus.index');
//    }
//
//
//    public function posRecipe(Request $request)
//    {
////        $recipes = new Recipe();
//
//
////        if ($request->search) {
////            $recipes = $recipes->where('name', 'LIKE', "%{$request->search}%");
////            $recipes = $recipes->orWhere('barcode', 'LIKE', "%{$request->search}%");
////        }
////
//        $pos_recipes = Product::whereHas('stores', function ($query) {
//            $query->where('stock', '>', 0);
//        })->get();
//
//        if (request()->wantsJson()) {
//            return RecipeResource::collection($pos_recipes);
//        }
//    }
//
//    /**
//     * Display the specified resource.
//     *
//     * @param Recipe $recipe
//     * @return Response
//     */
//    public function show(Recipe $recipe)
//    {
//        return view('recipes.show', compact('recipe'));
//    }
//
//    /**
//     * Show the form for editing the specified resource.
//     *
//     * @param Recipe $recipe
//     * @return Response
//     */
//    public function edit(Recipe $recipe)
//    {
//        $categories = Category::select('id', 'name')->get()->mapWithKeys(function ($category) {
//            return [$category->id => $category->name];
//        });
//
//        $types = Type::select('id', 'name')->get()->mapWithKeys(function ($type) {
//            return [$type->id => $type->name];
//        });
//
//        $selectedCategory = $recipe->category()->first()->id;
//        $selectedType = $recipe->type()->first()->id;
//
//
//        return view('recipes.edit', compact('recipe', 'categories', 'types', 'selectedCategory', 'selectedType'));
//    }
//
//    /**
//     * Update the specified resource in storage.
//     *
//     * @param UpdateRecipeRequest $request
//     * @param Recipe $recipe
//     * @return Response
//     */
//    public function update(UpdateRecipeRequest $request, Recipe $recipe)
//    {
//        $image_path = $recipe->image;
//
//        if ($request->hasFile('image')) {
//            Storage::disk('public')->delete($recipe->image);
//            $image_path = $request->file('image')->store('recipe', 'public');
//        }
//
//        $recipe->update([
//            'name' => $request->name,
//            'description' => $request->description,
//            'image' => $image_path,
//            'barcode' => $request->barcode,
//            'status' => $request->status ?? 1,
//        ]);
//        $recipe->price()->create([
//            'price' => $request->price
//        ]);
//        $recipe->tags()->create([
//
//            'tag_id' => $request->category_id,
//        ]);
//        $recipe->tags()->create([
//
//            'tag_id' => $request->type_id,
//        ]);
//
//        if (!$recipe) {
//            return redirect()->back()->with('error', 'Sorry, there a problem while updating recipe.');
//        }
//        return redirect()->route('recipes.index')->with('success', 'Success, you recipe have been updated.');
//    }
//
//    /**
//     * Store a newly created resource in storage.
//     *
//     * @param StoreRecipeRequest $request
//     * @return Response
//     */
//    public function store(StoreRecipeRequest $request)
//    {
//
//        $image_path = '';
//
//        if ($request->hasFile('image')) {
//            $image_path = $request->file('image')->store('recipe', 'public');
//        }
//
//
//        DB::beginTransaction();
//        $recipe = Recipe::create([
//            'name' => $request->name,
//            'sku' => strtoupper(Str::random(10)),
//            'description' => $request->description,
//            'image' => $image_path,
//            'barcode' => $request->barcode,
//            'status' => $request->status ?? 1,
//        ]);
//
//        $recipe->price()->create([
//            'price' => $request->price
//        ]);
//
//        $recipe->tags()->create([
//            'tag_id' => $request->category_id,
//        ]);
//        DB::commit();
////
////        $recipe->tags()->create([
////#
////            'tag_id' => $request->type_id,
////        ]);
//
//
//        if (!$recipe) {
//            return redirect()->back()->with('error', 'Sorry, there a problem while creating recipe.');
//        }
//        return redirect()->route('recipes.index')->with('success', 'Success, you recipe have been created.');
//    }
//
//    /**
//     * Show the form for creating a new resource.
//     *
//     * @return Response
//     */
//    public function create()
//    {
//        $categories = Category::select('id', 'name')->get()->mapWithKeys(function ($category) {
//            return [$category->id => $category->name];
//        });
//
//        $types = Type::select('id', 'name')->get()->mapWithKeys(function ($type) {
//            return [$type->id => $type->name];
//        });
//
//
//        $selectedCategory = null;
//
//        $selectedType = null;
//        return view('recipes.create', compact('categories', 'types', 'selectedCategory', 'selectedType'));
//        // return view('recipes.create');
//    }
//
//    /**
//     * Remove the specified resource from storage.
//     *
//     * @param Recipe $recipe
//     * @return Response
//     */
//    public function destroy(Recipe $recipe)
//    {
//
//        if ($recipe->image) {
//            Storage::delete($recipe->image);
//        }
//        $recipe->delete();
//
//        return redirect()->route('recipes.index')->with('success', 'Success, you recipe have been deleted.');
//
//
//    }
//}
