<?php

declare(strict_types=1);

namespace App\Models;

use App\Contracts\CashTransactionContract;
use App\Models\Traits\HasAccount;
use App\Models\Traits\HasCashTransaction;
use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Support\Facades\Storage;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

class Branch extends Model implements CashTransactionContract
{
    use LogsActivity;
    use HasUuids;
    use HasCashTransaction;
    use HasAccount;


    protected $fillable = [
        'name',
        'address',
        'email',
        'phone',
        'logo',
        'pan_no',
        'vat_no',
        'status',
        'user_id',
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function users(): BelongsToMany
    {
        return $this->belongsToMany(User::class, 'user_branch');
    }

    public function getLogoUrl()
    {
        return Storage::url($this->logo);
    }

    public function url(): string
    {
        return route('branches.show', $this);
    }

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->logOnly(['name', 'address', 'email', 'phone', 'logo', 'pan_no', 'vat_no', 'status', 'user_id'])
            ->useLogName('Branch');
    }

    public function label(): string
    {
        return $this->name;
    }
}
