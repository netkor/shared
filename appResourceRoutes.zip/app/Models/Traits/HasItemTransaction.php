<?php

namespace App\Models\Traits;

use App\Models\ItemTransaction;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Database\Eloquent\Relations\MorphOne;

trait HasItemTransaction
{
    /**
     * Get all the transactions for the model.
     */
    public function itemTransactions(): MorphMany
    {
        return $this->morphMany(ItemTransaction::class, 'item');
    }

    /**
     * Get the latest transaction for the model.
     */
    public function itemTransaction(): MorphOne
    {
        return $this->morphOne(ItemTransaction::class, 'item')->latestOfMany();
    }

    /**
     * Get the latest balance for the model.
     */
    public function stock(): float
    {
        return (float)$this->transaction?->stock ?? 0;
    }

}
