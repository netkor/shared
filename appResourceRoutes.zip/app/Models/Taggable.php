<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Taggable extends Model
{
    use HasFactory;
    use HasUuids;

    protected $guarded = [];

    protected $table = 'taggable';

    public function tag()
    {
        return $this->belongsTo(Tag::class);
    }

    public function taggable()
    {
        return $this->morphTo();
    }
//
//    public function scopeHasCategory($query)
//    {
//        return $query->whereHas('tag', function ($query) {
//            $query->category();
//        });
//    }
//
//    public function scopeHasType($query)
//    {
//        return $query->whereHas('tag', function ($query) {
//            $query->type();
//        });
//    }


}
