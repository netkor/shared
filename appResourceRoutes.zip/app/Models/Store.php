<?php

namespace App\Models;

use App\Models\Traits\HasPrice;
use App\Models\Traits\HasTendent;
use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

class Store extends Model
{
    use HasFactory;
    use HasTendent;
    use LogsActivity;
    use HasPrice;
    use HasUuids;
    use SoftDeletes;

    protected $fillable = [
        'product_id',
        'sku',
        'stock',
        'inventory_id',
        'unit_id',
        'type',
    ];

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->logOnly(['name', 'address', 'email', 'phone', 'logo', 'pan_no', 'vat_no', 'status', 'user_id'])
            ->useLogName('Store');
    }

    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }

    public function inventory(): BelongsTo
    {
        return $this->belongsTo(Inventory::class);
    }

    public function unit(): BelongsTo
    {
        return $this->belongsTo(Unit::class);
    }
}
