<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

class Tenant extends Model
{
    use HasFactory;
    use LogsActivity;
    use HasUuids;

    protected $guarded = [];

    protected $casts = [
        'branch_id' => 'integer',
    ];

//    public function tendentable()
//    {
//        return $this->morphTo();
//    }
//
    public function branch()
    {
        return $this->belongsTo(Branch::class);
    }

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->logOnly(['name', 'email', 'phone', 'address', 'branch_id'])
            ->logExcept(['created_at', 'updated_at'])
            ->useLogName('Tenant');
    }
}
